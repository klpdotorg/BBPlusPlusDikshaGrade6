Game.NS_FM_1_G6demo = function () {};

Game.NS_FM_1_G6demo.prototype = {

    init: function (game) {
        _this = this;

        //* THIS GAME PLAYS DEMO VIDEO FOR FM1 & FM2 GAMES.
        //* User can skip the video to go to the game. Backbutton takes back to the menu.
        
//************************************** to be used in the Addition-Subtraction games.***********
//        //* get the session parameter if the demo is already seen.
//        //* if it is already seen, then set the parameter to 1 and skip the demo now.
//		var addDemoseen = sessionStorage.getItem("param1");
//        
//        if (addDemoseen == 1) _this.state.start('NS_INT_1_G6level1');   //* skip to game.
//        else                                                            //* set flg and continue demo
//        {
//            addDemoseen = 1;
//            sessionStorage.setItem("param1", addDemoseen);
//        }
//*************************************************************************************************
        
        _this.languageSelected = document.getElementById("LANGUAGE").innerHTML;
        
        if (_this.languageSelected == null 
            || _this.languageSelected == " "
            || _this.languageSelected == "")
        {
            _this.languageSelected = "ENG";
        }
        else console.log("Language selected: " + _this.languageSelected);
        

        _this.clickSound = document.createElement('audio');
        _this.clickSoundsrc = document.createElement('source');
        _this.clickSoundsrc.setAttribute("src", "sounds/ClickSound.mp3");
        _this.clickSound.appendChild(_this.clickSoundsrc);

        _this.screen_opening = document.createElement('audio');
        _this.screen_openingsrc = document.createElement('source');
        _this.screen_openingsrc.setAttribute("src", "sounds/screen opening.wav");
        _this.screen_opening.appendChild(_this.screen_openingsrc);
        
        _this.demoAudio1 = document.createElement('audio');
        _this.demoAudio1src = document.createElement('source');
        _this.demoAudio1src.setAttribute("src", "questionSounds/NS-FM-1-G6/" + 
                                         _this.languageSelected + "/NS-FM-1-G6 demo 1.mp3");
        _this.demoAudio1.appendChild(_this.demoAudio1src);
        
        _this.demoAudio2 = document.createElement('audio');
        _this.demoAudio2src = document.createElement('source');
        _this.demoAudio2src.setAttribute("src", "questionSounds/NS-FM-1-G6/" + 
                                         _this.languageSelected + "/NS-FM-1-G6 demo 2.mp3");
        _this.demoAudio2.appendChild(_this.demoAudio2src);
        
        _this.demoAudio3 = document.createElement('audio');
        _this.demoAudio3src = document.createElement('source');
        _this.demoAudio3src.setAttribute("src", "questionSounds/NS-FM-1-G6/" + 
                                         _this.languageSelected + "/NS-FM-1-G6 demo 3.mp3");
        _this.demoAudio3.appendChild(_this.demoAudio3src);
        
        //* enter the number of lines you need.
        _this.q1Sound = document.createElement('audio');
        _this.q1Soundsrc = document.createElement('source');
        _this.q1Soundsrc.setAttribute("src", "questionSounds/NS-FM-1-G6/" + 
                                         _this.languageSelected + "/NS-FM-1A-G6-a.mp3");
        _this.q1Sound.appendChild(_this.q1Soundsrc);
        
        //* is the smaller number factor of bigger number
        _this.q2Sound = document.createElement('audio');
        _this.q2Soundsrc = document.createElement('source');
        _this.q2Soundsrc.setAttribute("src", "questionSounds/NS-FM-1-G6/" + 
                                         _this.languageSelected + "/NS-FM-1A-G6-b.mp3");
        _this.q2Sound.appendChild(_this.q2Soundsrc);
        
        //* wht is the other factor here
        _this.q3Sound = document.createElement('audio');
        _this.q3Soundsrc = document.createElement('source');
        _this.q3Soundsrc.setAttribute("src", "questionSounds/NS-FM-1-G6/" + 
                                         _this.languageSelected + "/NS-FM-1A-G6-c.mp3");
        _this.q3Sound.appendChild(_this.q3Soundsrc);
        
        //* find if the options are factors of the given number.
        _this.q4Sound = document.createElement('audio');
        _this.q4Soundsrc = document.createElement('source');
        _this.q4Soundsrc.setAttribute("src", "questionSounds/NS-FM-2-G6/" + 
                                         _this.languageSelected + "/NS-FM-1B-G6-a.mp3");
        _this.q4Sound.appendChild(_this.q4Soundsrc);
        
        //* is the selected option a factor of the bigger number.
        _this.q5Sound = document.createElement('audio');
        _this.q5Soundsrc = document.createElement('source');
        _this.q5Soundsrc.setAttribute("src", "questionSounds/NS-FM-2-G6/" + 
                                         _this.languageSelected + "/NS-FM-1B-G6-b.mp3");
        _this.q5Sound.appendChild(_this.q5Soundsrc);
    },

    create: function (game) 
    {        
        _this.time.events.removeAll();
        _this.video_playing = 0;  //* variables to keep track of which video is played. video1/2/3
        _this.showDemoVideo();  //* call the function to show the video
        
        _this.backbtn = _this.add.sprite(5,6,'backbtn');         //* back button at the top.
        _this.backbtn.inputEnabled = true;
        _this.backbtn.input.useHandCursor = true;
        _this.backbtn.events.onInputDown.add(function ()
        {
            _this.clickSound.play();
            _this.stopVideo();
            _this.state.start('NS_INT_G6Menu');
        });
        
        _this.skip = _this.add.image(870, 490, 'skipArrow');       //* skip button shown at the bottom
        _this.skip.inputEnabled = true;
        _this.skip.input.useHandCursor = true;
        _this.skip.events.onInputDown.add(function ()
        {
            _this.clickSound.play();
            _this.stopVideo();
            _this.state.start('NS_FM_1_G6level1');
        });
    },
    
    //* function to stop the video and audio if they are playing.
    stopVideo: function()
    {
        if (_this.video_playing == 1)
        {
            _this.demoVideo_1.stop(false);
            _this.demoVideo_1.destroy();
            _this.demoAudio1.pause();
        }
        else if (_this.video_playing == 2)
        {
            _this.demoVideo_2.stop(false);
            _this.demoVideo_2.destroy();
            _this.q1Sound.pause();            
        }
        else if (_this.video_playing == 3)
        {
            _this.demoVideo_3.stop(false);
            _this.demoVideo_3.destroy();
            _this.q2Sound.pause();
        }
        _this.demoAudio1.pause();   _this.demoAudio1 = null;
        _this.demoAudio2.pause();   _this.demoAudio2 = null;
        _this.demoAudio3.pause();   _this.demoAudio3 = null;
        _this.q1Sound.pause();      _this.q1Sound    = null;
        _this.q2Sound.pause();      _this.q2Sound    = null;
        _this.q3Sound.pause();      _this.q3Sound    = null;
        _this.q4Sound.pause();      _this.q4Sound    = null;
        _this.q5Sound.pause();      _this.q5Sound    = null;
        _this.time.events.removeAll();
        _this.backbtn.events.onInputDown.removeAll();
        _this.skip.events.onInputDown.removeAll();
    },
    
    //* video_1 is concept explanation uses demoaudio1, demoaudio2.
    //* video_2 is fm_1 game. uses question1, question2, demoaudio3, question3 (Questions from FM1 game)
    //* video_3 is fm_2 game. uses question4 and question 5 (Questions from FM2 game)
    //* video1 - 5s;  demoaudio1 - 4s;  demoaudio2 - 10s.
    //* video2 - 21s; q1 - 2s, q2 - 3s, q3 - 1s, demoaudio3 - 7s
    //* video3 - 23s; q4 - 3s;  q5 - 3s
    
    showDemoVideo: function()
    {                              
        _this.demoVideo_1 = _this.add.video('fm_1_1');
        _this.demoVideo_1.play(false);
        _this.demoVideo_1.changeSource("demoVideos/NS-FM-1-G6_1.mp4");
        _this.video_playing = 1;        
        _this.demoVideo_1.addToWorld();
        
        _this.time.events.add(800, function() {_this.demoAudio1.play()}); //* give bit delay for video to start playing
        
        _this.time.events.add(3000, function()       //* pause video after 3 seconds to show rectangle box 
        {
            console.log("3sec - executing pause of video1");
            _this.demoVideo_1.paused = true;
        });
                              
        _this.demoAudio1.addEventListener('ended', function()     //* after audio1 completion
        {
            console.log("audi1 ended - executing un-pause of video1");
            _this.demoVideo_1.paused = false;                //* let video play now (for 1 second)
            _this.demoAudio2.play();                         //* start audio 2.
            _this.time.events.add(2500, function()           //* pause video after 2.5sec while showing rect box
            {
                console.log("2.5sec - executing pause of video1");
                _this.demoVideo_1.paused = true;
            });
        });
            
        _this.demoVideo_2 = _this.add.video('fm_1_2');
        
        _this.demoAudio2.addEventListener('ended', function()   //*after audio2 is over, start 2nd video.
        {
            console.log("audio2 ended - pause video1");
            _this.demoVideo_2.play(false);
            _this.demoVideo_2.changeSource("demoVideos/NS-FM-1-G6_2.mp4");  //* phaser needs this.to run in mobile
            _this.video_playing = 2;
            _this.demoVideo_2.addToWorld();
            _this.backbtn.bringToTop();               //* bring backbtn and skip to top.
            _this.skip.bringToTop(); 
            
            //* ask 1st question here.bit delay for video to pl.
            _this.time.events.add(800, function() {_this.q1Sound.play()}); 
            
            _this.time.events.add(1500, function()           //* pause video after 1.5sec for Question to complete
            {
                console.log("1.5sec - executing pause of video2");
                _this.demoVideo_2.paused = true;
            });
        });
         
        _this.q1Sound.addEventListener('ended', function()
        {
            console.log("Q1 over - executing un-pause of video2");
            _this.demoVideo_2.paused = false;
 
            _this.time.events.add(8500, function()           //* after 8 seconds, ask 2nd question. pause video2
            {
                _this.demoVideo_2.paused = true;    
                console.log("1.5sec - executing pause of video2");
                _this.q2Sound.play();
            });
            
        });
        
        _this.q2Sound.addEventListener('ended', function()   //* after q2 is done
        {
            _this.demoVideo_2.paused = false;          //* continue the video
            _this.demoAudio3.play();                  //* play 3rd audio which shows full rectangle
            _this.time.events.add(8100, function()
            {
                _this.q3Sound.play();
            });
        });
        
        _this.demoVideo_3 = _this.add.video('fm_1_3');   //* add the video 3
        
        _this.demoVideo_2.onComplete.add(function()
        {
            console.log("completing video 2, playing v3");
            
            _this.demoVideo_3.play(false);        //* start playing video3 of fm2 game
            _this.demoVideo_3.changeSource("demoVideos/NS-FM-1-G6_3.mp4");
            _this.video_playing = 3;
            _this.demoVideo_3.addToWorld();
            
            //* ask let us find if given options are factors.
            _this.time.events.add(800, function() {_this.q4Sound.play()});  
            
            _this.time.events.add(2000, function()   //* pause the video after 2 seconds
            {
                _this.demoVideo_3.paused = true; 
            });

            _this.backbtn.bringToTop();
            _this.skip.bringToTop();
        });
       
        _this.q4Sound.addEventListener('ended', function()   //* after q4 is done
        {
            _this.demoVideo_3.paused = false;     //* unpause the video3, let it play for 5 seconds
            _this.time.events.add(5000, function()
            {
                _this.demoVideo_3.paused = true;
                _this.q5Sound.play();           //* ask if the given option is a factor.
            });
        });
        
        _this.q5Sound.addEventListener('ended', function()   //* after q5 is done
        {
            _this.demoVideo_3.paused = false;   //* let the video continue till the end
        });
        
        _this.demoVideo_3.onComplete.add(function()  //* after video3 is done, start the game
        {
            console.log("v3 over trigger the game");

            _this.backbtn.events.onInputDown.removeAll();
            _this.skip.events.onInputDown.removeAll();
            _this.demoAudio1.pause();   _this.demoAudio1 = null;
            _this.demoAudio2.pause();   _this.demoAudio2 = null;
            _this.demoAudio3.pause();   _this.demoAudio3 = null;
            _this.q1Sound.pause();      _this.q1Sound    = null;
            _this.q2Sound.pause();      _this.q2Sound    = null;
            _this.q3Sound.pause();      _this.q3Sound    = null;
            _this.q4Sound.pause();      _this.q4Sound    = null;
            _this.q5Sound.pause();      _this.q5Sound    = null;
            _this.state.start('NS_FM_1_G6level1');
        });
    },
}

//* video related commands     
//        this.video.changeSource("assets/demoVideos/7_1_1.mp4");
//        this.video.addToWorld();
//        this.video2.stop(false);
//        this.video2.onComplete.add(function() {}
//        this.video3.playbackRate = 1;  
//        this.video1 = this.add.video('demo7_1_1');
//        document.getElementById('phaser_canvas').style.pointerEvents = "none";
//
//        this.video1.play(false);
//        this.video1.changeSource(window.baseUrl+"assets/demoVideos/7_2_1.mp4");
//        this.video1.addToWorld();
//        this.video1.play(false);
//        
//        document.getElementById('phaser_canvas').style.pointerEvents = "initial";


//            this.videoLevel2 = this.add.video('demo');
//        this.videoLevel2.play(false);
//        this.videoLevel2.changeSource(window.baseUrl+"assets/demoVideos/7_2_2.mp4");
//        _this.something1 =  this.videoLevel2.addToWorld();
