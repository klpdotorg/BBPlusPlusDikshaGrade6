var NSRP_01_G6_JSON = {

	starAnimJson: {
		"frames": [

			{
				"filename": "Symbol 10 copy instance 10000",
				"frame": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10001",
				"frame": { "x": 0, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10002",
				"frame": { "x": 0, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10003",
				"frame": { "x": 0, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10004",
				"frame": { "x": 33, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10005",
				"frame": { "x": 33, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10006",
				"frame": { "x": 33, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10007",
				"frame": { "x": 33, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10008",
				"frame": { "x": 66, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10009",
				"frame": { "x": 66, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10010",
				"frame": { "x": 66, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10011",
				"frame": { "x": 66, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10012",
				"frame": { "x": 99, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10013",
				"frame": { "x": 99, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10014",
				"frame": { "x": 99, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10015",
				"frame": { "x": 99, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10016",
				"frame": { "x": 132, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10017",
				"frame": { "x": 132, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10018",
				"frame": { "x": 132, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10019",
				"frame": { "x": 132, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10020",
				"frame": { "x": 165, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10021",
				"frame": { "x": 165, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10022",
				"frame": { "x": 165, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10023",
				"frame": { "x": 165, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10024",
				"frame": { "x": 198, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10025",
				"frame": { "x": 198, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10026",
				"frame": { "x": 198, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10027",
				"frame": { "x": 198, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10028",
				"frame": { "x": 231, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10029",
				"frame": { "x": 231, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10030",
				"frame": { "x": 231, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10031",
				"frame": { "x": 231, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10032",
				"frame": { "x": 264, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10033",
				"frame": { "x": 264, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10034",
				"frame": { "x": 264, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10035",
				"frame": { "x": 264, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "st.png",
			"format": "RGB8",
			"size": { "w": 334, "h": 479 },
			"scale": "1"
		}
	},

	speakerJson: {
		"frames": [

			{
				"filename": "Symbol 5 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 41, "h": 30 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 41, "h": 30 },
				"sourceSize": { "w": 41, "h": 30 }
			},
			{
				"filename": "Symbol 5 instance 10001",
				"frame": { "x": 0, "y": 30, "w": 41, "h": 30 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 41, "h": 30 },
				"sourceSize": { "w": 41, "h": 30 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "s.png",
			"format": "RGB8",
			"size": { "w": 44, "h": 64 },
			"scale": "1"
		}
	},

	btnJson: {
		"frames": [

			{
				"filename": "Symbol 1 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 212, "h": 71 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 212, "h": 71 },
				"sourceSize": { "w": 212, "h": 71 }
			}
			, {
				"filename": "Symbol 1 instance 10001",
				"frame": { "x": 0, "y": 71, "w": 212, "h": 71 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 212, "h": 71 },
				"sourceSize": { "w": 212, "h": 71 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "16.5.1.104",
			"image": "b1.png",
			"format": "RGB8",
			"size": { "w": 213, "h": 144 },
			"scale": "1"
		}
	},

	replyJson: {
		"frames": [

			{
				"filename": "Symbol 8 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"sourceSize": { "w": 47, "h": 47 }
			}
			, {
				"filename": "Symbol 8 instance 10001",
				"frame": { "x": 47, "y": 0, "w": 47, "h": 47 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"sourceSize": { "w": 47, "h": 47 }
			}
			, {
				"filename": "Symbol 8 instance 10002",
				"frame": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"sourceSize": { "w": 47, "h": 47 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "Back btn.png",
			"format": "RGBA8888",
			"size": { "w": 98, "h": 48 },
			"scale": "1"
		}
	},

	backbtnJson: {
		"frames": [

			{
				"filename": "Symbol 9 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 41, "h": 29 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 41, "h": 29 },
				"sourceSize": { "w": 41, "h": 29 }
			}
			, {
				"filename": "Symbol 9 instance 10001",
				"frame": { "x": 0, "y": 29, "w": 41, "h": 29 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 41, "h": 29 },
				"sourceSize": { "w": 41, "h": 29 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "back.png",
			"format": "RGB8",
			"size": { "w": 44, "h": 64 },
			"scale": "1"
		}
	},

	tickJson: {
		"frames": [

			{
				"filename": "Symbol 10 copy instance 10000",
				"frame": { "x": 0, "y": 0, "w": 68, "h": 66 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 66 },
				"sourceSize": { "w": 68, "h": 66 }
			}
			, {
				"filename": "Symbol 10 copy instance 10001",
				"frame": { "x": 68, "y": 0, "w": 68, "h": 66 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 66 },
				"sourceSize": { "w": 68, "h": 66 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "20.0.1.19255",
			"image": "Right btn0002.png",
			"format": "RGBA8888",
			"size": { "w": 138, "h": 66 },
			"scale": "1"
		}
	},

	nextbtnJson: {
		"frames": [

			{
				"filename": "Symbol 6 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 59, "h": 60 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 59, "h": 60 },
				"sourceSize": { "w": 59, "h": 60 }
			}
			, {
				"filename": "Symbol 6 instance 10001",
				"frame": { "x": 0, "y": 60, "w": 59, "h": 60 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 59, "h": 60 },
				"sourceSize": { "w": 59, "h": 60 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.1.115",
			"image": "N.png",
			"format": "RGB8",
			"size": { "w": 64, "h": 128 },
			"scale": "1"
		}
	},
	homebtnJson: {
		"frames": [

			{
				"filename": "Symbol 4 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 60, "h": 60 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 60, "h": 60 },
				"sourceSize": { "w": 60, "h": 60 }
			}
			, {
				"filename": "Symbol 4 instance 10001",
				"frame": { "x": 0, "y": 60, "w": 60, "h": 60 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 60, "h": 60 },
				"sourceSize": { "w": 60, "h": 60 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.1.115",
			"image": "H.png",
			"format": "RGB8",
			"size": { "w": 64, "h": 128 },
			"scale": "1"
		}

	},

	TickbtnJson: {
		"frames": [

			{
				"filename": "Symbol 10 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 67, "h": 68 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 67, "h": 68 },
				"sourceSize": { "w": 67, "h": 68 }
			}
			, {
				"filename": "Symbol 10 instance 10001",
				"frame": { "x": 67, "y": 0, "w": 67, "h": 68 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 67, "h": 68 },
				"sourceSize": { "w": 67, "h": 68 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "20.0.1.19255",
			"image": "NSRP-01-G6.png",
			"format": "RGBA8888",
			"size": { "w": 134, "h": 68 },
			"scale": "1"
		}
	},

	SquareBoxJson: {
		"frames": [

			{
				"filename": "Symbol 5 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 55, "h": 54 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 55, "h": 54 },
				"sourceSize": { "w": 55, "h": 54 }
			}
			, {
				"filename": "Symbol 5 instance 10001",
				"frame": { "x": 55, "y": 0, "w": 55, "h": 54 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 55, "h": 54 },
				"sourceSize": { "w": 55, "h": 54 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "20.0.1.19255",
			"image": "NSF-2B-G6 new box.png",
			"format": "RGBA8888",
			"size": { "w": 110, "h": 54 },
			"scale": "1"
		}
	},

	textbox1: {
		"frames": [

			{
				"filename": "Symbol 2 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 255, "h": 81 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 255, "h": 81 },
				"sourceSize": { "w": 255, "h": 81 }
			}
			, {
				"filename": "Symbol 2 instance 10001",
				"frame": { "x": 255, "y": 0, "w": 255, "h": 81 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 255, "h": 81 },
				"sourceSize": { "w": 255, "h": 81 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "text box_1.png",
			"format": "RGBA8888",
			"size": { "w": 510, "h": 81 },
			"scale": "1"
		}
	},
	textbox2: {
		"frames": [

			{
				"filename": "Symbol 1 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 125, "h": 81 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 125, "h": 81 },
				"sourceSize": { "w": 125, "h": 81 }
			}
			, {
				"filename": "Symbol 1 instance 10001",
				"frame": { "x": 125, "y": 0, "w": 125, "h": 81 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 125, "h": 81 },
				"sourceSize": { "w": 125, "h": 81 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "text box_2.png",
			"format": "RGBA8888",
			"size": { "w": 250, "h": 81 },
			"scale": "1"
		}
	},
	// 1.1 sprites
	image1_11: {
		"frames": [

			{
				"filename": "Symbol 1 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}
			, {
				"filename": "Symbol 1 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_1.1.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 261 },
			"scale": "1"
		}
	},
	image1_12: {
		"frames": [

			{
				"filename": "Symbol 2 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}
			, {
				"filename": "Symbol 2 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_1.2.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 261 },
			"scale": "1"
		}
	},
	image1_13: {
		"frames": [

			{
				"filename": "Symbol 3 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}
			, {
				"filename": "Symbol 3 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_1.3.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 261 },
			"scale": "1"
		}
	},
	image1_21: {
		"frames": [

			{
				"filename": "Symbol 4 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 4 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_2.1.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image1_22: {
		"frames": [

			{
				"filename": "Symbol 5 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 5 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_2.2.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image1_23: {
		"frames": [

			{
				"filename": "Symbol 6 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 6 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_2.3.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},

	image1_31: {
		"frames": [

			{
				"filename": "Symbol 7 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 7 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_3.1.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image1_32: {
		"frames": [

			{
				"filename": "Symbol 8 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}
			, {
				"filename": "Symbol 8 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_3.2.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image1_33: {
		"frames": [

			{
				"filename": "Symbol 9 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}
			, {
				"filename": "Symbol 9 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_3.3.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image1_41: {
		"frames": [

			{
				"filename": "Symbol 10 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}
			, {
				"filename": "Symbol 10 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_4.1.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image1_42: {
		"frames": [

			{
				"filename": "Symbol 11 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}
			, {
				"filename": "Symbol 11 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_4.2.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image1_43: {
		"frames": [

			{
				"filename": "Symbol 12 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}
			, {
				"filename": "Symbol 12 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_4.3.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image1_51: {
		"frames": [

			{
				"filename": "Symbol 13 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}
			, {
				"filename": "Symbol 13 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_5.1.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image1_52: {
		"frames": [

			{
				"filename": "Symbol 14 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}
			, {
				"filename": "Symbol 14 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_5.2.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image1_53: {
		"frames": [

			{
				"filename": "Symbol 15 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}
			, {
				"filename": "Symbol 15 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_5.3.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image1_61: {
		"frames": [

			{
				"filename": "Symbol 16 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}
			, {
				"filename": "Symbol 16 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_6.1.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image1_62: {
		"frames": [

			{
				"filename": "Symbol 17 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}
			, {
				"filename": "Symbol 17 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_6.2.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image1_63: {
		"frames": [

			{
				"filename": "Symbol 18 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}
			, {
				"filename": "Symbol 18 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_6.3.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image1_71: {
		"frames": [

			{
				"filename": "Symbol 19 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 19 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_7.1.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image1_72: {
		"frames": [

			{
				"filename": "Symbol 20 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 20 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_7.2.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image1_73: {
		"frames": [

			{
				"filename": "Symbol 21 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 21 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_7.3.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image1_81: {
		"frames": [

			{
				"filename": "Symbol 22 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 22 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_8.1.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image1_82: {
		"frames": [

			{
				"filename": "Symbol 23 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 23 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_8.2.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image1_83: {
		"frames": [

			{
				"filename": "Symbol 24 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 24 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_8.3.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},


	// 1.2

	image2_11: {
		"frames": [

			{
				"filename": "Symbol 1 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 1 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Pic_1.1.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image2_12: {
		"frames": [

			{
				"filename": "Symbol 2 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 205, "h": 218 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 205, "h": 218 },
				"sourceSize": { "w": 205, "h": 218 }
			}
			, {
				"filename": "Symbol 2 instance 10001",
				"frame": { "x": 205, "y": 0, "w": 205, "h": 218 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 205, "h": 218 },
				"sourceSize": { "w": 205, "h": 218 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_1.2.png",
			"format": "RGBA8888",
			"size": { "w": 410, "h": 219 },
			"scale": "1"
		}
	},
	image2_13: {
		"frames": [

			{
				"filename": "Symbol 3 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 3 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Pic_1.3.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image2_21: {
		"frames": [

			{
				"filename": "Symbol 4 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 4 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Pic_2.1.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image2_22: {
		"frames": [

			{
				"filename": "Symbol 5 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 173, "h": 184 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 173, "h": 184 },
				"sourceSize": { "w": 173, "h": 184 }
			}
			, {
				"filename": "Symbol 5 instance 10001",
				"frame": { "x": 173, "y": 0, "w": 173, "h": 184 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 173, "h": 184 },
				"sourceSize": { "w": 173, "h": 184 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_2.2.png",
			"format": "RGBA8888",
			"size": { "w": 347, "h": 189 },
			"scale": "1"
		}
	}
	,
	image2_23: {
		"frames": [

			{
				"filename": "Symbol 6 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 6 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Pic_2.3.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image2_31: {
		"frames": [

			{
				"filename": "Symbol 7 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 7 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Pic_3.1.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image2_32: {
		"frames": [

			{
				"filename": "Symbol 8 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 172, "h": 183 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 172, "h": 183 },
				"sourceSize": { "w": 172, "h": 183 }
			}
			, {
				"filename": "Symbol 8 instance 10001",
				"frame": { "x": 172, "y": 0, "w": 172, "h": 183 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 172, "h": 183 },
				"sourceSize": { "w": 172, "h": 183 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_3.2.png",
			"format": "RGBA8888",
			"size": { "w": 347, "h": 189 },
			"scale": "1"
		}
	}
	,
	image2_33: {
		"frames": [

			{
				"filename": "Symbol 9 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 9 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Pic_3.3.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image2_41: {
		"frames": [

			{
				"filename": "Symbol 10 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 10 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Pic_4.1.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image2_42: {
		"frames": [

			{
				"filename": "Symbol 11 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 164, "h": 174 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 164, "h": 174 },
				"sourceSize": { "w": 164, "h": 174 }
			}
			, {
				"filename": "Symbol 11 instance 10001",
				"frame": { "x": 164, "y": 0, "w": 164, "h": 174 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 164, "h": 174 },
				"sourceSize": { "w": 164, "h": 174 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_4.2.png",
			"format": "RGBA8888",
			"size": { "w": 331, "h": 176 },
			"scale": "1"
		}
	}
	,
	image2_43: {
		"frames": [

			{
				"filename": "Symbol 12 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 12 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Pic_4.3.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image2_51: {
		"frames": [

			{
				"filename": "Symbol 13 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 13 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Pic_5.1.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image2_52: {
		"frames": [

			{
				"filename": "Symbol 14 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 176, "h": 187 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 176, "h": 187 },
				"sourceSize": { "w": 176, "h": 187 }
			}
			, {
				"filename": "Symbol 14 instance 10001",
				"frame": { "x": 176, "y": 0, "w": 176, "h": 187 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 176, "h": 187 },
				"sourceSize": { "w": 176, "h": 187 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_5.2.png",
			"format": "RGBA8888",
			"size": { "w": 352, "h": 187 },
			"scale": "1"
		}
	}
	,
	image2_53: {
		"frames": [

			{
				"filename": "Symbol 15 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 15 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Pic_5.3.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image2_61: {
		"frames": [

			{
				"filename": "Symbol 16 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 16 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Pic_6.1.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image2_62: {
		"frames": [

			{
				"filename": "Symbol 17 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 179, "h": 190 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 179, "h": 190 },
				"sourceSize": { "w": 179, "h": 190 }
			}
			, {
				"filename": "Symbol 17 instance 10001",
				"frame": { "x": 179, "y": 0, "w": 179, "h": 190 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 179, "h": 190 },
				"sourceSize": { "w": 179, "h": 190 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_6.2.png",
			"format": "RGBA8888",
			"size": { "w": 362, "h": 194 },
			"scale": "1"
		}
	}
	,
	image2_63: {
		"frames": [

			{
				"filename": "Symbol 18 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 18 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Pic_6.3.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image2_71: {
		"frames": [

			{
				"filename": "Symbol 19 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 19 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Pic_7.1.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image2_72: {
		"frames": [

			{
				"filename": "Symbol 20 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 179, "h": 189 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 179, "h": 189 },
				"sourceSize": { "w": 179, "h": 189 }
			}
			, {
				"filename": "Symbol 20 instance 10001",
				"frame": { "x": 179, "y": 0, "w": 179, "h": 189 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 179, "h": 189 },
				"sourceSize": { "w": 179, "h": 189 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_7.2.png",
			"format": "RGBA8888",
			"size": { "w": 360, "h": 191 },
			"scale": "1"
		}
	}
	,
	image2_73: {
		"frames": [

			{
				"filename": "Symbol 21 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 21 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Pic_7.3.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image2_81: {
		"frames": [

			{
				"filename": "Symbol 22 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 22 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Pic_8.1.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image2_82: {
		"frames": [

			{
				"filename": "Symbol 23 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 175, "h": 185 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 175, "h": 185 },
				"sourceSize": { "w": 175, "h": 185 }
			}
			, {
				"filename": "Symbol 23 instance 10001",
				"frame": { "x": 175, "y": 0, "w": 175, "h": 185 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 175, "h": 185 },
				"sourceSize": { "w": 175, "h": 185 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_8.2.png",
			"format": "RGBA8888",
			"size": { "w": 350, "h": 187 },
			"scale": "1"
		}
	}
	,
	image2_83: {
		"frames": [

			{
				"filename": "Symbol 24 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 24 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Pic_8.3.png",
			"format": "RGBA8888",
			"size": { "w": 497, "h": 262 },
			"scale": "1"
		}
	},

	// 1.3

	image3_11: {
		"frames": [

			{
				"filename": "Symbol 1 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 246, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 246, "h": 261 },
				"sourceSize": { "w": 246, "h": 261 }
			}
			, {
				"filename": "Symbol 1 instance 10001",
				"frame": { "x": 246, "y": 0, "w": 246, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 246, "h": 261 },
				"sourceSize": { "w": 246, "h": 261 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_1.1.png",
			"format": "RGBA8888",
			"size": { "w": 497, "h": 262 },
			"scale": "1"
		}
	},
	image3_12: {
		"frames": [

			{
				"filename": "Symbol 2 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 205, "h": 218 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 205, "h": 218 },
				"sourceSize": { "w": 205, "h": 218 }
			}
			, {
				"filename": "Symbol 2 instance 10001",
				"frame": { "x": 205, "y": 0, "w": 205, "h": 218 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 205, "h": 218 },
				"sourceSize": { "w": 205, "h": 218 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_1.2.png",
			"format": "RGBA8888",
			"size": { "w": 410, "h": 219 },
			"scale": "1"
		}
	},
	image3_13: {
		"frames": [

			{
				"filename": "Symbol 3 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 246, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 246, "h": 261 },
				"sourceSize": { "w": 246, "h": 261 }
			}
			, {
				"filename": "Symbol 3 instance 10001",
				"frame": { "x": 246, "y": 0, "w": 246, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 246, "h": 261 },
				"sourceSize": { "w": 246, "h": 261 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_1.3.png",
			"format": "RGBA8888",
			"size": { "w": 496, "h": 288 },
			"scale": "1"
		}
	},
	image3_21: {
		"frames": [

			{
				"filename": "Symbol 4 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 4 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_2.1.png",
			"format": "RGBA8888",
			"size": { "w": 496, "h": 288 },
			"scale": "1"
		}
	},
	image3_22: {
		"frames": [

			{
				"filename": "Symbol 5 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 173, "h": 184 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 173, "h": 184 },
				"sourceSize": { "w": 173, "h": 184 }
			}
			, {
				"filename": "Symbol 5 instance 10001",
				"frame": { "x": 173, "y": 0, "w": 173, "h": 184 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 173, "h": 184 },
				"sourceSize": { "w": 173, "h": 184 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_2.2.png",
			"format": "RGBA8888",
			"size": { "w": 347, "h": 189 },
			"scale": "1"
		}
	},
	image3_23: {
		"frames": [

			{
				"filename": "Symbol 6 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 6 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_2.3.png",
			"format": "RGBA8888",
			"size": { "w": 496, "h": 288 },
			"scale": "1"
		}
	},
	image3_31: {
		"frames": [

			{
				"filename": "Symbol 7 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 7 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_3.1.png",
			"format": "RGBA8888",
			"size": { "w": 496, "h": 263 },
			"scale": "1"
		}
	},
	image3_32: {
		"frames": [

			{
				"filename": "Symbol 8 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 172, "h": 183 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 172, "h": 183 },
				"sourceSize": { "w": 172, "h": 183 }
			}
			, {
				"filename": "Symbol 8 instance 10001",
				"frame": { "x": 172, "y": 0, "w": 172, "h": 183 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 172, "h": 183 },
				"sourceSize": { "w": 172, "h": 183 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_3.2.png",
			"format": "RGBA8888",
			"size": { "w": 347, "h": 189 },
			"scale": "1"
		}
	},
	image3_33: {
		"frames": [

			{
				"filename": "Symbol 9 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 9 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_3.3.png",
			"format": "RGBA8888",
			"size": { "w": 496, "h": 263 },
			"scale": "1"
		}
	},
	image3_41: {
		"frames": [

			{
				"filename": "Symbol 10 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}
			, {
				"filename": "Symbol 10 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_4.1.png",
			"format": "RGBA8888",
			"size": { "w": 494, "h": 276 },
			"scale": "1"
		}
	},
	image3_42: {
		"frames": [

			{
				"filename": "Symbol 11 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 164, "h": 174 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 164, "h": 174 },
				"sourceSize": { "w": 164, "h": 174 }
			}
			, {
				"filename": "Symbol 11 instance 10001",
				"frame": { "x": 164, "y": 0, "w": 164, "h": 174 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 164, "h": 174 },
				"sourceSize": { "w": 164, "h": 174 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_4.2.png",
			"format": "RGBA8888",
			"size": { "w": 331, "h": 176 },
			"scale": "1"
		}
	},
	image3_43: {
		"frames": [

			{
				"filename": "Symbol 12 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}
			, {
				"filename": "Symbol 12 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_4.3.png",
			"format": "RGBA8888",
			"size": { "w": 494, "h": 276 },
			"scale": "1"
		}
	},
	image3_51: {
		"frames": [

			{
				"filename": "Symbol 13 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 13 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_5.1.png",
			"format": "RGBA8888",
			"size": { "w": 494, "h": 268 },
			"scale": "1"
		}
	},
	image3_52: {
		"frames": [

			{
				"filename": "Symbol 14 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 176, "h": 187 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 176, "h": 187 },
				"sourceSize": { "w": 176, "h": 187 }
			}
			, {
				"filename": "Symbol 14 instance 10001",
				"frame": { "x": 176, "y": 0, "w": 176, "h": 187 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 176, "h": 187 },
				"sourceSize": { "w": 176, "h": 187 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_5.2.png",
			"format": "RGBA8888",
			"size": { "w": 352, "h": 187 },
			"scale": "1"
		}
	},
	image3_53: {
		"frames": [

			{
				"filename": "Symbol 15 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 15 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_5.3.png",
			"format": "RGBA8888",
			"size": { "w": 494, "h": 268 },
			"scale": "1"
		}
	},
	image3_61: {
		"frames": [

			{
				"filename": "Symbol 16 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 248, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 248, "h": 262 },
				"sourceSize": { "w": 248, "h": 262 }
			}
			, {
				"filename": "Symbol 16 instance 10001",
				"frame": { "x": 248, "y": 0, "w": 248, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 248, "h": 262 },
				"sourceSize": { "w": 248, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_6.1.png",
			"format": "RGBA8888",
			"size": { "w": 500, "h": 264 },
			"scale": "1"
		}
	},
	image3_62: {
		"frames": [

			{
				"filename": "Symbol 17 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 179, "h": 190 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 179, "h": 190 },
				"sourceSize": { "w": 179, "h": 190 }
			}
			, {
				"filename": "Symbol 17 instance 10001",
				"frame": { "x": 179, "y": 0, "w": 179, "h": 190 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 179, "h": 190 },
				"sourceSize": { "w": 179, "h": 190 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_6.2.png",
			"format": "RGBA8888",
			"size": { "w": 362, "h": 194 },
			"scale": "1"
		}
	},
	image3_63: {
		"frames": [

			{
				"filename": "Symbol 18 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 18 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_6.3.png",
			"format": "RGBA8888",
			"size": { "w": 500, "h": 264 },
			"scale": "1"
		}
	},
	image3_71: {
		"frames": [

			{
				"filename": "Symbol 19 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 248, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 248, "h": 261 },
				"sourceSize": { "w": 248, "h": 261 }
			}
			, {
				"filename": "Symbol 19 instance 10001",
				"frame": { "x": 248, "y": 0, "w": 248, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 248, "h": 261 },
				"sourceSize": { "w": 248, "h": 261 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_7.1.png",
			"format": "RGBA8888",
			"size": { "w": 501, "h": 262 },
			"scale": "1"
		}
	},
	image3_72: {
		"frames": [

			{
				"filename": "Symbol 20 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 179, "h": 189 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 179, "h": 189 },
				"sourceSize": { "w": 179, "h": 189 }
			}
			, {
				"filename": "Symbol 20 instance 10001",
				"frame": { "x": 179, "y": 0, "w": 179, "h": 189 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 179, "h": 189 },
				"sourceSize": { "w": 179, "h": 189 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_7.2.png",
			"format": "RGBA8888",
			"size": { "w": 360, "h": 191 },
			"scale": "1"
		}
	},
	image3_73: {
		"frames": [

			{
				"filename": "Symbol 21 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}
			, {
				"filename": "Symbol 21 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_7.3.png",
			"format": "RGBA8888",
			"size": { "w": 501, "h": 262 },
			"scale": "1"
		}
	},
	image3_81: {
		"frames": [

			{
				"filename": "Symbol 22 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 248, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 248, "h": 262 },
				"sourceSize": { "w": 248, "h": 262 }
			}
			, {
				"filename": "Symbol 22 instance 10001",
				"frame": { "x": 248, "y": 0, "w": 248, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 248, "h": 262 },
				"sourceSize": { "w": 248, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_8.1.png",
			"format": "RGBA8888",
			"size": { "w": 497, "h": 262 },
			"scale": "1"
		}
	},
	image3_82: {
		"frames": [

			{
				"filename": "Symbol 23 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 175, "h": 185 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 175, "h": 185 },
				"sourceSize": { "w": 175, "h": 185 }
			}
			, {
				"filename": "Symbol 23 instance 10001",
				"frame": { "x": 175, "y": 0, "w": 175, "h": 185 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 175, "h": 185 },
				"sourceSize": { "w": 175, "h": 185 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_8.2.png",
			"format": "RGBA8888",
			"size": { "w": 350, "h": 187 },
			"scale": "1"
		}
	},
	image3_83: {
		"frames": [

			{
				"filename": "Symbol 24 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 24 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Image_8.3.png",
			"format": "RGBA8888",
			"size": { "w": 497, "h": 262 },
			"scale": "1"
		}
	},
	// 1.4
	image4_11: {
		"frames": [

			{
				"filename": "Symbol 2 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 206, "h": 218 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 206, "h": 218 },
				"sourceSize": { "w": 206, "h": 218 }
			}
			, {
				"filename": "Symbol 2 instance 10001",
				"frame": { "x": 206, "y": 0, "w": 206, "h": 218 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 206, "h": 218 },
				"sourceSize": { "w": 206, "h": 218 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "PC_1.2.png",
			"format": "RGBA8888",
			"size": { "w": 413, "h": 219 },
			"scale": "1"
		}
	},
	image4_12: {
		"frames": [

			{
				"filename": "Symbol 2 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}
			, {
				"filename": "Symbol 2 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_1.2.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 261 },
			"scale": "1"
		}
	}

	,
	image4_13: {
		"frames": [

			{
				"filename": "Symbol 1 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 246, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 246, "h": 261 },
				"sourceSize": { "w": 246, "h": 261 }
			}
			, {
				"filename": "Symbol 1 instance 10001",
				"frame": { "x": 246, "y": 0, "w": 246, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 246, "h": 261 },
				"sourceSize": { "w": 246, "h": 261 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "PC_1.3.png",
			"format": "RGBA8888",
			"size": { "w": 496, "h": 265 },
			"scale": "1"
		}
	},

	image4_21: {
		"frames": [

			{
				"filename": "Symbol 5 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 173, "h": 184 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 173, "h": 184 },
				"sourceSize": { "w": 173, "h": 184 }
			}
			, {
				"filename": "Symbol 5 instance 10001",
				"frame": { "x": 173, "y": 0, "w": 173, "h": 184 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 173, "h": 184 },
				"sourceSize": { "w": 173, "h": 184 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "PC_2.2.png",
			"format": "RGBA8888",
			"size": { "w": 346, "h": 187 },
			"scale": "1"
		}
	},
	image4_22: {
		"frames": [

			{
				"filename": "Symbol 5 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 5 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_2.2.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image4_23: {
		"frames": [

			{
				"filename": "Symbol 6 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 6 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "PC_2.3.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image4_31: {
		"frames": [

			{
				"filename": "Symbol 8 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 172, "h": 183 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 172, "h": 183 },
				"sourceSize": { "w": 172, "h": 183 }
			}
			, {
				"filename": "Symbol 8 instance 10001",
				"frame": { "x": 172, "y": 0, "w": 172, "h": 183 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 172, "h": 183 },
				"sourceSize": { "w": 172, "h": 183 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "PC_3.2.png",
			"format": "RGBA8888",
			"size": { "w": 346, "h": 186 },
			"scale": "1"
		}
	},
	image4_32: {
		"frames": [

			{
				"filename": "Symbol 8 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}
			, {
				"filename": "Symbol 8 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_3.2.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},

	image4_33: {
		"frames": [

			{
				"filename": "Symbol 9 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}
			, {
				"filename": "Symbol 9 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "PC_3.3.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 267 },
			"scale": "1"
		}
	},

	image4_41: {
		"frames": [

			{
				"filename": "Symbol 11 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 164, "h": 174 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 164, "h": 174 },
				"sourceSize": { "w": 164, "h": 174 }
			}
			, {
				"filename": "Symbol 11 instance 10001",
				"frame": { "x": 164, "y": 0, "w": 164, "h": 174 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 164, "h": 174 },
				"sourceSize": { "w": 164, "h": 174 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "PC_4.2.png",
			"format": "RGBA8888",
			"size": { "w": 329, "h": 177 },
			"scale": "1"
		}
	},
	image4_42: {
		"frames": [

			{
				"filename": "Symbol 11 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}
			, {
				"filename": "Symbol 11 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_4.2.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image4_43: {
		"frames": [

			{
				"filename": "Symbol 12 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}
			, {
				"filename": "Symbol 12 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "PC_4.3.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 269 },
			"scale": "1"
		}
	},

	image4_51: {
		"frames": [

			{
				"filename": "Symbol 14 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 176, "h": 187 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 176, "h": 187 },
				"sourceSize": { "w": 176, "h": 187 }
			}
			, {
				"filename": "Symbol 14 instance 10001",
				"frame": { "x": 176, "y": 0, "w": 176, "h": 187 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 176, "h": 187 },
				"sourceSize": { "w": 176, "h": 187 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "PC_5.2.png",
			"format": "RGBA8888",
			"size": { "w": 352, "h": 192 },
			"scale": "1"
		}
	},
	image4_52: {
		"frames": [

			{
				"filename": "Symbol 14 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}
			, {
				"filename": "Symbol 14 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_5.2.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image4_53: {
		"frames": [

			{
				"filename": "Symbol 15 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 248, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 248, "h": 261 },
				"sourceSize": { "w": 248, "h": 261 }
			}
			, {
				"filename": "Symbol 15 instance 10001",
				"frame": { "x": 248, "y": 0, "w": 248, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 248, "h": 261 },
				"sourceSize": { "w": 248, "h": 261 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "PC_5.3.png",
			"format": "RGBA8888",
			"size": { "w": 497, "h": 267 },
			"scale": "1"
		}
	},
	image4_61: {
		"frames": [

			{
				"filename": "Symbol 17 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 179, "h": 189 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 179, "h": 189 },
				"sourceSize": { "w": 179, "h": 189 }
			}
			, {
				"filename": "Symbol 17 instance 10001",
				"frame": { "x": 179, "y": 0, "w": 179, "h": 189 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 179, "h": 189 },
				"sourceSize": { "w": 179, "h": 189 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "PC_6.2.png",
			"format": "RGBA8888",
			"size": { "w": 362, "h": 193 },
			"scale": "1"
		}
	},
	image4_62: {
		"frames": [

			{
				"filename": "Symbol 17 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}
			, {
				"filename": "Symbol 17 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 261 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 261 },
				"sourceSize": { "w": 247, "h": 261 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_6.2.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image4_63: {
		"frames": [

			{
				"filename": "Symbol 18 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 18 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "PC_6.3.png",
			"format": "RGBA8888",
			"size": { "w": 498, "h": 275 },
			"scale": "1"
		}
	},
	image4_71: {
		"frames": [

			{
				"filename": "Symbol 20 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 178, "h": 190 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 178, "h": 190 },
				"sourceSize": { "w": 178, "h": 190 }
			}
			, {
				"filename": "Symbol 20 instance 10001",
				"frame": { "x": 178, "y": 0, "w": 178, "h": 190 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 178, "h": 190 },
				"sourceSize": { "w": 178, "h": 190 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "PC_7.2.png",
			"format": "RGBA8888",
			"size": { "w": 357, "h": 195 },
			"scale": "1"
		}
	},
	image4_72: {
		"frames": [

			{
				"filename": "Symbol 20 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 20 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_7.2.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image4_73: {
		"frames": [

			{
				"filename": "Symbol 21 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 21 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "PC_7.3.png",
			"format": "RGBA8888",
			"size": { "w": 496, "h": 267 },
			"scale": "1"
		}
	},
	image4_81: {
		"frames": [

			{
				"filename": "Symbol 23 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 175, "h": 186 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 175, "h": 186 },
				"sourceSize": { "w": 175, "h": 186 }
			}
			, {
				"filename": "Symbol 23 instance 10001",
				"frame": { "x": 175, "y": 0, "w": 175, "h": 186 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 175, "h": 186 },
				"sourceSize": { "w": 175, "h": 186 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "PC_8.2.png",
			"format": "RGBA8888",
			"size": { "w": 351, "h": 188 },
			"scale": "1"
		}
	},
	image4_82: {
		"frames": [

			{
				"filename": "Symbol 23 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 23 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Photo_8.2.png",
			"format": "RGBA8888",
			"size": { "w": 495, "h": 262 },
			"scale": "1"
		}
	},
	image4_83: {
		"frames": [

			{
				"filename": "Symbol 24 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}
			, {
				"filename": "Symbol 24 instance 10001",
				"frame": { "x": 247, "y": 0, "w": 247, "h": 262 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 247, "h": 262 },
				"sourceSize": { "w": 247, "h": 262 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "PC_8.3.png",
			"format": "RGBA8888",
			"size": { "w": 494, "h": 265 },
			"scale": "1"
		}
	}

};

