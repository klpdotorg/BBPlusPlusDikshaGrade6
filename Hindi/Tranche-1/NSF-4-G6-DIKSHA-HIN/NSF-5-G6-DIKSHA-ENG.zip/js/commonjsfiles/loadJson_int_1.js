var game1Json = {

	starAnimJson : {"frames": [

		{
			"filename": "Symbol 10 copy instance 10000",
			"frame": {"x":0,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10001",
			"frame": {"x":0,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10002",
			"frame": {"x":0,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10003",
			"frame": {"x":0,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10004",
			"frame": {"x":33,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10005",
			"frame": {"x":33,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10006",
			"frame": {"x":33,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10007",
			"frame": {"x":33,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10008",
			"frame": {"x":66,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10009",
			"frame": {"x":66,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10010",
			"frame": {"x":66,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10011",
			"frame": {"x":66,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10012",
			"frame": {"x":99,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10013",
			"frame": {"x":99,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10014",
			"frame": {"x":99,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10015",
			"frame": {"x":99,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10016",
			"frame": {"x":132,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10017",
			"frame": {"x":132,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10018",
			"frame": {"x":132,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10019",
			"frame": {"x":132,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10020",
			"frame": {"x":165,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10021",
			"frame": {"x":165,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10022",
			"frame": {"x":165,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10023",
			"frame": {"x":165,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10024",
			"frame": {"x":198,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10025",
			"frame": {"x":198,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10026",
			"frame": {"x":198,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10027",
			"frame": {"x":198,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10028",
			"frame": {"x":231,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10029",
			"frame": {"x":231,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10030",
			"frame": {"x":231,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10031",
			"frame": {"x":231,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10032",
			"frame": {"x":264,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10033",
			"frame": {"x":264,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10034",
			"frame": {"x":264,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10035",
			"frame": {"x":264,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "st.png",
			"format": "RGB8",
			"size": {"w":334,"h":479},
			"scale": "1"
		}
		},
	speakerJson : {"frames": [

		{
			"filename": "Symbol 5 instance 10000",
			"frame": {"x":0,"y":0,"w":41,"h":30},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":41,"h":30},
			"sourceSize": {"w":41,"h":30}
		},
		{
			"filename": "Symbol 5 instance 10001",
			"frame": {"x":0,"y":30,"w":41,"h":30},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":41,"h":30},
			"sourceSize": {"w":41,"h":30}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "s.png",
			"format": "RGB8",
			"size": {"w":44,"h":64},
			"scale": "1"
		}
	},

	btnJson : {"frames": [

{
	"filename": "Symbol 1 instance 10000",
	"frame": {"x":0,"y":0,"w":212,"h":71},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":212,"h":71},
	"sourceSize": {"w":212,"h":71}
}
,{
	"filename": "Symbol 1 instance 10001",
	"frame": {"x":0,"y":71,"w":212,"h":71},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":212,"h":71},
	"sourceSize": {"w":212,"h":71}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "16.5.1.104",
	"image": "b1.png",
	"format": "RGB8",
	"size": {"w":213,"h":144},
	"scale": "1"
}
},

	replyJson : {"frames": [

{
	"filename": "Symbol 8 instance 10000",
	"frame": {"x":0,"y":0,"w":47,"h":47},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":47,"h":47},
	"sourceSize": {"w":47,"h":47}
}
,{
	"filename": "Symbol 8 instance 10001",
	"frame": {"x":47,"y":0,"w":47,"h":47},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":47,"h":47},
	"sourceSize": {"w":47,"h":47}
}
,{
	"filename": "Symbol 8 instance 10002",
	"frame": {"x":0,"y":0,"w":47,"h":47},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":47,"h":47},
	"sourceSize": {"w":47,"h":47}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "15.1.0.210",
	"image": "Back btn.png",
	"format": "RGBA8888",
	"size": {"w":98,"h":48},
	"scale": "1"
}
},

    backbtnJson : {"frames": [

		{
			"filename": "Symbol 9 instance 10000",
			"frame": {"x":0,"y":0,"w":41,"h":29},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":41,"h":29},
			"sourceSize": {"w":41,"h":29}
		}
		,{
			"filename": "Symbol 9 instance 10001",
			"frame": {"x":0,"y":29,"w":41,"h":29},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":41,"h":29},
			"sourceSize": {"w":41,"h":29}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "back.png",
			"format": "RGB8",
			"size": {"w":44,"h":64},
			"scale": "1"
		}
		},

    tickJson : {"frames": [

{
	"filename": "Symbol 14 copy instance 10000",
	"frame": {"x":0,"y":0,"w":58,"h":61},
	"rotated": false,
	"trimmed": true,
	"spriteSourceSize": {"x":0,"y":0,"w":64,"h":68},
	"sourceSize": {"w":64,"h":68}
}
,{
	"filename": "Symbol 14 copy instance 10001",
	"frame": {"x":58,"y":0,"w":59,"h":62},
	"rotated": false,
	"trimmed": true,
	"spriteSourceSize": {"x":5,"y":6,"w":64,"h":68},
	"sourceSize": {"w":64,"h":68}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "15.1.0.210",
	"image": "right btn.png",
	"format": "RGB8",
	"size": {"w":121,"h":62},
	"scale": "1"
}
},
    
jumpingWaterJson: {"frames": [
{
	"filename": "Symbol 4 instance 10000",
	"frame": {"x":0,"y":0,"w":65,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":65,"h":65},
	"sourceSize": {"w":65,"h":65}
}
,{
	"filename": "Symbol 4 instance 10001",
	"frame": {"x":65,"y":0,"w":65,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":65,"h":65},
	"sourceSize": {"w":65,"h":65}
}
,{
	"filename": "Symbol 4 instance 10002",
	"frame": {"x":130,"y":0,"w":65,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":65,"h":65},
	"sourceSize": {"w":65,"h":65}
}
,{
	"filename": "Symbol 4 instance 10003",
	"frame": {"x":195,"y":0,"w":65,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":65,"h":65},
	"sourceSize": {"w":65,"h":65}
}
,{
	"filename": "Symbol 4 instance 10004",
	"frame": {"x":260,"y":0,"w":65,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":65,"h":65},
	"sourceSize": {"w":65,"h":65}
}
,{
	"filename": "Symbol 4 instance 10005",
	"frame": {"x":325,"y":0,"w":65,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":65,"h":65},
	"sourceSize": {"w":65,"h":65}
}
,{
	"filename": "Symbol 4 instance 10006",
	"frame": {"x":390,"y":0,"w":65,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":65,"h":65},
	"sourceSize": {"w":65,"h":65}
}
,{
	"filename": "Symbol 4 instance 10007",
	"frame": {"x":455,"y":0,"w":65,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":65,"h":65},
	"sourceSize": {"w":65,"h":65}
}
,{
	"filename": "Symbol 4 instance 10008",
	"frame": {"x":520,"y":0,"w":65,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":65,"h":65},
	"sourceSize": {"w":65,"h":65}
}
,{
	"filename": "Symbol 4 instance 10009",
	"frame": {"x":585,"y":0,"w":65,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":65,"h":65},
	"sourceSize": {"w":65,"h":65}
}
,{
	"filename": "Symbol 4 instance 10010",
	"frame": {"x":650,"y":0,"w":65,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":65,"h":65},
	"sourceSize": {"w":65,"h":65}
}
,{
	"filename": "Symbol 4 instance 10011",
	"frame": {"x":715,"y":0,"w":65,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":65,"h":65},
	"sourceSize": {"w":65,"h":65}
}
,{
	"filename": "Symbol 4 instance 10012",
	"frame": {"x":780,"y":0,"w":65,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":65,"h":65},
	"sourceSize": {"w":65,"h":65}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Kingfisher jumping water.png",
	"format": "RGBA8888",
	"size": {"w":849,"h":72},
	"scale": "1"
}
},  
    
numberpadJson: {"frames": [

{
	"filename": "Symbol 3 instance 10000",
	"frame": {"x":0,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10001",
	"frame": {"x":68,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10002",
	"frame": {"x":136,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10003",
	"frame": {"x":204,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10004",
	"frame": {"x":272,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10005",
	"frame": {"x":340,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10006",
	"frame": {"x":408,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10007",
	"frame": {"x":476,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10008",
	"frame": {"x":544,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10009",
	"frame": {"x":612,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10010",
	"frame": {"x":680,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10011",
	"frame": {"x":748,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10012",
	"frame": {"x":816,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10013",
	"frame": {"x":884,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "number 0 to 9.png",
	"format": "RGBA8888",
	"size": {"w":952,"h":68},
	"scale": "1"
}
},

RightBtnJson:{"frames": [

{
	"filename": "Symbol 14 copy instance 10000",
	"frame": {"x":0,"y":0,"w":58,"h":61},
	"rotated": false,
	"trimmed": true,
	"spriteSourceSize": {"x":3,"y":3,"w":68,"h":70},
	"sourceSize": {"w":68,"h":70}
}
,{
	"filename": "Symbol 14 copy instance 10001",
	"frame": {"x":58,"y":0,"w":68,"h":70},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":70},
	"sourceSize": {"w":68,"h":70}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "15.1.0.210",
	"image": "check.png",
	"format": "RGB8",
	"size": {"w":128,"h":75},
	"scale": "1"
}
},
EraseBtnJson:{"frames": [

{
	"filename": "Symbol 14 copy 5 instance 10000",
	"frame": {"x":0,"y":0,"w":59,"h":61},
	"rotated": false,
	"trimmed": true,
	"spriteSourceSize": {"x":1,"y":1,"w":67,"h":69},
	"sourceSize": {"w":67,"h":69}
}
,{
	"filename": "Symbol 14 copy 5 instance 10001",
	"frame": {"x":59,"y":0,"w":67,"h":69},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":67,"h":69},
	"sourceSize": {"w":67,"h":69}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "15.1.0.210",
	"image": "eraser.png",
	"format": "RGB8",
	"size": {"w":128,"h":75},
	"scale": "1"
}
},


ScreenTextBox: {"frames": [

{
	"filename": "Symbol 14 instance 10000",
	"frame": {"x":0,"y":0,"w":159,"h":87},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":159,"h":87},
	"sourceSize": {"w":159,"h":87}
}
,{
	"filename": "Symbol 14 instance 10001",
	"frame": {"x":159,"y":0,"w":159,"h":87},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":159,"h":87},
	"sourceSize": {"w":159,"h":87}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "19.2.1.408",
	"image": "Box2.png.png",
	"format": "RGBA8888",
	"size": {"w":319,"h":87},
	"scale": "1"
}
},

comingUpJson: {"frames": [
{
	"filename": "Symbol 4 copy instance 10000",
	"frame": {"x":0,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10001",
	"frame": {"x":68,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10002",
	"frame": {"x":136,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10003",
	"frame": {"x":204,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10004",
	"frame": {"x":272,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10005",
	"frame": {"x":340,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10006",
	"frame": {"x":408,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10007",
	"frame": {"x":476,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10008",
	"frame": {"x":544,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10009",
	"frame": {"x":612,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10010",
	"frame": {"x":680,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10011",
	"frame": {"x":748,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10012",
	"frame": {"x":816,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "holding a fish coming back from water,.png",
	"format": "RGBA8888",
	"size": {"w":918,"h":72},
	"scale": "1"
}    
    
},

homebtnJson: {"frames": [

{
	"filename": "Symbol 4 instance 10000",
	"frame": {"x":0,"y":0,"w":60,"h":60},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":60},
	"sourceSize": {"w":60,"h":60}
}
,{
	"filename": "Symbol 4 instance 10001",
	"frame": {"x":0,"y":60,"w":60,"h":60},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":60},
	"sourceSize": {"w":60,"h":60}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "18.0.1.115",
	"image": "H.png",
	"format": "RGB8",
	"size": {"w":64,"h":128},
	"scale": "1"
}
},
    
nextbtnJson: {"frames": [

{
	"filename": "Symbol 6 instance 10000",
	"frame": {"x":0,"y":0,"w":59,"h":60},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":59,"h":60},
	"sourceSize": {"w":59,"h":60}
}
,{
	"filename": "Symbol 6 instance 10001",
	"frame": {"x":0,"y":60,"w":59,"h":60},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":59,"h":60},
	"sourceSize": {"w":59,"h":60}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "18.0.1.115",
	"image": "N.png",
	"format": "RGB8",
	"size": {"w":64,"h":128},
	"scale": "1"
}
},
    
undergroundJson:{"frames": [

{
	"filename": "Symbol 53 instance 10000",
	"frame": {"x":0,"y":0,"w":727,"h":276},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":727,"h":276},
	"sourceSize": {"w":727,"h":276}
}
,{
	"filename": "Symbol 53 instance 10001",
	"frame": {"x":727,"y":0,"w":727,"h":276},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":727,"h":276},
	"sourceSize": {"w":727,"h":276}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "under ground.png",
	"format": "RGBA8888",
	"size": {"w":1458,"h":276},
	"scale": "1"
}
}
,
groundfloorJson:{"frames": [

{
	"filename": "Symbol 54 instance 10000",
	"frame": {"x":0,"y":0,"w":731,"h":267},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":731,"h":267},
	"sourceSize": {"w":731,"h":267}
}
,{
	"filename": "Symbol 54 instance 10001",
	"frame": {"x":731,"y":0,"w":731,"h":267},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":731,"h":267},
	"sourceSize": {"w":731,"h":267}
}
,{
	"filename": "Symbol 54 instance 10002",
	"frame": {"x":1462,"y":0,"w":731,"h":267},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":731,"h":267},
	"sourceSize": {"w":731,"h":267}
}
,{
	"filename": "Symbol 54 instance 10003",
	"frame": {"x":2193,"y":0,"w":731,"h":267},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":731,"h":267},
	"sourceSize": {"w":731,"h":267}
}
,{
	"filename": "Symbol 54 instance 10004",
	"frame": {"x":2924,"y":0,"w":731,"h":267},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":731,"h":267},
	"sourceSize": {"w":731,"h":267}
}
,{
	"filename": "Symbol 54 instance 10005",
	"frame": {"x":0,"y":267,"w":731,"h":267},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":731,"h":267},
	"sourceSize": {"w":731,"h":267}
}
,{
	"filename": "Symbol 54 instance 10006",
	"frame": {"x":731,"y":267,"w":731,"h":267},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":731,"h":267},
	"sourceSize": {"w":731,"h":267}
}
,{
	"filename": "Symbol 54 instance 10007",
	"frame": {"x":1462,"y":267,"w":731,"h":267},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":731,"h":267},
	"sourceSize": {"w":731,"h":267}
}
,{
	"filename": "Symbol 54 instance 10008",
	"frame": {"x":2193,"y":267,"w":731,"h":267},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":731,"h":267},
	"sourceSize": {"w":731,"h":267}
}
,{
	"filename": "Symbol 54 instance 10009",
	"frame": {"x":2924,"y":267,"w":731,"h":267},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":731,"h":267},
	"sourceSize": {"w":731,"h":267}
}
,{
	"filename": "Symbol 54 instance 10010",
	"frame": {"x":0,"y":534,"w":731,"h":267},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":731,"h":267},
	"sourceSize": {"w":731,"h":267}
}
,{
	"filename": "Symbol 54 instance 10011",
	"frame": {"x":731,"y":534,"w":731,"h":267},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":731,"h":267},
	"sourceSize": {"w":731,"h":267}
}
,{
	"filename": "Symbol 54 instance 10012",
	"frame": {"x":1462,"y":534,"w":731,"h":267},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":731,"h":267},
	"sourceSize": {"w":731,"h":267}
}
,{
	"filename": "Symbol 54 instance 10013",
	"frame": {"x":2193,"y":534,"w":731,"h":267},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":731,"h":267},
	"sourceSize": {"w":731,"h":267}
}
,{
	"filename": "Symbol 54 instance 10014",
	"frame": {"x":2924,"y":534,"w":731,"h":267},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":731,"h":267},
	"sourceSize": {"w":731,"h":267}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Ground floor.png",
	"format": "RGBA8888",
	"size": {"w":3655,"h":819},
	"scale": "1"
}
}
,
ball:{"frames": [

{
	"filename": "Symbol 14 instance 10000",
	"frame": {"x":0,"y":0,"w":96,"h":97},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":96,"h":97},
	"sourceSize": {"w":96,"h":97}
}
,{
	"filename": "Symbol 14 instance 10001",
	"frame": {"x":96,"y":0,"w":96,"h":97},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":96,"h":97},
	"sourceSize": {"w":96,"h":97}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Ball.png",
	"format": "RGBA8888",
	"size": {"w":198,"h":98},
	"scale": "1"
}
},
cat:{"frames": [

{
	"filename": "Symbol 15 instance 10000",
	"frame": {"x":0,"y":0,"w":99,"h":106},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":99,"h":106},
	"sourceSize": {"w":99,"h":106}
}
,{
	"filename": "Symbol 15 instance 10001",
	"frame": {"x":99,"y":0,"w":99,"h":106},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":99,"h":106},
	"sourceSize": {"w":99,"h":106}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Cat.png",
	"format": "RGBA8888",
	"size": {"w":203,"h":109},
	"scale": "1"
}
},
dog:{"frames": [

{
	"filename": "Symbol 16 instance 10000",
	"frame": {"x":0,"y":0,"w":99,"h":109},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":99,"h":109},
	"sourceSize": {"w":99,"h":109}
}
,{
	"filename": "Symbol 16 instance 10001",
	"frame": {"x":99,"y":0,"w":99,"h":109},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":99,"h":109},
	"sourceSize": {"w":99,"h":109}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Dog.png",
	"format": "RGBA8888",
	"size": {"w":198,"h":109},
	"scale": "1"
}
}
,
cloth:{"frames": [

{
	"filename": "Symbol 17 instance 10000",
	"frame": {"x":0,"y":0,"w":105,"h":103},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":105,"h":103},
	"sourceSize": {"w":105,"h":103}
}
,{
	"filename": "Symbol 17 instance 10001",
	"frame": {"x":105,"y":0,"w":105,"h":103},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":105,"h":103},
	"sourceSize": {"w":105,"h":103}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Cloth.png",
	"format": "RGBA8888",
	"size": {"w":219,"h":104},
	"scale": "1"
}
}
,
rabbit:{"frames": [

{
	"filename": "Symbol 18 instance 10000",
	"frame": {"x":0,"y":0,"w":76,"h":107},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":76,"h":107},
	"sourceSize": {"w":76,"h":107}
}
,{
	"filename": "Symbol 18 instance 10001",
	"frame": {"x":76,"y":0,"w":76,"h":107},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":76,"h":107},
	"sourceSize": {"w":76,"h":107}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Rabbit.png",
	"format": "RGBA8888",
	"size": {"w":154,"h":110},
	"scale": "1"
}
}
,
doganim:{"frames": [

{
	"filename": "Symbol 23 instance 10000",
	"frame": {"x":0,"y":0,"w":34,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":34,"h":40},
	"sourceSize": {"w":34,"h":40}
}
,{
	"filename": "Symbol 23 instance 10001",
	"frame": {"x":34,"y":0,"w":34,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":34,"h":40},
	"sourceSize": {"w":34,"h":40}
}
,{
	"filename": "Symbol 23 instance 10002",
	"frame": {"x":68,"y":0,"w":34,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":34,"h":40},
	"sourceSize": {"w":34,"h":40}
}
,{
	"filename": "Symbol 23 instance 10003",
	"frame": {"x":102,"y":0,"w":34,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":34,"h":40},
	"sourceSize": {"w":34,"h":40}
}
,{
	"filename": "Symbol 23 instance 10004",
	"frame": {"x":136,"y":0,"w":34,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":34,"h":40},
	"sourceSize": {"w":34,"h":40}
}
,{
	"filename": "Symbol 23 instance 10005",
	"frame": {"x":170,"y":0,"w":34,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":34,"h":40},
	"sourceSize": {"w":34,"h":40}
}
,{
	"filename": "Symbol 23 instance 10006",
	"frame": {"x":204,"y":0,"w":34,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":34,"h":40},
	"sourceSize": {"w":34,"h":40}
}
,{
	"filename": "Symbol 23 instance 10007",
	"frame": {"x":238,"y":0,"w":34,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":34,"h":40},
	"sourceSize": {"w":34,"h":40}
}
,{
	"filename": "Symbol 23 instance 10008",
	"frame": {"x":272,"y":0,"w":34,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":34,"h":40},
	"sourceSize": {"w":34,"h":40}
}
,{
	"filename": "Symbol 23 instance 10009",
	"frame": {"x":306,"y":0,"w":34,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":34,"h":40},
	"sourceSize": {"w":34,"h":40}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Dog anim.png",
	"format": "RGBA8888",
	"size": {"w":342,"h":40},
	"scale": "1"
}
},
catanim:{"frames": [

{
	"filename": "Symbol 22 instance 10000",
	"frame": {"x":0,"y":0,"w":41,"h":39},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":41,"h":39},
	"sourceSize": {"w":41,"h":39}
}
,{
	"filename": "Symbol 22 instance 10001",
	"frame": {"x":41,"y":0,"w":41,"h":39},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":41,"h":39},
	"sourceSize": {"w":41,"h":39}
}
,{
	"filename": "Symbol 22 instance 10002",
	"frame": {"x":82,"y":0,"w":41,"h":39},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":41,"h":39},
	"sourceSize": {"w":41,"h":39}
}
,{
	"filename": "Symbol 22 instance 10003",
	"frame": {"x":123,"y":0,"w":41,"h":39},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":41,"h":39},
	"sourceSize": {"w":41,"h":39}
}
,{
	"filename": "Symbol 22 instance 10004",
	"frame": {"x":164,"y":0,"w":41,"h":39},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":41,"h":39},
	"sourceSize": {"w":41,"h":39}
}
,{
	"filename": "Symbol 22 instance 10005",
	"frame": {"x":205,"y":0,"w":41,"h":39},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":41,"h":39},
	"sourceSize": {"w":41,"h":39}
}
,{
	"filename": "Symbol 22 instance 10006",
	"frame": {"x":246,"y":0,"w":41,"h":39},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":41,"h":39},
	"sourceSize": {"w":41,"h":39}
}
,{
	"filename": "Symbol 22 instance 10007",
	"frame": {"x":287,"y":0,"w":41,"h":39},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":41,"h":39},
	"sourceSize": {"w":41,"h":39}
}
,{
	"filename": "Symbol 22 instance 10008",
	"frame": {"x":328,"y":0,"w":41,"h":39},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":41,"h":39},
	"sourceSize": {"w":41,"h":39}
}
,{
	"filename": "Symbol 22 instance 10009",
	"frame": {"x":369,"y":0,"w":41,"h":39},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":41,"h":39},
	"sourceSize": {"w":41,"h":39}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Cat anim.png",
	"format": "RGBA8888",
	"size": {"w":412,"h":40},
	"scale": "1"
}
},
ballanim:{"frames": [

{
	"filename": "Symbol 21 instance 10000",
	"frame": {"x":0,"y":0,"w":33,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":33,"h":40},
	"sourceSize": {"w":33,"h":40}
}
,{
	"filename": "Symbol 21 instance 10001",
	"frame": {"x":33,"y":0,"w":33,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":33,"h":40},
	"sourceSize": {"w":33,"h":40}
}
,{
	"filename": "Symbol 21 instance 10002",
	"frame": {"x":66,"y":0,"w":33,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":33,"h":40},
	"sourceSize": {"w":33,"h":40}
}
,{
	"filename": "Symbol 21 instance 10003",
	"frame": {"x":99,"y":0,"w":33,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":33,"h":40},
	"sourceSize": {"w":33,"h":40}
}
,{
	"filename": "Symbol 21 instance 10004",
	"frame": {"x":132,"y":0,"w":33,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":33,"h":40},
	"sourceSize": {"w":33,"h":40}
}
,{
	"filename": "Symbol 21 instance 10005",
	"frame": {"x":165,"y":0,"w":33,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":33,"h":40},
	"sourceSize": {"w":33,"h":40}
}
,{
	"filename": "Symbol 21 instance 10006",
	"frame": {"x":198,"y":0,"w":33,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":33,"h":40},
	"sourceSize": {"w":33,"h":40}
}
,{
	"filename": "Symbol 21 instance 10007",
	"frame": {"x":231,"y":0,"w":33,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":33,"h":40},
	"sourceSize": {"w":33,"h":40}
}
,{
	"filename": "Symbol 21 instance 10008",
	"frame": {"x":264,"y":0,"w":33,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":33,"h":40},
	"sourceSize": {"w":33,"h":40}
}
,{
	"filename": "Symbol 21 instance 10009",
	"frame": {"x":297,"y":0,"w":33,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":33,"h":40},
	"sourceSize": {"w":33,"h":40}
}
,{
	"filename": "Symbol 21 instance 10010",
	"frame": {"x":330,"y":0,"w":33,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":33,"h":40},
	"sourceSize": {"w":33,"h":40}
}
,{
	"filename": "Symbol 21 instance 10011",
	"frame": {"x":363,"y":0,"w":33,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":33,"h":40},
	"sourceSize": {"w":33,"h":40}
}
,{
	"filename": "Symbol 21 instance 10012",
	"frame": {"x":396,"y":0,"w":33,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":33,"h":40},
	"sourceSize": {"w":33,"h":40}
}
,{
	"filename": "Symbol 21 instance 10013",
	"frame": {"x":429,"y":0,"w":33,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":33,"h":40},
	"sourceSize": {"w":33,"h":40}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Ball anim.png",
	"format": "RGBA8888",
	"size": {"w":463,"h":41},
	"scale": "1"
}
},
clothanim:{"frames": [

{
	"filename": "Symbol 20 instance 10000",
	"frame": {"x":0,"y":0,"w":34,"h":37},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":34,"h":37},
	"sourceSize": {"w":34,"h":37}
}
,{
	"filename": "Symbol 20 instance 10001",
	"frame": {"x":34,"y":0,"w":34,"h":37},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":34,"h":37},
	"sourceSize": {"w":34,"h":37}
}
,{
	"filename": "Symbol 20 instance 10002",
	"frame": {"x":68,"y":0,"w":34,"h":37},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":34,"h":37},
	"sourceSize": {"w":34,"h":37}
}
,{
	"filename": "Symbol 20 instance 10003",
	"frame": {"x":102,"y":0,"w":34,"h":37},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":34,"h":37},
	"sourceSize": {"w":34,"h":37}
}
,{
	"filename": "Symbol 20 instance 10004",
	"frame": {"x":136,"y":0,"w":34,"h":37},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":34,"h":37},
	"sourceSize": {"w":34,"h":37}
}
,{
	"filename": "Symbol 20 instance 10005",
	"frame": {"x":170,"y":0,"w":34,"h":37},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":34,"h":37},
	"sourceSize": {"w":34,"h":37}
}
,{
	"filename": "Symbol 20 instance 10006",
	"frame": {"x":204,"y":0,"w":34,"h":37},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":34,"h":37},
	"sourceSize": {"w":34,"h":37}
}
,{
	"filename": "Symbol 20 instance 10007",
	"frame": {"x":238,"y":0,"w":34,"h":37},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":34,"h":37},
	"sourceSize": {"w":34,"h":37}
}
,{
	"filename": "Symbol 20 instance 10008",
	"frame": {"x":272,"y":0,"w":34,"h":37},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":34,"h":37},
	"sourceSize": {"w":34,"h":37}
}
,{
	"filename": "Symbol 20 instance 10009",
	"frame": {"x":306,"y":0,"w":34,"h":37},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":34,"h":37},
	"sourceSize": {"w":34,"h":37}
}
,{
	"filename": "Symbol 20 instance 10010",
	"frame": {"x":340,"y":0,"w":34,"h":37},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":34,"h":37},
	"sourceSize": {"w":34,"h":37}
}
,{
	"filename": "Symbol 20 instance 10011",
	"frame": {"x":374,"y":0,"w":34,"h":37},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":34,"h":37},
	"sourceSize": {"w":34,"h":37}
}
,{
	"filename": "Symbol 20 instance 10012",
	"frame": {"x":408,"y":0,"w":34,"h":37},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":34,"h":37},
	"sourceSize": {"w":34,"h":37}
}
,{
	"filename": "Symbol 20 instance 10013",
	"frame": {"x":442,"y":0,"w":34,"h":37},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":34,"h":37},
	"sourceSize": {"w":34,"h":37}
}
,{
	"filename": "Symbol 20 instance 10014",
	"frame": {"x":476,"y":0,"w":34,"h":37},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":34,"h":37},
	"sourceSize": {"w":34,"h":37}
}
,{
	"filename": "Symbol 20 instance 10015",
	"frame": {"x":510,"y":0,"w":34,"h":37},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":34,"h":37},
	"sourceSize": {"w":34,"h":37}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Cloth anim.png",
	"format": "RGBA8888",
	"size": {"w":546,"h":39},
	"scale": "1"
}
},
rabbitanim:{"frames": [

{
	"filename": "Symbol 24 instance 10000",
	"frame": {"x":0,"y":0,"w":25,"h":44},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":25,"h":44},
	"sourceSize": {"w":25,"h":44}
}
,{
	"filename": "Symbol 24 instance 10001",
	"frame": {"x":25,"y":0,"w":25,"h":44},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":25,"h":44},
	"sourceSize": {"w":25,"h":44}
}
,{
	"filename": "Symbol 24 instance 10002",
	"frame": {"x":50,"y":0,"w":25,"h":44},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":25,"h":44},
	"sourceSize": {"w":25,"h":44}
}
,{
	"filename": "Symbol 24 instance 10003",
	"frame": {"x":75,"y":0,"w":25,"h":44},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":25,"h":44},
	"sourceSize": {"w":25,"h":44}
}
,{
	"filename": "Symbol 24 instance 10004",
	"frame": {"x":100,"y":0,"w":25,"h":44},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":25,"h":44},
	"sourceSize": {"w":25,"h":44}
}
,{
	"filename": "Symbol 24 instance 10005",
	"frame": {"x":125,"y":0,"w":25,"h":44},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":25,"h":44},
	"sourceSize": {"w":25,"h":44}
}
,{
	"filename": "Symbol 24 instance 10006",
	"frame": {"x":150,"y":0,"w":25,"h":44},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":25,"h":44},
	"sourceSize": {"w":25,"h":44}
}
,{
	"filename": "Symbol 24 instance 10007",
	"frame": {"x":175,"y":0,"w":25,"h":44},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":25,"h":44},
	"sourceSize": {"w":25,"h":44}
}
,{
	"filename": "Symbol 24 instance 10008",
	"frame": {"x":200,"y":0,"w":25,"h":44},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":25,"h":44},
	"sourceSize": {"w":25,"h":44}
}
,{
	"filename": "Symbol 24 instance 10009",
	"frame": {"x":225,"y":0,"w":25,"h":44},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":25,"h":44},
	"sourceSize": {"w":25,"h":44}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Rabbit anim.png",
	"format": "RGBA8888",
	"size": {"w":252,"h":44},
	"scale": "1"
}
}

};

