var NSD_4E_G6_JSON = {

	starAnimJson: {
		"frames": [

			{
				"filename": "Symbol 10 copy instance 10000",
				"frame": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10001",
				"frame": { "x": 0, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10002",
				"frame": { "x": 0, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10003",
				"frame": { "x": 0, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10004",
				"frame": { "x": 33, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10005",
				"frame": { "x": 33, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10006",
				"frame": { "x": 33, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10007",
				"frame": { "x": 33, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10008",
				"frame": { "x": 66, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10009",
				"frame": { "x": 66, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10010",
				"frame": { "x": 66, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10011",
				"frame": { "x": 66, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10012",
				"frame": { "x": 99, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10013",
				"frame": { "x": 99, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10014",
				"frame": { "x": 99, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10015",
				"frame": { "x": 99, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10016",
				"frame": { "x": 132, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10017",
				"frame": { "x": 132, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10018",
				"frame": { "x": 132, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10019",
				"frame": { "x": 132, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10020",
				"frame": { "x": 165, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10021",
				"frame": { "x": 165, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10022",
				"frame": { "x": 165, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10023",
				"frame": { "x": 165, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10024",
				"frame": { "x": 198, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10025",
				"frame": { "x": 198, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10026",
				"frame": { "x": 198, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10027",
				"frame": { "x": 198, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10028",
				"frame": { "x": 231, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10029",
				"frame": { "x": 231, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10030",
				"frame": { "x": 231, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10031",
				"frame": { "x": 231, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10032",
				"frame": { "x": 264, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10033",
				"frame": { "x": 264, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10034",
				"frame": { "x": 264, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10035",
				"frame": { "x": 264, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "st.png",
			"format": "RGB8",
			"size": { "w": 334, "h": 479 },
			"scale": "1"
		}
	},

	speakerJson: {
		"frames": [

			{
				"filename": "Symbol 5 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 41, "h": 30 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 41, "h": 30 },
				"sourceSize": { "w": 41, "h": 30 }
			},
			{
				"filename": "Symbol 5 instance 10001",
				"frame": { "x": 0, "y": 30, "w": 41, "h": 30 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 41, "h": 30 },
				"sourceSize": { "w": 41, "h": 30 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "s.png",
			"format": "RGB8",
			"size": { "w": 44, "h": 64 },
			"scale": "1"
		}
	},

	btnJson: {
		"frames": [

			{
				"filename": "Symbol 1 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 212, "h": 71 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 212, "h": 71 },
				"sourceSize": { "w": 212, "h": 71 }
			}
			, {
				"filename": "Symbol 1 instance 10001",
				"frame": { "x": 0, "y": 71, "w": 212, "h": 71 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 212, "h": 71 },
				"sourceSize": { "w": 212, "h": 71 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "16.5.1.104",
			"image": "b1.png",
			"format": "RGB8",
			"size": { "w": 213, "h": 144 },
			"scale": "1"
		}
	},

	replyJson: {
		"frames": [

			{
				"filename": "Symbol 8 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"sourceSize": { "w": 47, "h": 47 }
			}
			, {
				"filename": "Symbol 8 instance 10001",
				"frame": { "x": 47, "y": 0, "w": 47, "h": 47 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"sourceSize": { "w": 47, "h": 47 }
			}
			, {
				"filename": "Symbol 8 instance 10002",
				"frame": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"sourceSize": { "w": 47, "h": 47 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "Back btn.png",
			"format": "RGBA8888",
			"size": { "w": 98, "h": 48 },
			"scale": "1"
		}
	},

	backbtnJson: {
		"frames": [

			{
				"filename": "Symbol 9 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 41, "h": 29 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 41, "h": 29 },
				"sourceSize": { "w": 41, "h": 29 }
			}
			, {
				"filename": "Symbol 9 instance 10001",
				"frame": { "x": 0, "y": 29, "w": 41, "h": 29 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 41, "h": 29 },
				"sourceSize": { "w": 41, "h": 29 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "back.png",
			"format": "RGB8",
			"size": { "w": 44, "h": 64 },
			"scale": "1"
		}
	},

	tickJson: {"frames": [

		{
			"filename": "Symbol 10 copy instance 10000",
			"frame": {"x":0,"y":0,"w":68,"h":66},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":68,"h":66},
			"sourceSize": {"w":68,"h":66}
		}
		,{
			"filename": "Symbol 10 copy instance 10001",
			"frame": {"x":68,"y":0,"w":68,"h":66},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":68,"h":66},
			"sourceSize": {"w":68,"h":66}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "20.0.1.19255",
			"image": "Right btn0002.png",
			"format": "RGBA8888",
			"size": {"w":138,"h":66},
			"scale": "1"
		}
		},
		
	nextbtnJson: {
		"frames": [

			{
				"filename": "Symbol 6 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 59, "h": 60 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 59, "h": 60 },
				"sourceSize": { "w": 59, "h": 60 }
			}
			, {
				"filename": "Symbol 6 instance 10001",
				"frame": { "x": 0, "y": 60, "w": 59, "h": 60 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 59, "h": 60 },
				"sourceSize": { "w": 59, "h": 60 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.1.115",
			"image": "N.png",
			"format": "RGB8",
			"size": { "w": 64, "h": 128 },
			"scale": "1"
		}
	},
	homebtnJson: {
		"frames": [

			{
				"filename": "Symbol 4 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 60, "h": 60 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 60, "h": 60 },
				"sourceSize": { "w": 60, "h": 60 }
			}
			, {
				"filename": "Symbol 4 instance 10001",
				"frame": { "x": 0, "y": 60, "w": 60, "h": 60 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 60, "h": 60 },
				"sourceSize": { "w": 60, "h": 60 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.1.115",
			"image": "H.png",
			"format": "RGB8",
			"size": { "w": 64, "h": 128 },
			"scale": "1"
		}

	},
	symbol1:{"frames": [

		{
			"filename": "Symbol 3 copy instance 10000",
			"frame": {"x":0,"y":0,"w":57,"h":57},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":57,"h":57},
			"sourceSize": {"w":57,"h":57}
		}
		,{
			"filename": "Symbol 3 copy instance 10001",
			"frame": {"x":57,"y":0,"w":57,"h":57},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":57,"h":57},
			"sourceSize": {"w":57,"h":57}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Symbol -.png",
			"format": "RGBA8888",
			"size": {"w":114,"h":57},
			"scale": "1"
		}
		},
		
	symbol2:{"frames": [

		{
			"filename": "Symbol 3 instance 10000",
			"frame": {"x":0,"y":0,"w":58,"h":57},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":58,"h":57},
			"sourceSize": {"w":58,"h":57}
		}
		,{
			"filename": "Symbol 3 instance 10001",
			"frame": {"x":58,"y":0,"w":58,"h":57},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":58,"h":57},
			"sourceSize": {"w":58,"h":57}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "Symbol +.png",
			"format": "RGBA8888",
			"size": {"w":116,"h":57},
			"scale": "1"
		}
		},
bucketAnim:{"frames": [

	{
		"filename": "Symbol 2 instance 10000",
		"frame": {"x":0,"y":0,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10001",
		"frame": {"x":585,"y":0,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10002",
		"frame": {"x":1170,"y":0,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10003",
		"frame": {"x":1755,"y":0,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10004",
		"frame": {"x":2340,"y":0,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10005",
		"frame": {"x":2925,"y":0,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10006",
		"frame": {"x":3510,"y":0,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10007",
		"frame": {"x":4095,"y":0,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10008",
		"frame": {"x":4680,"y":0,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10009",
		"frame": {"x":5265,"y":0,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10010",
		"frame": {"x":5850,"y":0,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10011",
		"frame": {"x":6435,"y":0,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10012",
		"frame": {"x":7020,"y":0,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10013",
		"frame": {"x":7605,"y":0,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10014",
		"frame": {"x":0,"y":400,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10015",
		"frame": {"x":585,"y":400,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10016",
		"frame": {"x":1170,"y":400,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10017",
		"frame": {"x":1755,"y":400,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10018",
		"frame": {"x":2340,"y":400,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10019",
		"frame": {"x":2925,"y":400,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10020",
		"frame": {"x":3510,"y":400,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10021",
		"frame": {"x":4095,"y":400,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10022",
		"frame": {"x":4680,"y":400,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10023",
		"frame": {"x":5265,"y":400,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10024",
		"frame": {"x":5850,"y":400,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10025",
		"frame": {"x":6435,"y":400,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10026",
		"frame": {"x":7020,"y":400,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10027",
		"frame": {"x":7605,"y":400,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10028",
		"frame": {"x":0,"y":800,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10029",
		"frame": {"x":585,"y":800,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10030",
		"frame": {"x":1170,"y":800,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10031",
		"frame": {"x":1755,"y":800,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10032",
		"frame": {"x":2340,"y":800,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10033",
		"frame": {"x":2925,"y":800,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10034",
		"frame": {"x":3510,"y":800,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10035",
		"frame": {"x":4095,"y":800,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10036",
		"frame": {"x":4680,"y":800,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10037",
		"frame": {"x":5265,"y":800,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10038",
		"frame": {"x":5850,"y":800,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10039",
		"frame": {"x":6435,"y":800,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10040",
		"frame": {"x":7020,"y":800,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10041",
		"frame": {"x":7605,"y":800,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10042",
		"frame": {"x":0,"y":1200,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10043",
		"frame": {"x":585,"y":1200,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10044",
		"frame": {"x":1170,"y":1200,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10045",
		"frame": {"x":1755,"y":1200,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10046",
		"frame": {"x":2340,"y":1200,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10047",
		"frame": {"x":2925,"y":1200,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10048",
		"frame": {"x":3510,"y":1200,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10049",
		"frame": {"x":4095,"y":1200,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10050",
		"frame": {"x":4680,"y":1200,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10051",
		"frame": {"x":5265,"y":1200,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10052",
		"frame": {"x":5850,"y":1200,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10053",
		"frame": {"x":6435,"y":1200,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10054",
		"frame": {"x":7020,"y":1200,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10055",
		"frame": {"x":7605,"y":1200,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10056",
		"frame": {"x":0,"y":1600,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10057",
		"frame": {"x":585,"y":1600,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10058",
		"frame": {"x":1170,"y":1600,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10059",
		"frame": {"x":1755,"y":1600,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10060",
		"frame": {"x":2340,"y":1600,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10061",
		"frame": {"x":2925,"y":1600,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10062",
		"frame": {"x":3510,"y":1600,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10063",
		"frame": {"x":4095,"y":1600,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10064",
		"frame": {"x":4680,"y":1600,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10065",
		"frame": {"x":5265,"y":1600,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10066",
		"frame": {"x":5850,"y":1600,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10067",
		"frame": {"x":6435,"y":1600,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10068",
		"frame": {"x":7020,"y":1600,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10069",
		"frame": {"x":7605,"y":1600,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10070",
		"frame": {"x":0,"y":2000,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10071",
		"frame": {"x":585,"y":2000,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10072",
		"frame": {"x":1170,"y":2000,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10073",
		"frame": {"x":1755,"y":2000,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10074",
		"frame": {"x":2340,"y":2000,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10075",
		"frame": {"x":2925,"y":2000,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10076",
		"frame": {"x":3510,"y":2000,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10077",
		"frame": {"x":4095,"y":2000,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10078",
		"frame": {"x":4680,"y":2000,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10079",
		"frame": {"x":5265,"y":2000,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10080",
		"frame": {"x":5850,"y":2000,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10081",
		"frame": {"x":6435,"y":2000,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10082",
		"frame": {"x":7020,"y":2000,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10083",
		"frame": {"x":7605,"y":2000,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10084",
		"frame": {"x":0,"y":2400,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10085",
		"frame": {"x":585,"y":2400,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10086",
		"frame": {"x":1170,"y":2400,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10087",
		"frame": {"x":1755,"y":2400,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10088",
		"frame": {"x":2340,"y":2400,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10089",
		"frame": {"x":2925,"y":2400,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10090",
		"frame": {"x":3510,"y":2400,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10091",
		"frame": {"x":4095,"y":2400,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10092",
		"frame": {"x":4680,"y":2400,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10093",
		"frame": {"x":5265,"y":2400,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10094",
		"frame": {"x":5850,"y":2400,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10095",
		"frame": {"x":6435,"y":2400,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10096",
		"frame": {"x":7020,"y":2400,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10097",
		"frame": {"x":7605,"y":2400,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10098",
		"frame": {"x":0,"y":2800,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10099",
		"frame": {"x":585,"y":2800,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}
	,{
		"filename": "Symbol 2 instance 10100",
		"frame": {"x":1170,"y":2800,"w":585,"h":400},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":585,"h":400},
		"sourceSize": {"w":585,"h":400}
	}],
	"meta": {
		"app": "Adobe Animate",
		"version": "22.0.0.93",
		"image": "Bucket anim new.png",
		"format": "RGBA8888",
		"size": {"w":8192,"h":3240},
		"scale": "1"
	}
	},
	lesserSign: {
		"frames": [

			{
				"filename": "Symbol 5 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 67, "h": 52 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 67, "h": 52 },
				"sourceSize": { "w": 67, "h": 52 }
			}
			, {
				"filename": "Symbol 5 instance 10001",
				"frame": { "x": 67, "y": 0, "w": 67, "h": 52 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 67, "h": 52 },
				"sourceSize": { "w": 67, "h": 52 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.0.93",
			"image": "sym_1.png",
			"format": "RGBA8888",
			"size": { "w": 134, "h": 52 },
			"scale": "1"
		}
	},
	numberpadJson: {
		"frames": [

			{
				"filename": "Symbol 11 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 49, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
				"sourceSize": { "w": 49, "h": 49 }
			}
			, {
				"filename": "Symbol 11 instance 10001",
				"frame": { "x": 49, "y": 0, "w": 49, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
				"sourceSize": { "w": 49, "h": 49 }
			}
			, {
				"filename": "Symbol 11 instance 10002",
				"frame": { "x": 98, "y": 0, "w": 49, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
				"sourceSize": { "w": 49, "h": 49 }
			}
			, {
				"filename": "Symbol 11 instance 10003",
				"frame": { "x": 147, "y": 0, "w": 49, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
				"sourceSize": { "w": 49, "h": 49 }
			}
			, {
				"filename": "Symbol 11 instance 10004",
				"frame": { "x": 196, "y": 0, "w": 49, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
				"sourceSize": { "w": 49, "h": 49 }
			}
			, {
				"filename": "Symbol 11 instance 10005",
				"frame": { "x": 245, "y": 0, "w": 49, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
				"sourceSize": { "w": 49, "h": 49 }
			}
			, {
				"filename": "Symbol 11 instance 10006",
				"frame": { "x": 294, "y": 0, "w": 49, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
				"sourceSize": { "w": 49, "h": 49 }
			}
			, {
				"filename": "Symbol 11 instance 10007",
				"frame": { "x": 343, "y": 0, "w": 49, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
				"sourceSize": { "w": 49, "h": 49 }
			}
			, {
				"filename": "Symbol 11 instance 10008",
				"frame": { "x": 392, "y": 0, "w": 49, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
				"sourceSize": { "w": 49, "h": 49 }
			}
			, {
				"filename": "Symbol 11 instance 10009",
				"frame": { "x": 441, "y": 0, "w": 49, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
				"sourceSize": { "w": 49, "h": 49 }
			}
			, {
				"filename": "Symbol 11 instance 10010",
				"frame": { "x": 490, "y": 0, "w": 49, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
				"sourceSize": { "w": 49, "h": 49 }
			}
			, {
				"filename": "Symbol 11 instance 10011",
				"frame": { "x": 539, "y": 0, "w": 49, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
				"sourceSize": { "w": 49, "h": 49 }
			}
			, {
				"filename": "Symbol 11 instance 10012",
				"frame": { "x": 588, "y": 0, "w": 49, "h": 49 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
				"sourceSize": { "w": 49, "h": 49 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "22.0.4.185",
			"image": "Number pad anim.png",
			"format": "RGBA8888",
			"size": { "w": 637, "h": 49 },
			"scale": "1"
		}
	},

	bulbBtnJson:{"frames": [

		{
			"filename": "Symbol 1 instance 10000",
			"frame": {"x":0,"y":0,"w":66,"h":49},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
			"sourceSize": {"w":66,"h":49}
		}
		,{
			"filename": "Symbol 1 instance 10001",
			"frame": {"x":66,"y":0,"w":66,"h":49},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
			"sourceSize": {"w":66,"h":49}
		}
		,{
			"filename": "Symbol 1 instance 10002",
			"frame": {"x":132,"y":0,"w":66,"h":49},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
			"sourceSize": {"w":66,"h":49}
		}
		,{
			"filename": "Symbol 1 instance 10003",
			"frame": {"x":0,"y":49,"w":66,"h":49},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
			"sourceSize": {"w":66,"h":49}
		}
		,{
			"filename": "Symbol 1 instance 10004",
			"frame": {"x":66,"y":49,"w":66,"h":49},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
			"sourceSize": {"w":66,"h":49}
		}
		,{
			"filename": "Symbol 1 instance 10005",
			"frame": {"x":132,"y":49,"w":66,"h":49},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
			"sourceSize": {"w":66,"h":49}
		}
		,{
			"filename": "Symbol 1 instance 10006",
			"frame": {"x":0,"y":98,"w":66,"h":49},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
			"sourceSize": {"w":66,"h":49}
		}
		,{
			"filename": "Symbol 1 instance 10007",
			"frame": {"x":66,"y":98,"w":66,"h":49},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
			"sourceSize": {"w":66,"h":49}
		}
		,{
			"filename": "Symbol 1 instance 10008",
			"frame": {"x":132,"y":98,"w":66,"h":49},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
			"sourceSize": {"w":66,"h":49}
		}
		,{
			"filename": "Symbol 1 instance 10009",
			"frame": {"x":0,"y":147,"w":66,"h":49},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
			"sourceSize": {"w":66,"h":49}
		}
		,{
			"filename": "Symbol 1 instance 10010",
			"frame": {"x":66,"y":147,"w":66,"h":49},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
			"sourceSize": {"w":66,"h":49}
		}
		,{
			"filename": "Symbol 1 instance 10011",
			"frame": {"x":132,"y":147,"w":66,"h":49},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
			"sourceSize": {"w":66,"h":49}
		}
		,{
			"filename": "Symbol 1 instance 10012",
			"frame": {"x":0,"y":196,"w":66,"h":49},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
			"sourceSize": {"w":66,"h":49}
		}
		,{
			"filename": "Symbol 1 instance 10013",
			"frame": {"x":66,"y":196,"w":66,"h":49},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
			"sourceSize": {"w":66,"h":49}
		}
		,{
			"filename": "Symbol 1 instance 10014",
			"frame": {"x":132,"y":196,"w":66,"h":49},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
			"sourceSize": {"w":66,"h":49}
		}
		,{
			"filename": "Symbol 1 instance 10015",
			"frame": {"x":0,"y":245,"w":66,"h":49},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
			"sourceSize": {"w":66,"h":49}
		}
		,{
			"filename": "Symbol 1 instance 10016",
			"frame": {"x":66,"y":245,"w":66,"h":49},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
			"sourceSize": {"w":66,"h":49}
		}
		,{
			"filename": "Symbol 1 instance 10017",
			"frame": {"x":132,"y":245,"w":66,"h":49},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
			"sourceSize": {"w":66,"h":49}
		}
		,{
			"filename": "Symbol 1 instance 10018",
			"frame": {"x":0,"y":294,"w":66,"h":49},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
			"sourceSize": {"w":66,"h":49}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.0.107",
			"image": "bulb anim.png",
			"format": "RGBA8888",
			"size": {"w":198,"h":347},
			"scale": "1"
		}
		}
	
	
};

