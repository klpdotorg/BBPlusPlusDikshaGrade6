var GMR_01_G6_JSON = {

	starAnimJson: {
		"frames": [

			{
				"filename": "Symbol 10 copy instance 10000",
				"frame": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10001",
				"frame": { "x": 0, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10002",
				"frame": { "x": 0, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10003",
				"frame": { "x": 0, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10004",
				"frame": { "x": 33, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10005",
				"frame": { "x": 33, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10006",
				"frame": { "x": 33, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10007",
				"frame": { "x": 33, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10008",
				"frame": { "x": 66, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10009",
				"frame": { "x": 66, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10010",
				"frame": { "x": 66, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10011",
				"frame": { "x": 66, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10012",
				"frame": { "x": 99, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10013",
				"frame": { "x": 99, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10014",
				"frame": { "x": 99, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10015",
				"frame": { "x": 99, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10016",
				"frame": { "x": 132, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10017",
				"frame": { "x": 132, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10018",
				"frame": { "x": 132, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10019",
				"frame": { "x": 132, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10020",
				"frame": { "x": 165, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10021",
				"frame": { "x": 165, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10022",
				"frame": { "x": 165, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10023",
				"frame": { "x": 165, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10024",
				"frame": { "x": 198, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10025",
				"frame": { "x": 198, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10026",
				"frame": { "x": 198, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10027",
				"frame": { "x": 198, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10028",
				"frame": { "x": 231, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10029",
				"frame": { "x": 231, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10030",
				"frame": { "x": 231, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10031",
				"frame": { "x": 231, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10032",
				"frame": { "x": 264, "y": 0, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10033",
				"frame": { "x": 264, "y": 116, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10034",
				"frame": { "x": 264, "y": 232, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}
			, {
				"filename": "Symbol 10 copy instance 10035",
				"frame": { "x": 264, "y": 348, "w": 33, "h": 116 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
				"sourceSize": { "w": 33, "h": 116 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "st.png",
			"format": "RGB8",
			"size": { "w": 334, "h": 479 },
			"scale": "1"
		}
	},

	speakerJson: {
		"frames": [

			{
				"filename": "Symbol 5 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 41, "h": 30 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 41, "h": 30 },
				"sourceSize": { "w": 41, "h": 30 }
			},
			{
				"filename": "Symbol 5 instance 10001",
				"frame": { "x": 0, "y": 30, "w": 41, "h": 30 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 41, "h": 30 },
				"sourceSize": { "w": 41, "h": 30 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "s.png",
			"format": "RGB8",
			"size": { "w": 44, "h": 64 },
			"scale": "1"
		}
	},

	btnJson: {
		"frames": [

			{
				"filename": "Symbol 1 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 212, "h": 71 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 212, "h": 71 },
				"sourceSize": { "w": 212, "h": 71 }
			}
			, {
				"filename": "Symbol 1 instance 10001",
				"frame": { "x": 0, "y": 71, "w": 212, "h": 71 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 212, "h": 71 },
				"sourceSize": { "w": 212, "h": 71 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "16.5.1.104",
			"image": "b1.png",
			"format": "RGB8",
			"size": { "w": 213, "h": 144 },
			"scale": "1"
		}
	},

	replyJson: {
		"frames": [

			{
				"filename": "Symbol 8 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"sourceSize": { "w": 47, "h": 47 }
			}
			, {
				"filename": "Symbol 8 instance 10001",
				"frame": { "x": 47, "y": 0, "w": 47, "h": 47 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"sourceSize": { "w": 47, "h": 47 }
			}
			, {
				"filename": "Symbol 8 instance 10002",
				"frame": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 47, "h": 47 },
				"sourceSize": { "w": 47, "h": 47 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "Back btn.png",
			"format": "RGBA8888",
			"size": { "w": 98, "h": 48 },
			"scale": "1"
		}
	},

	backbtnJson: {
		"frames": [

			{
				"filename": "Symbol 9 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 41, "h": 29 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 41, "h": 29 },
				"sourceSize": { "w": 41, "h": 29 }
			}
			, {
				"filename": "Symbol 9 instance 10001",
				"frame": { "x": 0, "y": 29, "w": 41, "h": 29 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 41, "h": 29 },
				"sourceSize": { "w": 41, "h": 29 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "back.png",
			"format": "RGB8",
			"size": { "w": 44, "h": 64 },
			"scale": "1"
		}
	},

	tickJson: {
		"frames": [

			{
				"filename": "Symbol 10 copy instance 10000",
				"frame": { "x": 0, "y": 0, "w": 68, "h": 66 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 66 },
				"sourceSize": { "w": 68, "h": 66 }
			}
			, {
				"filename": "Symbol 10 copy instance 10001",
				"frame": { "x": 68, "y": 0, "w": 68, "h": 66 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 68, "h": 66 },
				"sourceSize": { "w": 68, "h": 66 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "20.0.1.19255",
			"image": "Right btn0002.png",
			"format": "RGBA8888",
			"size": { "w": 138, "h": 66 },
			"scale": "1"
		}
	},

	nextbtnJson: {
		"frames": [

			{
				"filename": "Symbol 6 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 59, "h": 60 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 59, "h": 60 },
				"sourceSize": { "w": 59, "h": 60 }
			}
			, {
				"filename": "Symbol 6 instance 10001",
				"frame": { "x": 0, "y": 60, "w": 59, "h": 60 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 59, "h": 60 },
				"sourceSize": { "w": 59, "h": 60 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.1.115",
			"image": "N.png",
			"format": "RGB8",
			"size": { "w": 64, "h": 128 },
			"scale": "1"
		}
	},
	homebtnJson: {
		"frames": [

			{
				"filename": "Symbol 4 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 60, "h": 60 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 60, "h": 60 },
				"sourceSize": { "w": 60, "h": 60 }
			}
			, {
				"filename": "Symbol 4 instance 10001",
				"frame": { "x": 0, "y": 60, "w": 60, "h": 60 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 60, "h": 60 },
				"sourceSize": { "w": 60, "h": 60 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.1.115",
			"image": "H.png",
			"format": "RGB8",
			"size": { "w": 64, "h": 128 },
			"scale": "1"
		}

	},
	bananaJson: {
		"frames": [

			{
				"filename": "Symbol 6 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 188, "h": 118 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 188, "h": 118 },
				"sourceSize": { "w": 188, "h": 118 }
			}
			, {
				"filename": "Symbol 6 instance 10001",
				"frame": { "x": 0, "y": 118, "w": 188, "h": 118 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 188, "h": 118 },
				"sourceSize": { "w": 188, "h": 118 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.0.107",
			"image": "3.png",
			"format": "RGBA8888",
			"size": { "w": 256, "h": 256 },
			"scale": "1"
		}
	},
	bootJson: {
		"frames": [

			{
				"filename": "Symbol 1 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 124, "h": 160 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 124, "h": 160 },
				"sourceSize": { "w": 124, "h": 160 }
			}
			, {
				"filename": "Symbol 1 instance 10001",
				"frame": { "x": 0, "y": 160, "w": 124, "h": 160 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 124, "h": 160 },
				"sourceSize": { "w": 124, "h": 160 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.0.107",
			"image": "8.png",
			"format": "RGBA8888",
			"size": { "w": 193, "h": 358 },
			"scale": "1"
		}
	},

	bubbleAniJson: {
		"frames": [

			{
				"filename": "Symbol 8 copy instance 10000",
				"frame": { "x": 0, "y": 0, "w": 111, "h": 111 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 111, "h": 111 },
				"sourceSize": { "w": 111, "h": 111 }
			}
			, {
				"filename": "Symbol 8 copy instance 10001",
				"frame": { "x": 111, "y": 0, "w": 111, "h": 111 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 111, "h": 111 },
				"sourceSize": { "w": 111, "h": 111 }
			}
			, {
				"filename": "Symbol 8 copy instance 10002",
				"frame": { "x": 222, "y": 0, "w": 111, "h": 111 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 111, "h": 111 },
				"sourceSize": { "w": 111, "h": 111 }
			}
			, {
				"filename": "Symbol 8 copy instance 10003",
				"frame": { "x": 333, "y": 0, "w": 111, "h": 111 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 111, "h": 111 },
				"sourceSize": { "w": 111, "h": 111 }
			}
			, {
				"filename": "Symbol 8 copy instance 10004",
				"frame": { "x": 444, "y": 0, "w": 111, "h": 111 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 111, "h": 111 },
				"sourceSize": { "w": 111, "h": 111 }
			}
			, {
				"filename": "Symbol 8 copy instance 10005",
				"frame": { "x": 555, "y": 0, "w": 111, "h": 111 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 111, "h": 111 },
				"sourceSize": { "w": 111, "h": 111 }
			}
			, {
				"filename": "Symbol 8 copy instance 10006",
				"frame": { "x": 666, "y": 0, "w": 111, "h": 111 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 111, "h": 111 },
				"sourceSize": { "w": 111, "h": 111 }
			}
			, {
				"filename": "Symbol 8 copy instance 10007",
				"frame": { "x": 777, "y": 0, "w": 111, "h": 111 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 111, "h": 111 },
				"sourceSize": { "w": 111, "h": 111 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "NEW 3.png",
			"format": "RGB8",
			"size": { "w": 911, "h": 121 },
			"scale": "1"
		}
	},
	canJson: {
		"frames": [

			{
				"filename": "Symbol 12 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 120, "h": 152 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 120, "h": 152 },
				"sourceSize": { "w": 120, "h": 152 }
			}
			, {
				"filename": "Symbol 12 instance 10001",
				"frame": { "x": 120, "y": 0, "w": 120, "h": 152 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 120, "h": 152 },
				"sourceSize": { "w": 120, "h": 152 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.0.107",
			"image": "6.png",
			"format": "RGBA8888",
			"size": { "w": 256, "h": 256 },
			"scale": "1"
		}
	},
	combJson: {
		"frames": [

			{
				"filename": "Symbol 22 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 235, "h": 71 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 235, "h": 71 },
				"sourceSize": { "w": 235, "h": 71 }
			}
			, {
				"filename": "Symbol 22 instance 10001",
				"frame": { "x": 0, "y": 71, "w": 235, "h": 71 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 235, "h": 71 },
				"sourceSize": { "w": 235, "h": 71 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.0.107",
			"image": "11.png",
			"format": "RGBA8888",
			"size": { "w": 256, "h": 320 },
			"scale": "1"
		}
	},
	cupJson: {
		"frames": [

			{
				"filename": "Symbol 14 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 141, "h": 145 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 141, "h": 145 },
				"sourceSize": { "w": 141, "h": 145 }
			}
			, {
				"filename": "Symbol 14 instance 10001",
				"frame": { "x": 0, "y": 145, "w": 141, "h": 145 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 141, "h": 145 },
				"sourceSize": { "w": 141, "h": 145 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.0.107",
			"image": "7.png",
			"format": "RGBA8888",
			"size": { "w": 193, "h": 358 },
			"scale": "1"
		}
	},
	hammerJson: {
		"frames": [

			{
				"filename": "Symbol 18 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 94, "h": 205 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 94, "h": 205 },
				"sourceSize": { "w": 94, "h": 205 }
			}
			, {
				"filename": "Symbol 18 instance 10001",
				"frame": { "x": 94, "y": 0, "w": 94, "h": 205 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 94, "h": 205 },
				"sourceSize": { "w": 94, "h": 205 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.0.107",
			"image": "9.png",
			"format": "RGBA8888",
			"size": { "w": 193, "h": 358 },
			"scale": "1"
		}
	},
	handJson: {
		"frames": [

			{
				"filename": "Symbol 8 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 174, "h": 107 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 174, "h": 107 },
				"sourceSize": { "w": 174, "h": 107 }
			}
			, {
				"filename": "Symbol 8 instance 10001",
				"frame": { "x": 0, "y": 107, "w": 174, "h": 107 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 174, "h": 107 },
				"sourceSize": { "w": 174, "h": 107 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.0.107",
			"image": "4.png",
			"format": "RGBA8888",
			"size": { "w": 256, "h": 256 },
			"scale": "1"
		}
	},
	horizontalJson: {
		"frames": [

			{
				"filename": "Symbol 1 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 133, "h": 133 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 133, "h": 133 },
				"sourceSize": { "w": 133, "h": 133 }
			}
			, {
				"filename": "Symbol 1 instance 10001",
				"frame": { "x": 0, "y": 133, "w": 133, "h": 133 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 133, "h": 133 },
				"sourceSize": { "w": 133, "h": 133 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.0.107",
			"image": "B1.png",
			"format": "RGBA8888",
			"size": { "w": 153, "h": 288 },
			"scale": "1"
		}
	},
	keyJson: {
		"frames": [

			{
				"filename": "Symbol 24 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 195, "h": 85 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 195, "h": 85 },
				"sourceSize": { "w": 195, "h": 85 }
			}
			, {
				"filename": "Symbol 24 instance 10001",
				"frame": { "x": 0, "y": 85, "w": 195, "h": 85 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 195, "h": 85 },
				"sourceSize": { "w": 195, "h": 85 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.0.107",
			"image": "12.png",
			"format": "RGBA8888",
			"size": { "w": 256, "h": 320 },
			"scale": "1"
		}
	},
	legJson: {
		"frames": [

			{
				"filename": "Symbol 2 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 94, "h": 192 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 94, "h": 192 },
				"sourceSize": { "w": 94, "h": 192 }
			}
			, {
				"filename": "Symbol 2 instance 10001",
				"frame": { "x": 94, "y": 0, "w": 94, "h": 192 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 94, "h": 192 },
				"sourceSize": { "w": 94, "h": 192 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.0.107",
			"image": "1.png",
			"format": "RGBA8888",
			"size": { "w": 256, "h": 256 },
			"scale": "1"
		}
	},
	triangleJson: {
		"frames": [

			{
				"filename": "Symbol 20 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 197, "h": 138 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 197, "h": 138 },
				"sourceSize": { "w": 197, "h": 138 }
			}
			, {
				"filename": "Symbol 20 instance 10001",
				"frame": { "x": 0, "y": 138, "w": 197, "h": 138 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 197, "h": 138 },
				"sourceSize": { "w": 197, "h": 138 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.0.107",
			"image": "10.png",
			"format": "RGBA8888",
			"size": { "w": 256, "h": 320 },
			"scale": "1"
		}
	},
	umbrellaJson: {
		"frames": [

			{
				"filename": "Symbol 4 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 148, "h": 166 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 148, "h": 166 },
				"sourceSize": { "w": 148, "h": 166 }
			}
			, {
				"filename": "Symbol 4 instance 10001",
				"frame": { "x": 0, "y": 166, "w": 148, "h": 166 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 148, "h": 166 },
				"sourceSize": { "w": 148, "h": 166 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.0.107",
			"image": "2.png",
			"format": "RGBA8888",
			"size": { "w": 256, "h": 512 },
			"scale": "1"
		}
	},
	verticalJson: {
		"frames": [

			{
				"filename": "Symbol 1 copy instance 10000",
				"frame": { "x": 0, "y": 0, "w": 133, "h": 133 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 133, "h": 133 },
				"sourceSize": { "w": 133, "h": 133 }
			}
			, {
				"filename": "Symbol 1 copy instance 10001",
				"frame": { "x": 0, "y": 133, "w": 133, "h": 133 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 133, "h": 133 },
				"sourceSize": { "w": 133, "h": 133 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.0.107",
			"image": "B2.png",
			"format": "RGBA8888",
			"size": { "w": 153, "h": 288 },
			"scale": "1"
		}
	},
	watercanJson: {
		"frames": [

			{
				"filename": "Symbol 10 instance 10000",
				"frame": { "x": 0, "y": 0, "w": 207, "h": 120 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 207, "h": 120 },
				"sourceSize": { "w": 207, "h": 120 }
			}
			, {
				"filename": "Symbol 10 instance 10001",
				"frame": { "x": 0, "y": 120, "w": 207, "h": 120 },
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": { "x": 0, "y": 0, "w": 207, "h": 120 },
				"sourceSize": { "w": 207, "h": 120 }
			}],
		"meta": {
			"app": "Adobe Animate",
			"version": "18.0.0.107",
			"image": "5.png",
			"format": "RGBA8888",
			"size": { "w": 256, "h": 256 },
			"scale": "1"
		}
	}

};

