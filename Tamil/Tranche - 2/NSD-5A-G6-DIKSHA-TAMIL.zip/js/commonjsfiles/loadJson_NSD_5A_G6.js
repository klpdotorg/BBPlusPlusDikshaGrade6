var NSD_5A_G6_JSON = {

    starAnimJson: {
        "frames": [

            {
                "filename": "Symbol 10 copy instance 10000",
                "frame": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10001",
                "frame": { "x": 0, "y": 116, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10002",
                "frame": { "x": 0, "y": 232, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10003",
                "frame": { "x": 0, "y": 348, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10004",
                "frame": { "x": 33, "y": 0, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10005",
                "frame": { "x": 33, "y": 116, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10006",
                "frame": { "x": 33, "y": 232, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10007",
                "frame": { "x": 33, "y": 348, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10008",
                "frame": { "x": 66, "y": 0, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10009",
                "frame": { "x": 66, "y": 116, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10010",
                "frame": { "x": 66, "y": 232, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10011",
                "frame": { "x": 66, "y": 348, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10012",
                "frame": { "x": 99, "y": 0, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10013",
                "frame": { "x": 99, "y": 116, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10014",
                "frame": { "x": 99, "y": 232, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10015",
                "frame": { "x": 99, "y": 348, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10016",
                "frame": { "x": 132, "y": 0, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10017",
                "frame": { "x": 132, "y": 116, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10018",
                "frame": { "x": 132, "y": 232, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10019",
                "frame": { "x": 132, "y": 348, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10020",
                "frame": { "x": 165, "y": 0, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10021",
                "frame": { "x": 165, "y": 116, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10022",
                "frame": { "x": 165, "y": 232, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10023",
                "frame": { "x": 165, "y": 348, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10024",
                "frame": { "x": 198, "y": 0, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10025",
                "frame": { "x": 198, "y": 116, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10026",
                "frame": { "x": 198, "y": 232, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10027",
                "frame": { "x": 198, "y": 348, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10028",
                "frame": { "x": 231, "y": 0, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10029",
                "frame": { "x": 231, "y": 116, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10030",
                "frame": { "x": 231, "y": 232, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10031",
                "frame": { "x": 231, "y": 348, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10032",
                "frame": { "x": 264, "y": 0, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10033",
                "frame": { "x": 264, "y": 116, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10034",
                "frame": { "x": 264, "y": 232, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }
            , {
                "filename": "Symbol 10 copy instance 10035",
                "frame": { "x": 264, "y": 348, "w": 33, "h": 116 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 33, "h": 116 },
                "sourceSize": { "w": 33, "h": 116 }
            }],
        "meta": {
            "app": "Adobe Animate",
            "version": "15.1.0.210",
            "image": "st.png",
            "format": "RGB8",
            "size": { "w": 334, "h": 479 },
            "scale": "1"
        }
    },

    speakerJson: {
        "frames": [

            {
                "filename": "Symbol 5 instance 10000",
                "frame": { "x": 0, "y": 0, "w": 41, "h": 30 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 41, "h": 30 },
                "sourceSize": { "w": 41, "h": 30 }
            },
            {
                "filename": "Symbol 5 instance 10001",
                "frame": { "x": 0, "y": 30, "w": 41, "h": 30 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 41, "h": 30 },
                "sourceSize": { "w": 41, "h": 30 }
            }],
        "meta": {
            "app": "Adobe Animate",
            "version": "15.1.0.210",
            "image": "s.png",
            "format": "RGB8",
            "size": { "w": 44, "h": 64 },
            "scale": "1"
        }
    },

    btnJson: {
        "frames": [

            {
                "filename": "Symbol 1 instance 10000",
                "frame": { "x": 0, "y": 0, "w": 212, "h": 71 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 212, "h": 71 },
                "sourceSize": { "w": 212, "h": 71 }
            }
            , {
                "filename": "Symbol 1 instance 10001",
                "frame": { "x": 0, "y": 71, "w": 212, "h": 71 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 212, "h": 71 },
                "sourceSize": { "w": 212, "h": 71 }
            }],
        "meta": {
            "app": "Adobe Animate",
            "version": "16.5.1.104",
            "image": "b1.png",
            "format": "RGB8",
            "size": { "w": 213, "h": 144 },
            "scale": "1"
        }
    },

    replyJson: {
        "frames": [

            {
                "filename": "Symbol 8 instance 10000",
                "frame": { "x": 0, "y": 0, "w": 47, "h": 47 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 47, "h": 47 },
                "sourceSize": { "w": 47, "h": 47 }
            }
            , {
                "filename": "Symbol 8 instance 10001",
                "frame": { "x": 47, "y": 0, "w": 47, "h": 47 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 47, "h": 47 },
                "sourceSize": { "w": 47, "h": 47 }
            }
            , {
                "filename": "Symbol 8 instance 10002",
                "frame": { "x": 0, "y": 0, "w": 47, "h": 47 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 47, "h": 47 },
                "sourceSize": { "w": 47, "h": 47 }
            }],
        "meta": {
            "app": "Adobe Animate",
            "version": "15.1.0.210",
            "image": "Back btn.png",
            "format": "RGBA8888",
            "size": { "w": 98, "h": 48 },
            "scale": "1"
        }
    },

    backbtnJson: {
        "frames": [

            {
                "filename": "Symbol 9 instance 10000",
                "frame": { "x": 0, "y": 0, "w": 41, "h": 29 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 41, "h": 29 },
                "sourceSize": { "w": 41, "h": 29 }
            }
            , {
                "filename": "Symbol 9 instance 10001",
                "frame": { "x": 0, "y": 29, "w": 41, "h": 29 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 41, "h": 29 },
                "sourceSize": { "w": 41, "h": 29 }
            }],
        "meta": {
            "app": "Adobe Animate",
            "version": "15.1.0.210",
            "image": "back.png",
            "format": "RGB8",
            "size": { "w": 44, "h": 64 },
            "scale": "1"
        }
    },

    tickJson: {
        "frames": [

            {
                "filename": "Symbol 14 copy instance 10000",
                "frame": { "x": 0, "y": 0, "w": 58, "h": 61 },
                "rotated": false,
                "trimmed": true,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 64, "h": 68 },
                "sourceSize": { "w": 64, "h": 68 }
            }
            , {
                "filename": "Symbol 14 copy instance 10001",
                "frame": { "x": 58, "y": 0, "w": 59, "h": 62 },
                "rotated": false,
                "trimmed": true,
                "spriteSourceSize": { "x": 5, "y": 6, "w": 64, "h": 68 },
                "sourceSize": { "w": 64, "h": 68 }
            }],
        "meta": {
            "app": "Adobe Animate",
            "version": "15.1.0.210",
            "image": "right btn.png",
            "format": "RGB8",
            "size": { "w": 121, "h": 62 },
            "scale": "1"
        }
    },

    nextbtnJson: {
        "frames": [

            {
                "filename": "Symbol 6 instance 10000",
                "frame": { "x": 0, "y": 0, "w": 59, "h": 60 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 59, "h": 60 },
                "sourceSize": { "w": 59, "h": 60 }
            }
            , {
                "filename": "Symbol 6 instance 10001",
                "frame": { "x": 0, "y": 60, "w": 59, "h": 60 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 59, "h": 60 },
                "sourceSize": { "w": 59, "h": 60 }
            }],
        "meta": {
            "app": "Adobe Animate",
            "version": "18.0.1.115",
            "image": "N.png",
            "format": "RGB8",
            "size": { "w": 64, "h": 128 },
            "scale": "1"
        }
    },
    homebtnJson: {
        "frames": [

            {
                "filename": "Symbol 4 instance 10000",
                "frame": { "x": 0, "y": 0, "w": 60, "h": 60 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 60, "h": 60 },
                "sourceSize": { "w": 60, "h": 60 }
            }
            , {
                "filename": "Symbol 4 instance 10001",
                "frame": { "x": 0, "y": 60, "w": 60, "h": 60 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 60, "h": 60 },
                "sourceSize": { "w": 60, "h": 60 }
            }],
        "meta": {
            "app": "Adobe Animate",
            "version": "18.0.1.115",
            "image": "H.png",
            "format": "RGB8",
            "size": { "w": 64, "h": 128 },
            "scale": "1"
        }

    },

    numberpadJson: {
        "frames": [

            {
                "filename": "Symbol 11 instance 10000",
                "frame": { "x": 0, "y": 0, "w": 49, "h": 49 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
                "sourceSize": { "w": 49, "h": 49 }
            }
            , {
                "filename": "Symbol 11 instance 10001",
                "frame": { "x": 49, "y": 0, "w": 49, "h": 49 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
                "sourceSize": { "w": 49, "h": 49 }
            }
            , {
                "filename": "Symbol 11 instance 10002",
                "frame": { "x": 98, "y": 0, "w": 49, "h": 49 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
                "sourceSize": { "w": 49, "h": 49 }
            }
            , {
                "filename": "Symbol 11 instance 10003",
                "frame": { "x": 147, "y": 0, "w": 49, "h": 49 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
                "sourceSize": { "w": 49, "h": 49 }
            }
            , {
                "filename": "Symbol 11 instance 10004",
                "frame": { "x": 196, "y": 0, "w": 49, "h": 49 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
                "sourceSize": { "w": 49, "h": 49 }
            }
            , {
                "filename": "Symbol 11 instance 10005",
                "frame": { "x": 245, "y": 0, "w": 49, "h": 49 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
                "sourceSize": { "w": 49, "h": 49 }
            }
            , {
                "filename": "Symbol 11 instance 10006",
                "frame": { "x": 294, "y": 0, "w": 49, "h": 49 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
                "sourceSize": { "w": 49, "h": 49 }
            }
            , {
                "filename": "Symbol 11 instance 10007",
                "frame": { "x": 343, "y": 0, "w": 49, "h": 49 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
                "sourceSize": { "w": 49, "h": 49 }
            }
            , {
                "filename": "Symbol 11 instance 10008",
                "frame": { "x": 392, "y": 0, "w": 49, "h": 49 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
                "sourceSize": { "w": 49, "h": 49 }
            }
            , {
                "filename": "Symbol 11 instance 10009",
                "frame": { "x": 441, "y": 0, "w": 49, "h": 49 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
                "sourceSize": { "w": 49, "h": 49 }
            }
            , {
                "filename": "Symbol 11 instance 10010",
                "frame": { "x": 490, "y": 0, "w": 49, "h": 49 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
                "sourceSize": { "w": 49, "h": 49 }
            }
            , {
                "filename": "Symbol 11 instance 10011",
                "frame": { "x": 539, "y": 0, "w": 49, "h": 49 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
                "sourceSize": { "w": 49, "h": 49 }
            }
            , {
                "filename": "Symbol 11 instance 10012",
                "frame": { "x": 588, "y": 0, "w": 49, "h": 49 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 49, "h": 49 },
                "sourceSize": { "w": 49, "h": 49 }
            }],
        "meta": {
            "app": "Adobe Animate",
            "version": "22.0.4.185",
            "image": "Number pad anim.png",
            "format": "RGBA8888",
            "size": { "w": 637, "h": 49 },
            "scale": "1"
        }
    },



    TickbtnJson: {
        "frames": [

            {
                "filename": "Symbol 10 instance 10000",
                "frame": { "x": 0, "y": 0, "w": 67, "h": 68 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 67, "h": 68 },
                "sourceSize": { "w": 67, "h": 68 }
            }
            , {
                "filename": "Symbol 10 instance 10001",
                "frame": { "x": 67, "y": 0, "w": 67, "h": 68 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 67, "h": 68 },
                "sourceSize": { "w": 67, "h": 68 }
            }],
        "meta": {
            "app": "Adobe Animate",
            "version": "20.0.1.19255",
            "image": "NSD-3A-G6.png",
            "format": "RGBA8888",
            "size": { "w": 134, "h": 68 },
            "scale": "1"
        }
    },

    SquareBoxJson: {
        "frames": [

            {
                "filename": "Symbol 5 instance 10000",
                "frame": { "x": 0, "y": 0, "w": 55, "h": 54 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 55, "h": 54 },
                "sourceSize": { "w": 55, "h": 54 }
            }
            , {
                "filename": "Symbol 5 instance 10001",
                "frame": { "x": 55, "y": 0, "w": 55, "h": 54 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 55, "h": 54 },
                "sourceSize": { "w": 55, "h": 54 }
            }],
        "meta": {
            "app": "Adobe Animate",
            "version": "20.0.1.19255",
            "image": "NSF-2B-G6 new box.png",
            "format": "RGBA8888",
            "size": { "w": 110, "h": 54 },
            "scale": "1"
        }
    },

    HomeBtnJson: {
        "frames": [

            {
                "filename": "Symbol 4 instance 10000",
                "frame": { "x": 0, "y": 0, "w": 60, "h": 60 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 60, "h": 60 },
                "sourceSize": { "w": 60, "h": 60 }
            }
            , {
                "filename": "Symbol 4 instance 10001",
                "frame": { "x": 0, "y": 60, "w": 60, "h": 60 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 60, "h": 60 },
                "sourceSize": { "w": 60, "h": 60 }
            }],
        "meta": {
            "app": "Adobe Animate",
            "version": "18.0.1.115",
            "image": "H.png",
            "format": "RGB8",
            "size": { "w": 64, "h": 128 },
            "scale": "1"
        }
    },


    YellowBoxJson: {
        "frames": [

            {
                "filename": "Symbol 4 instance 10000",
                "frame": { "x": 0, "y": 0, "w": 293, "h": 293 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 293, "h": 293 },
                "sourceSize": { "w": 293, "h": 293 }
            }
            , {
                "filename": "Symbol 4 instance 10001",
                "frame": { "x": 293, "y": 0, "w": 293, "h": 293 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 293, "h": 293 },
                "sourceSize": { "w": 293, "h": 293 }
            }],
        "meta": {
            "app": "Adobe Animate",
            "version": "22.0.4.185",
            "image": "yellow box 10X10.png",
            "format": "RGBA8888",
            "size": { "w": 587, "h": 293 },
            "scale": "1"
        }
    },

    GreenLeverJson: {
        "frames": [

            {
                "filename": "Symbol 4 copy instance 10000",
                "frame": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }
            , {
                "filename": "Symbol 4 copy instance 10001",
                "frame": { "x": 92, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }
            , {
                "filename": "Symbol 4 copy instance 10002",
                "frame": { "x": 184, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }
            , {
                "filename": "Symbol 4 copy instance 10003",
                "frame": { "x": 276, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }
            , {
                "filename": "Symbol 4 copy instance 10004",
                "frame": { "x": 368, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }
            , {
                "filename": "Symbol 4 copy instance 10005",
                "frame": { "x": 460, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }
            , {
                "filename": "Symbol 4 copy instance 10006",
                "frame": { "x": 552, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }
            , {
                "filename": "Symbol 4 copy instance 10007",
                "frame": { "x": 644, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }
            , {
                "filename": "Symbol 4 copy instance 10008",
                "frame": { "x": 736, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }
            , {
                "filename": "Symbol 4 copy instance 10009",
                "frame": { "x": 828, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }],
        "meta": {
            "app": "Adobe Animate",
            "version": "22.0.0.93",
            "image": "Green Liver.png",
            "format": "RGBA8888",
            "size": { "w": 924, "h": 91 },
            "scale": "1"
        }
    },

    YellowLeverJson: {
        "frames": [

            {
                "filename": "Symbol 4 copy 2 instance 10000",
                "frame": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }
            , {
                "filename": "Symbol 4 copy 2 instance 10001",
                "frame": { "x": 92, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }
            , {
                "filename": "Symbol 4 copy 2 instance 10002",
                "frame": { "x": 184, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }
            , {
                "filename": "Symbol 4 copy 2 instance 10003",
                "frame": { "x": 276, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }
            , {
                "filename": "Symbol 4 copy 2 instance 10004",
                "frame": { "x": 368, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }
            , {
                "filename": "Symbol 4 copy 2 instance 10005",
                "frame": { "x": 460, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }
            , {
                "filename": "Symbol 4 copy 2 instance 10006",
                "frame": { "x": 552, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }
            , {
                "filename": "Symbol 4 copy 2 instance 10007",
                "frame": { "x": 644, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }
            , {
                "filename": "Symbol 4 copy 2 instance 10008",
                "frame": { "x": 736, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }
            , {
                "filename": "Symbol 4 copy 2 instance 10009",
                "frame": { "x": 828, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }],
        "meta": {
            "app": "Adobe Animate",
            "version": "22.0.0.93",
            "image": "Yellow Liver.png",
            "format": "RGBA8888",
            "size": { "w": 924, "h": 91 },
            "scale": "1"
        }
    },

    YellowCoinAnimJson: {
        "frames": [

            {
                "filename": "Symbol 1 copy 10 instance 10000",
                "frame": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10001",
                "frame": { "x": 85, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10002",
                "frame": { "x": 170, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10003",
                "frame": { "x": 255, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10004",
                "frame": { "x": 340, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10005",
                "frame": { "x": 425, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10006",
                "frame": { "x": 510, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10007",
                "frame": { "x": 595, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10008",
                "frame": { "x": 680, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10009",
                "frame": { "x": 765, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10010",
                "frame": { "x": 850, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10011",
                "frame": { "x": 935, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10012",
                "frame": { "x": 1020, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10013",
                "frame": { "x": 1105, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10014",
                "frame": { "x": 1190, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10015",
                "frame": { "x": 1275, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10016",
                "frame": { "x": 1360, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10017",
                "frame": { "x": 1445, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10018",
                "frame": { "x": 1530, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10019",
                "frame": { "x": 1615, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10020",
                "frame": { "x": 1700, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10021",
                "frame": { "x": 1785, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10022",
                "frame": { "x": 1870, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10023",
                "frame": { "x": 1955, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10024",
                "frame": { "x": 2040, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10025",
                "frame": { "x": 2125, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10026",
                "frame": { "x": 2210, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10027",
                "frame": { "x": 2295, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10028",
                "frame": { "x": 2380, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10029",
                "frame": { "x": 2465, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10030",
                "frame": { "x": 2550, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10031",
                "frame": { "x": 2635, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10032",
                "frame": { "x": 2720, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10033",
                "frame": { "x": 2805, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10034",
                "frame": { "x": 2890, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10035",
                "frame": { "x": 2975, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10036",
                "frame": { "x": 3060, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10037",
                "frame": { "x": 3145, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10038",
                "frame": { "x": 3230, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10039",
                "frame": { "x": 3315, "y": 0, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 10 instance 10040",
                "frame": { "x": 0, "y": 232, "w": 85, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 85, "h": 232 },
                "sourceSize": { "w": 85, "h": 232 }
            }],
        "meta": {
            "app": "Adobe Animate",
            "version": "22.0.0.93",
            "image": "Yellow coin going.png",
            "format": "RGBA8888",
            "size": { "w": 3409, "h": 466 },
            "scale": "1"
        }
    }

    ,

    OrangeCoinAnimJson: {
        "frames": [

            {
                "filename": "Symbol 1 copy 8 instance 10000",
                "frame": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10001",
                "frame": { "x": 84, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10002",
                "frame": { "x": 168, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10003",
                "frame": { "x": 252, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10004",
                "frame": { "x": 336, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10005",
                "frame": { "x": 420, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10006",
                "frame": { "x": 504, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10007",
                "frame": { "x": 588, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10008",
                "frame": { "x": 672, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10009",
                "frame": { "x": 756, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10010",
                "frame": { "x": 840, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10011",
                "frame": { "x": 924, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10012",
                "frame": { "x": 1008, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10013",
                "frame": { "x": 1092, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10014",
                "frame": { "x": 1176, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10015",
                "frame": { "x": 1260, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10016",
                "frame": { "x": 1344, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10017",
                "frame": { "x": 1428, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10018",
                "frame": { "x": 1512, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10019",
                "frame": { "x": 1596, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10020",
                "frame": { "x": 1680, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10021",
                "frame": { "x": 1764, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10022",
                "frame": { "x": 1848, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10023",
                "frame": { "x": 1932, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10024",
                "frame": { "x": 2016, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10025",
                "frame": { "x": 2100, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10026",
                "frame": { "x": 2184, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10027",
                "frame": { "x": 2268, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10028",
                "frame": { "x": 2352, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10029",
                "frame": { "x": 2436, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10030",
                "frame": { "x": 2520, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10031",
                "frame": { "x": 2604, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10032",
                "frame": { "x": 2688, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10033",
                "frame": { "x": 2772, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10034",
                "frame": { "x": 2856, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10035",
                "frame": { "x": 2940, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10036",
                "frame": { "x": 3024, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10037",
                "frame": { "x": 3108, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10038",
                "frame": { "x": 3192, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10039",
                "frame": { "x": 3276, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 8 instance 10040",
                "frame": { "x": 0, "y": 232, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }],
        "meta": {
            "app": "Adobe Animate",
            "version": "22.0.0.93",
            "image": "Orange coin going.png",
            "format": "RGBA8888",
            "size": { "w": 3409, "h": 466 },
            "scale": "1"
        }
    }
    ,

    OrangeLeverJson: {
        "frames": [

            {
                "filename": "Symbol 4 instance 10000",
                "frame": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }
            , {
                "filename": "Symbol 4 instance 10001",
                "frame": { "x": 92, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }
            , {
                "filename": "Symbol 4 instance 10002",
                "frame": { "x": 184, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }
            , {
                "filename": "Symbol 4 instance 10003",
                "frame": { "x": 276, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }
            , {
                "filename": "Symbol 4 instance 10004",
                "frame": { "x": 368, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }
            , {
                "filename": "Symbol 4 instance 10005",
                "frame": { "x": 460, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }
            , {
                "filename": "Symbol 4 instance 10006",
                "frame": { "x": 552, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }
            , {
                "filename": "Symbol 4 instance 10007",
                "frame": { "x": 644, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }
            , {
                "filename": "Symbol 4 instance 10008",
                "frame": { "x": 736, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }
            , {
                "filename": "Symbol 4 instance 10009",
                "frame": { "x": 828, "y": 0, "w": 92, "h": 91 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 92, "h": 91 },
                "sourceSize": { "w": 92, "h": 91 }
            }],
        "meta": {
            "app": "Adobe Animate",
            "version": "22.0.0.93",
            "image": "Orenge Liver.png",
            "format": "RGBA8888",
            "size": { "w": 924, "h": 91 },
            "scale": "1"
        }
    },

    GreenCoinAnimJSON: {
        "frames": [

            {
                "filename": "Symbol 1 copy 9 instance 10000",
                "frame": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10001",
                "frame": { "x": 84, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10002",
                "frame": { "x": 168, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10003",
                "frame": { "x": 252, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10004",
                "frame": { "x": 336, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10005",
                "frame": { "x": 420, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10006",
                "frame": { "x": 504, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10007",
                "frame": { "x": 588, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10008",
                "frame": { "x": 672, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10009",
                "frame": { "x": 756, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10010",
                "frame": { "x": 840, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10011",
                "frame": { "x": 924, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10012",
                "frame": { "x": 1008, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10013",
                "frame": { "x": 1092, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10014",
                "frame": { "x": 1176, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10015",
                "frame": { "x": 1260, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10016",
                "frame": { "x": 1344, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10017",
                "frame": { "x": 1428, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10018",
                "frame": { "x": 1512, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10019",
                "frame": { "x": 1596, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10020",
                "frame": { "x": 1680, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10021",
                "frame": { "x": 1764, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10022",
                "frame": { "x": 1848, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10023",
                "frame": { "x": 1932, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10024",
                "frame": { "x": 2016, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10025",
                "frame": { "x": 2100, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10026",
                "frame": { "x": 2184, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10027",
                "frame": { "x": 2268, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10028",
                "frame": { "x": 2352, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10029",
                "frame": { "x": 2436, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10030",
                "frame": { "x": 2520, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10031",
                "frame": { "x": 2604, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10032",
                "frame": { "x": 2688, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10033",
                "frame": { "x": 2772, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10034",
                "frame": { "x": 2856, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10035",
                "frame": { "x": 2940, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10036",
                "frame": { "x": 3024, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10037",
                "frame": { "x": 3108, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10038",
                "frame": { "x": 3192, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10039",
                "frame": { "x": 3276, "y": 0, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }
            , {
                "filename": "Symbol 1 copy 9 instance 10040",
                "frame": { "x": 0, "y": 232, "w": 84, "h": 232 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 84, "h": 232 },
                "sourceSize": { "w": 84, "h": 232 }
            }],
        "meta": {
            "app": "Adobe Animate",
            "version": "22.0.0.93",
            "image": "Green coin going.png",
            "format": "RGBA8888",
            "size": { "w": 3409, "h": 466 },
            "scale": "1"
        }
    },


    NumberVSmallJson: {
        "frames": [

            {
                "filename": "Symbol 17 copy 2 instance 10000",
                "frame": { "x": 0, "y": 0, "w": 32, "h": 40 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 32, "h": 40 },
                "sourceSize": { "w": 32, "h": 40 }
            }
            , {
                "filename": "Symbol 17 copy 2 instance 10001",
                "frame": { "x": 32, "y": 0, "w": 28, "h": 40 },
                "rotated": false,
                "trimmed": true,
                "spriteSourceSize": { "x": 2, "y": 0, "w": 32, "h": 40 },
                "sourceSize": { "w": 32, "h": 40 }
            }
            , {
                "filename": "Symbol 17 copy 2 instance 10002",
                "frame": { "x": 60, "y": 0, "w": 30, "h": 40 },
                "rotated": false,
                "trimmed": true,
                "spriteSourceSize": { "x": 1, "y": 0, "w": 32, "h": 40 },
                "sourceSize": { "w": 32, "h": 40 }
            }
            , {
                "filename": "Symbol 17 copy 2 instance 10003",
                "frame": { "x": 90, "y": 0, "w": 30, "h": 40 },
                "rotated": false,
                "trimmed": true,
                "spriteSourceSize": { "x": 1, "y": 0, "w": 32, "h": 40 },
                "sourceSize": { "w": 32, "h": 40 }
            }
            , {
                "filename": "Symbol 17 copy 2 instance 10004",
                "frame": { "x": 120, "y": 0, "w": 30, "h": 40 },
                "rotated": false,
                "trimmed": true,
                "spriteSourceSize": { "x": 1, "y": 0, "w": 32, "h": 40 },
                "sourceSize": { "w": 32, "h": 40 }
            }
            , {
                "filename": "Symbol 17 copy 2 instance 10005",
                "frame": { "x": 0, "y": 40, "w": 28, "h": 40 },
                "rotated": false,
                "trimmed": true,
                "spriteSourceSize": { "x": 2, "y": 0, "w": 32, "h": 40 },
                "sourceSize": { "w": 32, "h": 40 }
            }
            , {
                "filename": "Symbol 17 copy 2 instance 10006",
                "frame": { "x": 28, "y": 40, "w": 28, "h": 40 },
                "rotated": false,
                "trimmed": true,
                "spriteSourceSize": { "x": 2, "y": 0, "w": 32, "h": 40 },
                "sourceSize": { "w": 32, "h": 40 }
            }
            , {
                "filename": "Symbol 17 copy 2 instance 10007",
                "frame": { "x": 56, "y": 40, "w": 28, "h": 40 },
                "rotated": false,
                "trimmed": true,
                "spriteSourceSize": { "x": 2, "y": 0, "w": 32, "h": 40 },
                "sourceSize": { "w": 32, "h": 40 }
            }
            , {
                "filename": "Symbol 17 copy 2 instance 10008",
                "frame": { "x": 84, "y": 40, "w": 28, "h": 40 },
                "rotated": false,
                "trimmed": true,
                "spriteSourceSize": { "x": 2, "y": 0, "w": 32, "h": 40 },
                "sourceSize": { "w": 32, "h": 40 }
            }
            , {
                "filename": "Symbol 17 copy 2 instance 10009",
                "frame": { "x": 112, "y": 40, "w": 28, "h": 40 },
                "rotated": false,
                "trimmed": true,
                "spriteSourceSize": { "x": 2, "y": 0, "w": 32, "h": 40 },
                "sourceSize": { "w": 32, "h": 40 }
            }],
        "meta": {
            "app": "Adobe Animate",
            "version": "15.1.0.210",
            "image": "Journey 3 0 to 9.png",
            "format": "RGB8",
            "size": { "w": 152, "h": 80 },
            "scale": "1"
        }
    },

    CounterBoxJson: {
        "frames": [

            {
                "filename": "Symbol 21 instance 10000",
                "frame": { "x": 0, "y": 0, "w": 160, "h": 201 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 160, "h": 201 },
                "sourceSize": { "w": 160, "h": 201 }
            }
            , {
                "filename": "Symbol 21 instance 10001",
                "frame": { "x": 160, "y": 0, "w": 160, "h": 201 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 160, "h": 201 },
                "sourceSize": { "w": 160, "h": 201 }
            }
            , {
                "filename": "Symbol 21 instance 10002",
                "frame": { "x": 320, "y": 0, "w": 160, "h": 201 },
                "rotated": false,
                "trimmed": false,
                "spriteSourceSize": { "x": 0, "y": 0, "w": 160, "h": 201 },
                "sourceSize": { "w": 160, "h": 201 }
            }],
        "meta": {
            "app": "Adobe Animate",
            "version": "22.0.0.93",
            "image": "Text box_5.png",
            "format": "RGBA8888",
            "size": { "w": 480, "h": 201 },
            "scale": "1"
        }
    },

    bulbBtnJson	: {"frames": [

        {
            "filename": "Symbol 1 instance 10000",
            "frame": {"x":0,"y":0,"w":66,"h":49},
            "rotated": false,
            "trimmed": false,
            "spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
            "sourceSize": {"w":66,"h":49}
        }
        ,{
            "filename": "Symbol 1 instance 10001",
            "frame": {"x":66,"y":0,"w":66,"h":49},
            "rotated": false,
            "trimmed": false,
            "spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
            "sourceSize": {"w":66,"h":49}
        }
        ,{
            "filename": "Symbol 1 instance 10002",
            "frame": {"x":132,"y":0,"w":66,"h":49},
            "rotated": false,
            "trimmed": false,
            "spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
            "sourceSize": {"w":66,"h":49}
        }
        ,{
            "filename": "Symbol 1 instance 10003",
            "frame": {"x":0,"y":49,"w":66,"h":49},
            "rotated": false,
            "trimmed": false,
            "spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
            "sourceSize": {"w":66,"h":49}
        }
        ,{
            "filename": "Symbol 1 instance 10004",
            "frame": {"x":66,"y":49,"w":66,"h":49},
            "rotated": false,
            "trimmed": false,
            "spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
            "sourceSize": {"w":66,"h":49}
        }
        ,{
            "filename": "Symbol 1 instance 10005",
            "frame": {"x":132,"y":49,"w":66,"h":49},
            "rotated": false,
            "trimmed": false,
            "spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
            "sourceSize": {"w":66,"h":49}
        }
        ,{
            "filename": "Symbol 1 instance 10006",
            "frame": {"x":0,"y":98,"w":66,"h":49},
            "rotated": false,
            "trimmed": false,
            "spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
            "sourceSize": {"w":66,"h":49}
        }
        ,{
            "filename": "Symbol 1 instance 10007",
            "frame": {"x":66,"y":98,"w":66,"h":49},
            "rotated": false,
            "trimmed": false,
            "spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
            "sourceSize": {"w":66,"h":49}
        }
        ,{
            "filename": "Symbol 1 instance 10008",
            "frame": {"x":132,"y":98,"w":66,"h":49},
            "rotated": false,
            "trimmed": false,
            "spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
            "sourceSize": {"w":66,"h":49}
        }
        ,{
            "filename": "Symbol 1 instance 10009",
            "frame": {"x":0,"y":147,"w":66,"h":49},
            "rotated": false,
            "trimmed": false,
            "spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
            "sourceSize": {"w":66,"h":49}
        }
        ,{
            "filename": "Symbol 1 instance 10010",
            "frame": {"x":66,"y":147,"w":66,"h":49},
            "rotated": false,
            "trimmed": false,
            "spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
            "sourceSize": {"w":66,"h":49}
        }
        ,{
            "filename": "Symbol 1 instance 10011",
            "frame": {"x":132,"y":147,"w":66,"h":49},
            "rotated": false,
            "trimmed": false,
            "spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
            "sourceSize": {"w":66,"h":49}
        }
        ,{
            "filename": "Symbol 1 instance 10012",
            "frame": {"x":0,"y":196,"w":66,"h":49},
            "rotated": false,
            "trimmed": false,
            "spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
            "sourceSize": {"w":66,"h":49}
        }
        ,{
            "filename": "Symbol 1 instance 10013",
            "frame": {"x":66,"y":196,"w":66,"h":49},
            "rotated": false,
            "trimmed": false,
            "spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
            "sourceSize": {"w":66,"h":49}
        }
        ,{
            "filename": "Symbol 1 instance 10014",
            "frame": {"x":132,"y":196,"w":66,"h":49},
            "rotated": false,
            "trimmed": false,
            "spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
            "sourceSize": {"w":66,"h":49}
        }
        ,{
            "filename": "Symbol 1 instance 10015",
            "frame": {"x":0,"y":245,"w":66,"h":49},
            "rotated": false,
            "trimmed": false,
            "spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
            "sourceSize": {"w":66,"h":49}
        }
        ,{
            "filename": "Symbol 1 instance 10016",
            "frame": {"x":66,"y":245,"w":66,"h":49},
            "rotated": false,
            "trimmed": false,
            "spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
            "sourceSize": {"w":66,"h":49}
        }
        ,{
            "filename": "Symbol 1 instance 10017",
            "frame": {"x":132,"y":245,"w":66,"h":49},
            "rotated": false,
            "trimmed": false,
            "spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
            "sourceSize": {"w":66,"h":49}
        }
        ,{
            "filename": "Symbol 1 instance 10018",
            "frame": {"x":0,"y":294,"w":66,"h":49},
            "rotated": false,
            "trimmed": false,
            "spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
            "sourceSize": {"w":66,"h":49}
        }],
        "meta": {
            "app": "Adobe Animate",
            "version": "18.0.0.107",
            "image": "bulb anim.png",
            "format": "RGBA8888",
            "size": {"w":198,"h":347},
            "scale": "1"
        }
    }

};


