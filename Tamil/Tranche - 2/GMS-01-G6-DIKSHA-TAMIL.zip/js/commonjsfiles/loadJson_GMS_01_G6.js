var GMS_01_G6_JSON = {

	starAnimJson : {"frames": [

		{
			"filename": "Symbol 10 copy instance 10000",
			"frame": {"x":0,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10001",
			"frame": {"x":0,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10002",
			"frame": {"x":0,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10003",
			"frame": {"x":0,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10004",
			"frame": {"x":33,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10005",
			"frame": {"x":33,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10006",
			"frame": {"x":33,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10007",
			"frame": {"x":33,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10008",
			"frame": {"x":66,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10009",
			"frame": {"x":66,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10010",
			"frame": {"x":66,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10011",
			"frame": {"x":66,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10012",
			"frame": {"x":99,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10013",
			"frame": {"x":99,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10014",
			"frame": {"x":99,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10015",
			"frame": {"x":99,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10016",
			"frame": {"x":132,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10017",
			"frame": {"x":132,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10018",
			"frame": {"x":132,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10019",
			"frame": {"x":132,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10020",
			"frame": {"x":165,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10021",
			"frame": {"x":165,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10022",
			"frame": {"x":165,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10023",
			"frame": {"x":165,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10024",
			"frame": {"x":198,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10025",
			"frame": {"x":198,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10026",
			"frame": {"x":198,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10027",
			"frame": {"x":198,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10028",
			"frame": {"x":231,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10029",
			"frame": {"x":231,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10030",
			"frame": {"x":231,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10031",
			"frame": {"x":231,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10032",
			"frame": {"x":264,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10033",
			"frame": {"x":264,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10034",
			"frame": {"x":264,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10035",
			"frame": {"x":264,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "st.png",
			"format": "RGB8",
			"size": {"w":334,"h":479},
			"scale": "1"
		}
		},
	speakerJson : {"frames": [

		{
			"filename": "Symbol 5 instance 10000",
			"frame": {"x":0,"y":0,"w":41,"h":30},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":41,"h":30},
			"sourceSize": {"w":41,"h":30}
		},
		{
			"filename": "Symbol 5 instance 10001",
			"frame": {"x":0,"y":30,"w":41,"h":30},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":41,"h":30},
			"sourceSize": {"w":41,"h":30}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "s.png",
			"format": "RGB8",
			"size": {"w":44,"h":64},
			"scale": "1"
		}
	},

	btnJson : {"frames": [

{
	"filename": "Symbol 1 instance 10000",
	"frame": {"x":0,"y":0,"w":212,"h":71},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":212,"h":71},
	"sourceSize": {"w":212,"h":71}
}
,{
	"filename": "Symbol 1 instance 10001",
	"frame": {"x":0,"y":71,"w":212,"h":71},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":212,"h":71},
	"sourceSize": {"w":212,"h":71}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "16.5.1.104",
	"image": "b1.png",
	"format": "RGB8",
	"size": {"w":213,"h":144},
	"scale": "1"
}
},

	replyJson : {"frames": [

{
	"filename": "Symbol 8 instance 10000",
	"frame": {"x":0,"y":0,"w":47,"h":47},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":47,"h":47},
	"sourceSize": {"w":47,"h":47}
}
,{
	"filename": "Symbol 8 instance 10001",
	"frame": {"x":47,"y":0,"w":47,"h":47},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":47,"h":47},
	"sourceSize": {"w":47,"h":47}
}
,{
	"filename": "Symbol 8 instance 10002",
	"frame": {"x":0,"y":0,"w":47,"h":47},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":47,"h":47},
	"sourceSize": {"w":47,"h":47}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "15.1.0.210",
	"image": "Back btn.png",
	"format": "RGBA8888",
	"size": {"w":98,"h":48},
	"scale": "1"
}
},

    backbtnJson : {"frames": [

		{
			"filename": "Symbol 9 instance 10000",
			"frame": {"x":0,"y":0,"w":41,"h":29},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":41,"h":29},
			"sourceSize": {"w":41,"h":29}
		}
		,{
			"filename": "Symbol 9 instance 10001",
			"frame": {"x":0,"y":29,"w":41,"h":29},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":41,"h":29},
			"sourceSize": {"w":41,"h":29}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "back.png",
			"format": "RGB8",
			"size": {"w":44,"h":64},
			"scale": "1"
		}
		},

   
    tickJson : {"frames": [

{
	"filename": "Symbol 14 copy instance 10000",
	"frame": {"x":0,"y":0,"w":58,"h":61},
	"rotated": false,
	"trimmed": true,
	"spriteSourceSize": {"x":0,"y":0,"w":64,"h":68},
	"sourceSize": {"w":64,"h":68}
}
,{
	"filename": "Symbol 14 copy instance 10001",
	"frame": {"x":58,"y":0,"w":59,"h":62},
	"rotated": false,
	"trimmed": true,
	"spriteSourceSize": {"x":5,"y":6,"w":64,"h":68},
	"sourceSize": {"w":64,"h":68}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "15.1.0.210",
	"image": "right btn.png",
	"format": "RGB8",
	"size": {"w":121,"h":62},
	"scale": "1"
}
},
comingUpJson: {"frames": [
{
	"filename": "Symbol 4 copy instance 10000",
	"frame": {"x":0,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10001",
	"frame": {"x":68,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10002",
	"frame": {"x":136,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10003",
	"frame": {"x":204,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10004",
	"frame": {"x":272,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10005",
	"frame": {"x":340,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10006",
	"frame": {"x":408,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10007",
	"frame": {"x":476,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10008",
	"frame": {"x":544,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10009",
	"frame": {"x":612,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10010",
	"frame": {"x":680,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10011",
	"frame": {"x":748,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10012",
	"frame": {"x":816,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "holding a fish coming back from water,.png",
	"format": "RGBA8888",
	"size": {"w":918,"h":72},
	"scale": "1"
}    
    
},
    
rightbutton:{"frames": [

		{
			"filename": "Symbol 10 instance 10000",
			"frame": {"x":0,"y":0,"w":68,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
			"sourceSize": {"w":68,"h":68}
		}
		,{
			"filename": "Symbol 10 instance 10001",
			"frame": {"x":68,"y":0,"w":68,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
			"sourceSize": {"w":68,"h":68}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "20.0.1.19255",
			"image": "Right Btn.png",
			"format": "RGBA8888",
			"size": {"w":138,"h":70},
			"scale": "1"
		}
},

homebtnJson : {"frames": [

{
	"filename": "Symbol 4 instance 10000",
	"frame": {"x":0,"y":0,"w":60,"h":60},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":60},
	"sourceSize": {"w":60,"h":60}
}
,{
	"filename": "Symbol 4 instance 10001",
	"frame": {"x":0,"y":60,"w":60,"h":60},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":60},
	"sourceSize": {"w":60,"h":60}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "18.0.1.115",
	"image": "H.png",
	"format": "RGB8",
	"size": {"w":64,"h":128},
	"scale": "1"
}
},

nextbtnJson : {"frames": [

{
	"filename": "Symbol 6 instance 10000",
	"frame": {"x":0,"y":0,"w":59,"h":60},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":59,"h":60},
	"sourceSize": {"w":59,"h":60}
}
,{
	"filename": "Symbol 6 instance 10001",
	"frame": {"x":0,"y":60,"w":59,"h":60},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":59,"h":60},
	"sourceSize": {"w":59,"h":60}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "18.0.1.115",
	"image": "N.png",
	"format": "RGB8",
	"size": {"w":64,"h":128},
	"scale": "1"
}
},
Json1:{"frames": [

	{
		"filename": "Symbol 2 instance 10000",
		"frame": {"x":0,"y":0,"w":88,"h":11},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":88,"h":11},
		"sourceSize": {"w":88,"h":11}
	}
	,{
		"filename": "Symbol 2 instance 10001",
		"frame": {"x":0,"y":11,"w":88,"h":11},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":88,"h":11},
		"sourceSize": {"w":88,"h":11}
	}],
	"meta": {
		"app": "Adobe Animate",
		"version": "16.5.1.104",
		"image": "4.png",
		"format": "RGBA8888",
		"size": {"w":128,"h":128},
		"scale": "1"
	}
	},	

Json2:
{"frames": [

	{
		"filename": "Symbol 2 instance 10000",
		"frame": {"x":0,"y":0,"w":10,"h":83},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":10,"h":83},
		"sourceSize": {"w":10,"h":83}
	}
	,{
		"filename": "Symbol 2 instance 10001",
		"frame": {"x":10,"y":0,"w":10,"h":83},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":10,"h":83},
		"sourceSize": {"w":10,"h":83}
	}],
	"meta": {
		"app": "Adobe Animate",
		"version": "16.5.1.104",
		"image": "v1.png",
		"format": "RGBA8888",
		"size": {"w":32,"h":128},
		"scale": "1"
	}
	},
	
Json3:{"frames": [

	{
		"filename": "Symbol 1 instance 10000",
		"frame": {"x":0,"y":0,"w":87,"h":84},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":87,"h":84},
		"sourceSize": {"w":87,"h":84}
	}
	,{
		"filename": "Symbol 1 instance 10001",
		"frame": {"x":0,"y":84,"w":87,"h":84},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":87,"h":84},
		"sourceSize": {"w":87,"h":84}
	}],
	"meta": {
		"app": "Adobe Animate",
		"version": "16.5.1.104",
		"image": "2.png",
		"format": "RGBA8888",
		"size": {"w":128,"h":256},
		"scale": "1"
	}
	},
	
Json4:{"frames": [

	{
		"filename": "Symbol 1 instance 10000",
		"frame": {"x":0,"y":0,"w":87,"h":82},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":87,"h":82},
		"sourceSize": {"w":87,"h":82}
	}
	,{
		"filename": "Symbol 1 instance 10001",
		"frame": {"x":0,"y":82,"w":87,"h":82},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":87,"h":82},
		"sourceSize": {"w":87,"h":82}
	}],
	"meta": {
		"app": "Adobe Animate",
		"version": "16.5.1.104",
		"image": "1.png",
		"format": "RGBA8888",
		"size": {"w":128,"h":256},
		"scale": "1"
	}
	},
	
Json5:{"frames": [

	{
		"filename": "Symbol 3 instance 10000",
		"frame": {"x":0,"y":0,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10001",
		"frame": {"x":322,"y":0,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10002",
		"frame": {"x":644,"y":0,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10003",
		"frame": {"x":966,"y":0,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10004",
		"frame": {"x":1288,"y":0,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10005",
		"frame": {"x":1610,"y":0,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10006",
		"frame": {"x":0,"y":447,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10007",
		"frame": {"x":322,"y":447,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10008",
		"frame": {"x":644,"y":447,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10009",
		"frame": {"x":966,"y":447,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10010",
		"frame": {"x":1288,"y":447,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10011",
		"frame": {"x":1610,"y":447,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10012",
		"frame": {"x":0,"y":894,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10013",
		"frame": {"x":322,"y":894,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10014",
		"frame": {"x":644,"y":894,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10015",
		"frame": {"x":966,"y":894,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10016",
		"frame": {"x":1288,"y":894,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10017",
		"frame": {"x":1610,"y":894,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10018",
		"frame": {"x":0,"y":1341,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10019",
		"frame": {"x":322,"y":1341,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10020",
		"frame": {"x":644,"y":1341,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10021",
		"frame": {"x":966,"y":1341,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10022",
		"frame": {"x":1288,"y":1341,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10023",
		"frame": {"x":1610,"y":1341,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10024",
		"frame": {"x":0,"y":1788,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10025",
		"frame": {"x":322,"y":1788,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10026",
		"frame": {"x":644,"y":1788,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10027",
		"frame": {"x":966,"y":1788,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10028",
		"frame": {"x":1288,"y":1788,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10029",
		"frame": {"x":1610,"y":1788,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10030",
		"frame": {"x":0,"y":2235,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10031",
		"frame": {"x":322,"y":2235,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10032",
		"frame": {"x":644,"y":2235,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10033",
		"frame": {"x":966,"y":2235,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10034",
		"frame": {"x":1288,"y":2235,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10035",
		"frame": {"x":1610,"y":2235,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10036",
		"frame": {"x":0,"y":2682,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10037",
		"frame": {"x":322,"y":2682,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}],
	"meta": {
		"app": "Adobe Animate",
		"version": "16.5.1.104",
		"image": "q1.png",
		"format": "RGBA8888",
		"size": {"w":2048,"h":4096},
		"scale": "1"
	}
	},
	
Json6:{"frames": [

	{
		"filename": "Symbol 7 instance 10000",
		"frame": {"x":0,"y":0,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10001",
		"frame": {"x":242,"y":0,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10002",
		"frame": {"x":484,"y":0,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10003",
		"frame": {"x":726,"y":0,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10004",
		"frame": {"x":968,"y":0,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10005",
		"frame": {"x":1210,"y":0,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10006",
		"frame": {"x":1452,"y":0,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10007",
		"frame": {"x":1694,"y":0,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10008",
		"frame": {"x":0,"y":373,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10009",
		"frame": {"x":242,"y":373,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10010",
		"frame": {"x":484,"y":373,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10011",
		"frame": {"x":726,"y":373,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10012",
		"frame": {"x":968,"y":373,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10013",
		"frame": {"x":1210,"y":373,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10014",
		"frame": {"x":1452,"y":373,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10015",
		"frame": {"x":1694,"y":373,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10016",
		"frame": {"x":0,"y":746,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10017",
		"frame": {"x":242,"y":746,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10018",
		"frame": {"x":484,"y":746,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10019",
		"frame": {"x":726,"y":746,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10020",
		"frame": {"x":968,"y":746,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10021",
		"frame": {"x":1210,"y":746,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10022",
		"frame": {"x":1452,"y":746,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10023",
		"frame": {"x":1694,"y":746,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10024",
		"frame": {"x":0,"y":1119,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10025",
		"frame": {"x":242,"y":1119,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10026",
		"frame": {"x":484,"y":1119,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10027",
		"frame": {"x":726,"y":1119,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10028",
		"frame": {"x":968,"y":1119,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10029",
		"frame": {"x":1210,"y":1119,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10030",
		"frame": {"x":1452,"y":1119,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10031",
		"frame": {"x":1694,"y":1119,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10032",
		"frame": {"x":0,"y":1492,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10033",
		"frame": {"x":242,"y":1492,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10034",
		"frame": {"x":484,"y":1492,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10035",
		"frame": {"x":726,"y":1492,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10036",
		"frame": {"x":968,"y":1492,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10037",
		"frame": {"x":1210,"y":1492,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10038",
		"frame": {"x":1452,"y":1492,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10039",
		"frame": {"x":1694,"y":1492,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10040",
		"frame": {"x":0,"y":1865,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10041",
		"frame": {"x":0,"y":2238,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10042",
		"frame": {"x":0,"y":2611,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10043",
		"frame": {"x":0,"y":2984,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10044",
		"frame": {"x":0,"y":3357,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10045",
		"frame": {"x":242,"y":1865,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10046",
		"frame": {"x":484,"y":1865,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10047",
		"frame": {"x":726,"y":1865,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10048",
		"frame": {"x":968,"y":1865,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10049",
		"frame": {"x":1210,"y":1865,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10050",
		"frame": {"x":1452,"y":1865,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10051",
		"frame": {"x":1694,"y":1865,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10052",
		"frame": {"x":242,"y":2238,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10053",
		"frame": {"x":242,"y":2611,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10054",
		"frame": {"x":242,"y":2984,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10055",
		"frame": {"x":242,"y":3357,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10056",
		"frame": {"x":484,"y":2238,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10057",
		"frame": {"x":726,"y":2238,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10058",
		"frame": {"x":968,"y":2238,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10059",
		"frame": {"x":1210,"y":2238,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10060",
		"frame": {"x":1452,"y":2238,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10061",
		"frame": {"x":1694,"y":2238,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10062",
		"frame": {"x":484,"y":2611,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10063",
		"frame": {"x":484,"y":2984,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10064",
		"frame": {"x":484,"y":3357,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10065",
		"frame": {"x":726,"y":2611,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10066",
		"frame": {"x":726,"y":2984,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10067",
		"frame": {"x":726,"y":3357,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10068",
		"frame": {"x":968,"y":2611,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10069",
		"frame": {"x":1210,"y":2611,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10070",
		"frame": {"x":1452,"y":2611,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10071",
		"frame": {"x":1694,"y":2611,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10072",
		"frame": {"x":968,"y":2984,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10073",
		"frame": {"x":968,"y":3357,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10074",
		"frame": {"x":1210,"y":2984,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10075",
		"frame": {"x":1452,"y":2984,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10076",
		"frame": {"x":1694,"y":2984,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10077",
		"frame": {"x":1210,"y":3357,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10078",
		"frame": {"x":1452,"y":3357,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}
	,{
		"filename": "Symbol 7 instance 10079",
		"frame": {"x":1694,"y":3357,"w":242,"h":373},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":373},
		"sourceSize": {"w":242,"h":373}
	}],
	"meta": {
		"app": "Adobe Animate",
		"version": "18.0.0.107",
		"image": "q8.png",
		"format": "RGBA8888",
		"size": {"w":2048,"h":4096},
		"scale": "1"
	}
	}
	,
Json7:{"frames": [

	{
		"filename": "Symbol 15 instance 10000",
		"frame": {"x":0,"y":0,"w":0,"h":0},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":1384,"y":-932,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10001",
		"frame": {"x":490,"y":2332,"w":245,"h":16},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10002",
		"frame": {"x":980,"y":2302,"w":245,"h":32},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10003",
		"frame": {"x":1470,"y":2298,"w":245,"h":49},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10004",
		"frame": {"x":735,"y":2298,"w":245,"h":65},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10005",
		"frame": {"x":1715,"y":2297,"w":245,"h":82},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10006",
		"frame": {"x":1225,"y":2296,"w":245,"h":98},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10007",
		"frame": {"x":245,"y":2293,"w":245,"h":115},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10008",
		"frame": {"x":0,"y":2292,"w":245,"h":131},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10009",
		"frame": {"x":490,"y":2184,"w":245,"h":148},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10010",
		"frame": {"x":490,"y":2001,"w":245,"h":183},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10011",
		"frame": {"x":245,"y":2000,"w":245,"h":293},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10012",
		"frame": {"x":1225,"y":1997,"w":245,"h":299},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10013",
		"frame": {"x":735,"y":1994,"w":245,"h":304},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10014",
		"frame": {"x":1470,"y":1988,"w":245,"h":310},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10015",
		"frame": {"x":0,"y":1683,"w":245,"h":315},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10016",
		"frame": {"x":490,"y":1681,"w":245,"h":320},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10017",
		"frame": {"x":980,"y":1668,"w":245,"h":324},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10018",
		"frame": {"x":1715,"y":1667,"w":245,"h":328},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10019",
		"frame": {"x":1470,"y":1656,"w":245,"h":332},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10020",
		"frame": {"x":0,"y":1347,"w":245,"h":336},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10021",
		"frame": {"x":1225,"y":1329,"w":245,"h":338},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10022",
		"frame": {"x":1470,"y":1317,"w":245,"h":339},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10023",
		"frame": {"x":980,"y":1330,"w":245,"h":338},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10024",
		"frame": {"x":735,"y":1333,"w":245,"h":337},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10025",
		"frame": {"x":490,"y":1347,"w":245,"h":334},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10026",
		"frame": {"x":1225,"y":1667,"w":245,"h":330},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10027",
		"frame": {"x":735,"y":1670,"w":245,"h":324},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10028",
		"frame": {"x":245,"y":1682,"w":245,"h":318},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10029",
		"frame": {"x":980,"y":1992,"w":245,"h":310},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10030",
		"frame": {"x":1715,"y":1995,"w":245,"h":302},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10031",
		"frame": {"x":0,"y":1998,"w":245,"h":294},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10032",
		"frame": {"x":245,"y":1347,"w":245,"h":335},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10033",
		"frame": {"x":1715,"y":1297,"w":245,"h":370},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10034",
		"frame": {"x":1715,"y":898,"w":245,"h":399},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10035",
		"frame": {"x":1470,"y":898,"w":245,"h":419},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10036",
		"frame": {"x":980,"y":898,"w":245,"h":432},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10037",
		"frame": {"x":735,"y":898,"w":245,"h":435},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10038",
		"frame": {"x":1225,"y":898,"w":245,"h":431},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10039",
		"frame": {"x":0,"y":0,"w":245,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10040",
		"frame": {"x":245,"y":0,"w":245,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10041",
		"frame": {"x":490,"y":0,"w":245,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10042",
		"frame": {"x":735,"y":0,"w":245,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10043",
		"frame": {"x":980,"y":0,"w":245,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10044",
		"frame": {"x":1225,"y":0,"w":245,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10045",
		"frame": {"x":1470,"y":0,"w":245,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10046",
		"frame": {"x":1715,"y":0,"w":245,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10047",
		"frame": {"x":0,"y":449,"w":245,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10048",
		"frame": {"x":245,"y":449,"w":245,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10049",
		"frame": {"x":490,"y":449,"w":245,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10050",
		"frame": {"x":735,"y":449,"w":245,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10051",
		"frame": {"x":980,"y":449,"w":245,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10052",
		"frame": {"x":1225,"y":449,"w":245,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10053",
		"frame": {"x":1470,"y":449,"w":245,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10054",
		"frame": {"x":1715,"y":449,"w":245,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10055",
		"frame": {"x":0,"y":898,"w":245,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10056",
		"frame": {"x":245,"y":898,"w":245,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}
	,{
		"filename": "Symbol 15 instance 10057",
		"frame": {"x":490,"y":898,"w":245,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":245,"h":449},
		"sourceSize": {"w":245,"h":449}
	}],
	"meta": {
		"app": "Adobe Animate",
		"version": "16.5.1.104",
		"image": "q2.png",
		"format": "RGBA8888",
		"size": {"w":2048,"h":4096},
		"scale": "1"
	}
	},
	
Json8:{"frames": [

	{
		"filename": "Symbol 5 instance 10000",
		"frame": {"x":1936,"y":840,"w":73,"h":52},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":169,"y":144,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10001",
		"frame": {"x":1936,"y":892,"w":73,"h":52},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":169,"y":144,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10002",
		"frame": {"x":1936,"y":944,"w":73,"h":52},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":169,"y":144,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10003",
		"frame": {"x":1936,"y":996,"w":73,"h":52},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":169,"y":144,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10004",
		"frame": {"x":1936,"y":1048,"w":73,"h":52},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":169,"y":144,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10005",
		"frame": {"x":1936,"y":0,"w":91,"h":168},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":151,"y":28,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10006",
		"frame": {"x":1936,"y":168,"w":91,"h":168},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":151,"y":28,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10007",
		"frame": {"x":1936,"y":336,"w":91,"h":168},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":151,"y":28,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10008",
		"frame": {"x":1936,"y":504,"w":91,"h":168},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":151,"y":28,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10009",
		"frame": {"x":1936,"y":672,"w":91,"h":168},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":151,"y":28,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10010",
		"frame": {"x":726,"y":2009,"w":242,"h":207},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10011",
		"frame": {"x":968,"y":2009,"w":242,"h":207},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10012",
		"frame": {"x":1210,"y":2009,"w":242,"h":207},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10013",
		"frame": {"x":1452,"y":2009,"w":242,"h":207},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10014",
		"frame": {"x":1694,"y":2009,"w":242,"h":207},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10015",
		"frame": {"x":484,"y":1796,"w":242,"h":213},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10016",
		"frame": {"x":726,"y":1796,"w":242,"h":213},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10017",
		"frame": {"x":968,"y":1796,"w":242,"h":213},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10018",
		"frame": {"x":1210,"y":1796,"w":242,"h":213},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10019",
		"frame": {"x":1452,"y":1796,"w":242,"h":213},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10020",
		"frame": {"x":1694,"y":1796,"w":242,"h":213},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10021",
		"frame": {"x":484,"y":2009,"w":242,"h":213},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10022",
		"frame": {"x":0,"y":0,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10023",
		"frame": {"x":242,"y":0,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10024",
		"frame": {"x":484,"y":0,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10025",
		"frame": {"x":726,"y":0,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10026",
		"frame": {"x":968,"y":0,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10027",
		"frame": {"x":1210,"y":0,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10028",
		"frame": {"x":1452,"y":0,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10029",
		"frame": {"x":1694,"y":0,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10030",
		"frame": {"x":0,"y":449,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10031",
		"frame": {"x":242,"y":449,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10032",
		"frame": {"x":484,"y":449,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10033",
		"frame": {"x":726,"y":449,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10034",
		"frame": {"x":968,"y":449,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10035",
		"frame": {"x":1210,"y":449,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10036",
		"frame": {"x":1452,"y":449,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10037",
		"frame": {"x":1694,"y":449,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10038",
		"frame": {"x":0,"y":898,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10039",
		"frame": {"x":242,"y":898,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10040",
		"frame": {"x":484,"y":898,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10041",
		"frame": {"x":726,"y":898,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10042",
		"frame": {"x":968,"y":898,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10043",
		"frame": {"x":1210,"y":898,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10044",
		"frame": {"x":1452,"y":898,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10045",
		"frame": {"x":1694,"y":898,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10046",
		"frame": {"x":0,"y":1347,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10047",
		"frame": {"x":242,"y":1347,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10048",
		"frame": {"x":484,"y":1347,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10049",
		"frame": {"x":726,"y":1347,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10050",
		"frame": {"x":968,"y":1347,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10051",
		"frame": {"x":1210,"y":1347,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10052",
		"frame": {"x":1452,"y":1347,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10053",
		"frame": {"x":1694,"y":1347,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10054",
		"frame": {"x":0,"y":1796,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}
	,{
		"filename": "Symbol 5 instance 10055",
		"frame": {"x":242,"y":1796,"w":242,"h":449},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
		"sourceSize": {"w":242,"h":449}
	}],
	"meta": {
		"app": "Adobe Animate",
		"version": "16.5.1.104",
		"image": "q5.png",
		"format": "RGBA8888",
		"size": {"w":2048,"h":4096},
		"scale": "1"
	}
	},
	
Json9:{"frames": [

	{
		"filename": "Symbol 7 instance 10000",
		"frame": {"x":0,"y":0,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10001",
		"frame": {"x":395,"y":0,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10002",
		"frame": {"x":790,"y":0,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10003",
		"frame": {"x":1185,"y":0,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10004",
		"frame": {"x":1580,"y":0,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10005",
		"frame": {"x":1975,"y":0,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10006",
		"frame": {"x":2370,"y":0,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10007",
		"frame": {"x":2765,"y":0,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10008",
		"frame": {"x":3160,"y":0,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10009",
		"frame": {"x":3555,"y":0,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10010",
		"frame": {"x":0,"y":448,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10011",
		"frame": {"x":395,"y":448,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10012",
		"frame": {"x":790,"y":448,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10013",
		"frame": {"x":1185,"y":448,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10014",
		"frame": {"x":1580,"y":448,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10015",
		"frame": {"x":1975,"y":448,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10016",
		"frame": {"x":2370,"y":448,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10017",
		"frame": {"x":2765,"y":448,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10018",
		"frame": {"x":3160,"y":448,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10019",
		"frame": {"x":3555,"y":448,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10020",
		"frame": {"x":0,"y":896,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10021",
		"frame": {"x":395,"y":896,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10022",
		"frame": {"x":790,"y":896,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10023",
		"frame": {"x":1185,"y":896,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10024",
		"frame": {"x":1580,"y":896,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10025",
		"frame": {"x":1975,"y":896,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10026",
		"frame": {"x":2370,"y":896,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10027",
		"frame": {"x":2765,"y":896,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10028",
		"frame": {"x":3160,"y":896,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10029",
		"frame": {"x":3555,"y":896,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10030",
		"frame": {"x":0,"y":1344,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10031",
		"frame": {"x":395,"y":1344,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10032",
		"frame": {"x":790,"y":1344,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10033",
		"frame": {"x":1185,"y":1344,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10034",
		"frame": {"x":1580,"y":1344,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10035",
		"frame": {"x":1975,"y":1344,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10036",
		"frame": {"x":2370,"y":1344,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10037",
		"frame": {"x":2765,"y":1344,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10038",
		"frame": {"x":3160,"y":1344,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10039",
		"frame": {"x":3555,"y":1344,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10040",
		"frame": {"x":0,"y":1792,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10041",
		"frame": {"x":395,"y":1792,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10042",
		"frame": {"x":790,"y":1792,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10043",
		"frame": {"x":1185,"y":1792,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10044",
		"frame": {"x":1580,"y":1792,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10045",
		"frame": {"x":1975,"y":1792,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}
	,{
		"filename": "Symbol 7 instance 10046",
		"frame": {"x":2370,"y":1792,"w":395,"h":448},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
		"sourceSize": {"w":395,"h":448}
	}],
	"meta": {
		"app": "Adobe Animate",
		"version": "16.5.1.104",
		"image": "q7.png",
		"format": "RGBA8888",
		"size": {"w":4096,"h":4096},
		"scale": "1"
	}
	},
	
Json10:{"frames": [

	{
		"filename": "Symbol 6 instance 10000",
		"frame": {"x":0,"y":0,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10001",
		"frame": {"x":243,"y":0,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10002",
		"frame": {"x":486,"y":0,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10003",
		"frame": {"x":729,"y":0,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10004",
		"frame": {"x":972,"y":0,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10005",
		"frame": {"x":1215,"y":0,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10006",
		"frame": {"x":1458,"y":0,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10007",
		"frame": {"x":1701,"y":0,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10008",
		"frame": {"x":0,"y":450,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10009",
		"frame": {"x":243,"y":450,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10010",
		"frame": {"x":486,"y":450,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10011",
		"frame": {"x":729,"y":450,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10012",
		"frame": {"x":972,"y":450,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10013",
		"frame": {"x":1215,"y":450,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10014",
		"frame": {"x":1458,"y":450,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10015",
		"frame": {"x":1701,"y":450,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10016",
		"frame": {"x":0,"y":900,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10017",
		"frame": {"x":243,"y":900,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10018",
		"frame": {"x":486,"y":900,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10019",
		"frame": {"x":729,"y":900,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10020",
		"frame": {"x":972,"y":900,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10021",
		"frame": {"x":1215,"y":900,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10022",
		"frame": {"x":1458,"y":900,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10023",
		"frame": {"x":1701,"y":900,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10024",
		"frame": {"x":0,"y":1350,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10025",
		"frame": {"x":243,"y":1350,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10026",
		"frame": {"x":486,"y":1350,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10027",
		"frame": {"x":729,"y":1350,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10028",
		"frame": {"x":972,"y":1350,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10029",
		"frame": {"x":1215,"y":1350,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10030",
		"frame": {"x":1458,"y":1350,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10031",
		"frame": {"x":1701,"y":1350,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10032",
		"frame": {"x":0,"y":1800,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10033",
		"frame": {"x":0,"y":2250,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10034",
		"frame": {"x":0,"y":2700,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10035",
		"frame": {"x":0,"y":3150,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10036",
		"frame": {"x":0,"y":3600,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10037",
		"frame": {"x":243,"y":1800,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10038",
		"frame": {"x":486,"y":1800,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10039",
		"frame": {"x":729,"y":1800,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10040",
		"frame": {"x":972,"y":1800,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10041",
		"frame": {"x":1215,"y":1800,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10042",
		"frame": {"x":1458,"y":1800,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10043",
		"frame": {"x":1701,"y":1800,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10044",
		"frame": {"x":243,"y":2250,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10045",
		"frame": {"x":243,"y":2700,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10046",
		"frame": {"x":243,"y":3150,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10047",
		"frame": {"x":243,"y":3600,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10048",
		"frame": {"x":486,"y":2250,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10049",
		"frame": {"x":486,"y":2700,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10050",
		"frame": {"x":486,"y":3150,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10051",
		"frame": {"x":486,"y":3600,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10052",
		"frame": {"x":729,"y":2250,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10053",
		"frame": {"x":972,"y":2250,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10054",
		"frame": {"x":1215,"y":2250,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10055",
		"frame": {"x":1458,"y":2250,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10056",
		"frame": {"x":1701,"y":2250,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10057",
		"frame": {"x":729,"y":2700,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10058",
		"frame": {"x":729,"y":3150,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10059",
		"frame": {"x":729,"y":3600,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10060",
		"frame": {"x":972,"y":2700,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10061",
		"frame": {"x":972,"y":3150,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10062",
		"frame": {"x":972,"y":3600,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10063",
		"frame": {"x":1215,"y":2700,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10064",
		"frame": {"x":1458,"y":2700,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10065",
		"frame": {"x":1701,"y":2700,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}
	,{
		"filename": "Symbol 6 instance 10066",
		"frame": {"x":1215,"y":3150,"w":243,"h":450},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":243,"h":450},
		"sourceSize": {"w":243,"h":450}
	}],
	"meta": {
		"app": "Adobe Animate",
		"version": "16.5.1.104",
		"image": "q6.png",
		"format": "RGBA8888",
		"size": {"w":2048,"h":4096},
		"scale": "1"
	}
	},
	
Json11:{"frames": [

	{
		"filename": "Symbol 10 instance 10000",
		"frame": {"x":1210,"y":1655,"w":213,"h":14},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":29,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10001",
		"frame": {"x":1210,"y":1669,"w":213,"h":14},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":29,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10002",
		"frame": {"x":1694,"y":1675,"w":213,"h":14},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":29,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10003",
		"frame": {"x":0,"y":1681,"w":213,"h":14},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":29,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10004",
		"frame": {"x":213,"y":1681,"w":213,"h":14},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":29,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10005",
		"frame": {"x":1210,"y":1683,"w":213,"h":14},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":29,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10006",
		"frame": {"x":1452,"y":1507,"w":242,"h":129},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10007",
		"frame": {"x":1210,"y":1526,"w":242,"h":129},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10008",
		"frame": {"x":1694,"y":1546,"w":242,"h":129},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10009",
		"frame": {"x":0,"y":1552,"w":242,"h":129},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10010",
		"frame": {"x":242,"y":1552,"w":242,"h":129},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10011",
		"frame": {"x":1452,"y":1636,"w":242,"h":129},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10012",
		"frame": {"x":1452,"y":1239,"w":242,"h":268},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10013",
		"frame": {"x":1694,"y":1278,"w":242,"h":268},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10014",
		"frame": {"x":0,"y":1284,"w":242,"h":268},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10015",
		"frame": {"x":242,"y":1284,"w":242,"h":268},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10016",
		"frame": {"x":484,"y":1462,"w":242,"h":268},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10017",
		"frame": {"x":726,"y":1462,"w":242,"h":268},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10018",
		"frame": {"x":968,"y":1462,"w":242,"h":268},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10019",
		"frame": {"x":484,"y":888,"w":242,"h":287},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10020",
		"frame": {"x":726,"y":888,"w":242,"h":287},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10021",
		"frame": {"x":968,"y":888,"w":242,"h":287},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10022",
		"frame": {"x":484,"y":1175,"w":242,"h":287},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10023",
		"frame": {"x":726,"y":1175,"w":242,"h":287},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10024",
		"frame": {"x":968,"y":1175,"w":242,"h":287},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10025",
		"frame": {"x":1210,"y":1239,"w":242,"h":287},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10026",
		"frame": {"x":1210,"y":447,"w":242,"h":396},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10027",
		"frame": {"x":1452,"y":447,"w":242,"h":396},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10028",
		"frame": {"x":1210,"y":843,"w":242,"h":396},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10029",
		"frame": {"x":1452,"y":843,"w":242,"h":396},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10030",
		"frame": {"x":1694,"y":882,"w":242,"h":396},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10031",
		"frame": {"x":0,"y":888,"w":242,"h":396},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10032",
		"frame": {"x":242,"y":888,"w":242,"h":396},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10033",
		"frame": {"x":1694,"y":0,"w":242,"h":441},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10034",
		"frame": {"x":1694,"y":441,"w":242,"h":441},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10035",
		"frame": {"x":0,"y":447,"w":242,"h":441},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10036",
		"frame": {"x":242,"y":447,"w":242,"h":441},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10037",
		"frame": {"x":484,"y":447,"w":242,"h":441},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10038",
		"frame": {"x":726,"y":447,"w":242,"h":441},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10039",
		"frame": {"x":968,"y":447,"w":242,"h":441},
		"rotated": false,
		"trimmed": true,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10040",
		"frame": {"x":0,"y":0,"w":242,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10041",
		"frame": {"x":242,"y":0,"w":242,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10042",
		"frame": {"x":484,"y":0,"w":242,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10043",
		"frame": {"x":726,"y":0,"w":242,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10044",
		"frame": {"x":968,"y":0,"w":242,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10045",
		"frame": {"x":1210,"y":0,"w":242,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}
	,{
		"filename": "Symbol 10 instance 10046",
		"frame": {"x":1452,"y":0,"w":242,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
		"sourceSize": {"w":242,"h":447}
	}],
	"meta": {
		"app": "Adobe Animate",
		"version": "16.5.1.104",
		"image": "q4.png",
		"format": "RGBA8888",
		"size": {"w":2048,"h":2048},
		"scale": "1"
	}
	},
	
Json12:{"frames": [

	{
		"filename": "Symbol 4 instance 10000",
		"frame": {"x":0,"y":0,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10001",
		"frame": {"x":0,"y":445,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10002",
		"frame": {"x":0,"y":890,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10003",
		"frame": {"x":0,"y":1335,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10004",
		"frame": {"x":0,"y":1780,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10005",
		"frame": {"x":0,"y":2225,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10006",
		"frame": {"x":0,"y":2670,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10007",
		"frame": {"x":0,"y":3115,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10008",
		"frame": {"x":0,"y":3560,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10009",
		"frame": {"x":318,"y":0,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10010",
		"frame": {"x":318,"y":445,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10011",
		"frame": {"x":318,"y":890,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10012",
		"frame": {"x":318,"y":1335,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10013",
		"frame": {"x":318,"y":1780,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10014",
		"frame": {"x":318,"y":2225,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10015",
		"frame": {"x":318,"y":2670,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10016",
		"frame": {"x":318,"y":3115,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10017",
		"frame": {"x":318,"y":3560,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10018",
		"frame": {"x":636,"y":0,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10019",
		"frame": {"x":636,"y":445,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10020",
		"frame": {"x":636,"y":890,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10021",
		"frame": {"x":636,"y":1335,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10022",
		"frame": {"x":636,"y":1780,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10023",
		"frame": {"x":636,"y":2225,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10024",
		"frame": {"x":636,"y":2670,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10025",
		"frame": {"x":636,"y":3115,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10026",
		"frame": {"x":636,"y":3560,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10027",
		"frame": {"x":954,"y":0,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10028",
		"frame": {"x":954,"y":445,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10029",
		"frame": {"x":954,"y":890,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10030",
		"frame": {"x":954,"y":1335,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10031",
		"frame": {"x":954,"y":1780,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10032",
		"frame": {"x":954,"y":2225,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10033",
		"frame": {"x":954,"y":2670,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10034",
		"frame": {"x":954,"y":3115,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10035",
		"frame": {"x":954,"y":3560,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10036",
		"frame": {"x":1272,"y":0,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10037",
		"frame": {"x":1272,"y":445,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10038",
		"frame": {"x":1272,"y":890,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10039",
		"frame": {"x":1272,"y":1335,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10040",
		"frame": {"x":1272,"y":1780,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10041",
		"frame": {"x":1272,"y":2225,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10042",
		"frame": {"x":1272,"y":2670,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10043",
		"frame": {"x":1272,"y":3115,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}
	,{
		"filename": "Symbol 4 instance 10044",
		"frame": {"x":1272,"y":3560,"w":318,"h":445},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":318,"h":445},
		"sourceSize": {"w":318,"h":445}
	}],
	"meta": {
		"app": "Adobe Animate",
		"version": "16.5.1.104",
		"image": "q3.png",
		"format": "RGBA8888",
		"size": {"w":2048,"h":4096},
		"scale": "1"
	}
	},
// Json51:
JsonHr1:{"frames": [

	{
		"filename": "Symbol 3 instance 10000",
		"frame": {"x":0,"y":0,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10001",
		"frame": {"x":322,"y":0,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10002",
		"frame": {"x":644,"y":0,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10003",
		"frame": {"x":966,"y":0,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10004",
		"frame": {"x":1288,"y":0,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10005",
		"frame": {"x":1610,"y":0,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10006",
		"frame": {"x":0,"y":447,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10007",
		"frame": {"x":322,"y":447,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10008",
		"frame": {"x":644,"y":447,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10009",
		"frame": {"x":966,"y":447,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10010",
		"frame": {"x":1288,"y":447,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10011",
		"frame": {"x":1610,"y":447,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10012",
		"frame": {"x":0,"y":894,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10013",
		"frame": {"x":322,"y":894,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10014",
		"frame": {"x":644,"y":894,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10015",
		"frame": {"x":966,"y":894,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10016",
		"frame": {"x":1288,"y":894,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	,{
		"filename": "Symbol 3 instance 10017",
		"frame": {"x":1610,"y":894,"w":322,"h":447},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":322,"h":447},
		"sourceSize": {"w":322,"h":447}
	}
	
],
	"meta": {
		"app": "Adobe Animate",
		"version": "16.5.1.104",
		"image": "q1.png",
		"format": "RGBA8888",
		"size": {"w":2048,"h":4096},
		"scale": "1"
	}
	},
	JsonHr3:{"frames": [

		{
			"filename": "Symbol 5 instance 10000",
			"frame": {"x":1936,"y":840,"w":73,"h":52},
			"rotated": false,
			"trimmed": true,
			"spriteSourceSize": {"x":169,"y":144,"w":242,"h":449},
			"sourceSize": {"w":242,"h":449}
		}
		,{
			"filename": "Symbol 5 instance 10001",
			"frame": {"x":1936,"y":892,"w":73,"h":52},
			"rotated": false,
			"trimmed": true,
			"spriteSourceSize": {"x":169,"y":144,"w":242,"h":449},
			"sourceSize": {"w":242,"h":449}
		}
		,{
			"filename": "Symbol 5 instance 10002",
			"frame": {"x":1936,"y":944,"w":73,"h":52},
			"rotated": false,
			"trimmed": true,
			"spriteSourceSize": {"x":169,"y":144,"w":242,"h":449},
			"sourceSize": {"w":242,"h":449}
		}
		,{
			"filename": "Symbol 5 instance 10003",
			"frame": {"x":1936,"y":996,"w":73,"h":52},
			"rotated": false,
			"trimmed": true,
			"spriteSourceSize": {"x":169,"y":144,"w":242,"h":449},
			"sourceSize": {"w":242,"h":449}
		}
		,{
			"filename": "Symbol 5 instance 10004",
			"frame": {"x":1936,"y":1048,"w":73,"h":52},
			"rotated": false,
			"trimmed": true,
			"spriteSourceSize": {"x":169,"y":144,"w":242,"h":449},
			"sourceSize": {"w":242,"h":449}
		}
		,{
			"filename": "Symbol 5 instance 10005",
			"frame": {"x":1936,"y":0,"w":91,"h":168},
			"rotated": false,
			"trimmed": true,
			"spriteSourceSize": {"x":151,"y":28,"w":242,"h":449},
			"sourceSize": {"w":242,"h":449}
		}
		,{
			"filename": "Symbol 5 instance 10006",
			"frame": {"x":1936,"y":168,"w":91,"h":168},
			"rotated": false,
			"trimmed": true,
			"spriteSourceSize": {"x":151,"y":28,"w":242,"h":449},
			"sourceSize": {"w":242,"h":449}
		}
		,{
			"filename": "Symbol 5 instance 10007",
			"frame": {"x":1936,"y":336,"w":91,"h":168},
			"rotated": false,
			"trimmed": true,
			"spriteSourceSize": {"x":151,"y":28,"w":242,"h":449},
			"sourceSize": {"w":242,"h":449}
		}
		,{
			"filename": "Symbol 5 instance 10008",
			"frame": {"x":1936,"y":504,"w":91,"h":168},
			"rotated": false,
			"trimmed": true,
			"spriteSourceSize": {"x":151,"y":28,"w":242,"h":449},
			"sourceSize": {"w":242,"h":449}
		}
		,{
			"filename": "Symbol 5 instance 10009",
			"frame": {"x":1936,"y":672,"w":91,"h":168},
			"rotated": false,
			"trimmed": true,
			"spriteSourceSize": {"x":151,"y":28,"w":242,"h":449},
			"sourceSize": {"w":242,"h":449}
		}
		,{
			"filename": "Symbol 5 instance 10010",
			"frame": {"x":726,"y":2009,"w":242,"h":207},
			"rotated": false,
			"trimmed": true,
			"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
			"sourceSize": {"w":242,"h":449}
		}
		,{
			"filename": "Symbol 5 instance 10011",
			"frame": {"x":968,"y":2009,"w":242,"h":207},
			"rotated": false,
			"trimmed": true,
			"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
			"sourceSize": {"w":242,"h":449}
		}
		,{
			"filename": "Symbol 5 instance 10012",
			"frame": {"x":1210,"y":2009,"w":242,"h":207},
			"rotated": false,
			"trimmed": true,
			"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
			"sourceSize": {"w":242,"h":449}
		}
		,{
			"filename": "Symbol 5 instance 10013",
			"frame": {"x":1452,"y":2009,"w":242,"h":207},
			"rotated": false,
			"trimmed": true,
			"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
			"sourceSize": {"w":242,"h":449}
		}
		,{
			"filename": "Symbol 5 instance 10014",
			"frame": {"x":1694,"y":2009,"w":242,"h":207},
			"rotated": false,
			"trimmed": true,
			"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
			"sourceSize": {"w":242,"h":449}
		}
		,{
			"filename": "Symbol 5 instance 10015",
			"frame": {"x":484,"y":1796,"w":242,"h":213},
			"rotated": false,
			"trimmed": true,
			"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
			"sourceSize": {"w":242,"h":449}
		}
		,{
			"filename": "Symbol 5 instance 10016",
			"frame": {"x":726,"y":1796,"w":242,"h":213},
			"rotated": false,
			"trimmed": true,
			"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
			"sourceSize": {"w":242,"h":449}
		}
		,{
			"filename": "Symbol 5 instance 10017",
			"frame": {"x":968,"y":1796,"w":242,"h":213},
			"rotated": false,
			"trimmed": true,
			"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
			"sourceSize": {"w":242,"h":449}
		}
		,{
			"filename": "Symbol 5 instance 10018",
			"frame": {"x":1210,"y":1796,"w":242,"h":213},
			"rotated": false,
			"trimmed": true,
			"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
			"sourceSize": {"w":242,"h":449}
		}
		,{
			"filename": "Symbol 5 instance 10019",
			"frame": {"x":1452,"y":1796,"w":242,"h":213},
			"rotated": false,
			"trimmed": true,
			"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
			"sourceSize": {"w":242,"h":449}
		}
		,{
			"filename": "Symbol 5 instance 10020",
			"frame": {"x":1694,"y":1796,"w":242,"h":213},
			"rotated": false,
			"trimmed": true,
			"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
			"sourceSize": {"w":242,"h":449}
		}
		,{
			"filename": "Symbol 5 instance 10021",
			"frame": {"x":484,"y":2009,"w":242,"h":213},
			"rotated": false,
			"trimmed": true,
			"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
			"sourceSize": {"w":242,"h":449}
		}
		,{
			"filename": "Symbol 5 instance 10022",
			"frame": {"x":0,"y":0,"w":242,"h":449},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
			"sourceSize": {"w":242,"h":449}
		}
		,{
			"filename": "Symbol 5 instance 10023",
			"frame": {"x":242,"y":0,"w":242,"h":449},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":242,"h":449},
			"sourceSize": {"w":242,"h":449}
		}
		
		
		
		],
		"meta": {
			"app": "Adobe Animate",
			"version": "16.5.1.104",
			"image": "q5.png",
			"format": "RGBA8888",
			"size": {"w":2048,"h":4096},
			"scale": "1"
		}
		},
		
	JsonHr5:{"frames": [
	
		{
			"filename": "Symbol 7 instance 10000",
			"frame": {"x":0,"y":0,"w":395,"h":448},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
			"sourceSize": {"w":395,"h":448}
		}
		,{
			"filename": "Symbol 7 instance 10001",
			"frame": {"x":395,"y":0,"w":395,"h":448},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
			"sourceSize": {"w":395,"h":448}
		}
		,{
			"filename": "Symbol 7 instance 10002",
			"frame": {"x":790,"y":0,"w":395,"h":448},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
			"sourceSize": {"w":395,"h":448}
		}
		,{
			"filename": "Symbol 7 instance 10003",
			"frame": {"x":1185,"y":0,"w":395,"h":448},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
			"sourceSize": {"w":395,"h":448}
		}
		,{
			"filename": "Symbol 7 instance 10004",
			"frame": {"x":1580,"y":0,"w":395,"h":448},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
			"sourceSize": {"w":395,"h":448}
		}
		,{
			"filename": "Symbol 7 instance 10005",
			"frame": {"x":1975,"y":0,"w":395,"h":448},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
			"sourceSize": {"w":395,"h":448}
		}
		,{
			"filename": "Symbol 7 instance 10006",
			"frame": {"x":2370,"y":0,"w":395,"h":448},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
			"sourceSize": {"w":395,"h":448}
		}
		,{
			"filename": "Symbol 7 instance 10007",
			"frame": {"x":2765,"y":0,"w":395,"h":448},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
			"sourceSize": {"w":395,"h":448}
		}
		,{
			"filename": "Symbol 7 instance 10008",
			"frame": {"x":3160,"y":0,"w":395,"h":448},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
			"sourceSize": {"w":395,"h":448}
		}
		,{
			"filename": "Symbol 7 instance 10009",
			"frame": {"x":3555,"y":0,"w":395,"h":448},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
			"sourceSize": {"w":395,"h":448}
		}
		,{
			"filename": "Symbol 7 instance 10010",
			"frame": {"x":0,"y":448,"w":395,"h":448},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
			"sourceSize": {"w":395,"h":448}
		}
		,{
			"filename": "Symbol 7 instance 10011",
			"frame": {"x":395,"y":448,"w":395,"h":448},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
			"sourceSize": {"w":395,"h":448}
		}
		,{
			"filename": "Symbol 7 instance 10012",
			"frame": {"x":790,"y":448,"w":395,"h":448},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
			"sourceSize": {"w":395,"h":448}
		}
		,{
			"filename": "Symbol 7 instance 10013",
			"frame": {"x":1185,"y":448,"w":395,"h":448},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
			"sourceSize": {"w":395,"h":448}
		}
		,{
			"filename": "Symbol 7 instance 10014",
			"frame": {"x":1580,"y":448,"w":395,"h":448},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
			"sourceSize": {"w":395,"h":448}
		}
		,{
			"filename": "Symbol 7 instance 10015",
			"frame": {"x":1975,"y":448,"w":395,"h":448},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
			"sourceSize": {"w":395,"h":448}
		}
		,{
			"filename": "Symbol 7 instance 10016",
			"frame": {"x":2370,"y":448,"w":395,"h":448},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
			"sourceSize": {"w":395,"h":448}
		}
		,{
			"filename": "Symbol 7 instance 10017",
			"frame": {"x":2765,"y":448,"w":395,"h":448},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
			"sourceSize": {"w":395,"h":448}
		}
		,{
			"filename": "Symbol 7 instance 10018",
			"frame": {"x":3160,"y":448,"w":395,"h":448},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
			"sourceSize": {"w":395,"h":448}
		}
		,{
			"filename": "Symbol 7 instance 10019",
			"frame": {"x":3555,"y":448,"w":395,"h":448},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
			"sourceSize": {"w":395,"h":448}
		}
		,{
			"filename": "Symbol 7 instance 10020",
			"frame": {"x":0,"y":896,"w":395,"h":448},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
			"sourceSize": {"w":395,"h":448}
		}
		,{
			"filename": "Symbol 7 instance 10021",
			"frame": {"x":395,"y":896,"w":395,"h":448},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
			"sourceSize": {"w":395,"h":448}
		}
		,{
			"filename": "Symbol 7 instance 10022",
			"frame": {"x":790,"y":896,"w":395,"h":448},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
			"sourceSize": {"w":395,"h":448}
		},
             {
			"filename": "Symbol 7 instance 10023",
			"frame": {"x":1185,"y":896,"w":395,"h":448},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":395,"h":448},
			"sourceSize": {"w":395,"h":448}
		}
	
	
		],
		"meta": {
			"app": "Adobe Animate",
			"version": "16.5.1.104",
			"image": "q7.png",
			"format": "RGBA8888",
			"size": {"w":4096,"h":4096},
			"scale": "1"
		}
		},	
		JsonHr4:{"frames": [

			{
				"filename": "Symbol 10 instance 10000",
				"frame": {"x":1210,"y":1655,"w":213,"h":14},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":29,"y":0,"w":242,"h":447},
				"sourceSize": {"w":242,"h":447}
			}
			,{
				"filename": "Symbol 10 instance 10001",
				"frame": {"x":1210,"y":1669,"w":213,"h":14},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":29,"y":0,"w":242,"h":447},
				"sourceSize": {"w":242,"h":447}
			}
			,{
				"filename": "Symbol 10 instance 10002",
				"frame": {"x":1694,"y":1675,"w":213,"h":14},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":29,"y":0,"w":242,"h":447},
				"sourceSize": {"w":242,"h":447}
			}
			,{
				"filename": "Symbol 10 instance 10003",
				"frame": {"x":0,"y":1681,"w":213,"h":14},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":29,"y":0,"w":242,"h":447},
				"sourceSize": {"w":242,"h":447}
			}
			,{
				"filename": "Symbol 10 instance 10004",
				"frame": {"x":213,"y":1681,"w":213,"h":14},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":29,"y":0,"w":242,"h":447},
				"sourceSize": {"w":242,"h":447}
			}
			,{
				"filename": "Symbol 10 instance 10005",
				"frame": {"x":1210,"y":1683,"w":213,"h":14},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":29,"y":0,"w":242,"h":447},
				"sourceSize": {"w":242,"h":447}
			}
			,{
				"filename": "Symbol 10 instance 10006",
				"frame": {"x":1452,"y":1507,"w":242,"h":129},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
				"sourceSize": {"w":242,"h":447}
			}
			,{
				"filename": "Symbol 10 instance 10007",
				"frame": {"x":1210,"y":1526,"w":242,"h":129},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
				"sourceSize": {"w":242,"h":447}
			}
			,{
				"filename": "Symbol 10 instance 10008",
				"frame": {"x":1694,"y":1546,"w":242,"h":129},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
				"sourceSize": {"w":242,"h":447}
			}
			,{
				"filename": "Symbol 10 instance 10009",
				"frame": {"x":0,"y":1552,"w":242,"h":129},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
				"sourceSize": {"w":242,"h":447}
			}
			,{
				"filename": "Symbol 10 instance 10010",
				"frame": {"x":242,"y":1552,"w":242,"h":129},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
				"sourceSize": {"w":242,"h":447}
			}
			,{
				"filename": "Symbol 10 instance 10011",
				"frame": {"x":1452,"y":1636,"w":242,"h":129},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
				"sourceSize": {"w":242,"h":447}
			}
			,{
				"filename": "Symbol 10 instance 10012",
				"frame": {"x":1452,"y":1239,"w":242,"h":268},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
				"sourceSize": {"w":242,"h":447}
			}
			,{
				"filename": "Symbol 10 instance 10013",
				"frame": {"x":1694,"y":1278,"w":242,"h":268},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
				"sourceSize": {"w":242,"h":447}
			}
			,{
				"filename": "Symbol 10 instance 10014",
				"frame": {"x":0,"y":1284,"w":242,"h":268},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
				"sourceSize": {"w":242,"h":447}
			}
			,{
				"filename": "Symbol 10 instance 10015",
				"frame": {"x":242,"y":1284,"w":242,"h":268},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
				"sourceSize": {"w":242,"h":447}
			}
			,{
				"filename": "Symbol 10 instance 10016",
				"frame": {"x":484,"y":1462,"w":242,"h":268},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
				"sourceSize": {"w":242,"h":447}
			}
			,{
				"filename": "Symbol 10 instance 10017",
				"frame": {"x":726,"y":1462,"w":242,"h":268},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
				"sourceSize": {"w":242,"h":447}
			}
			,{
				"filename": "Symbol 10 instance 10018",
				"frame": {"x":968,"y":1462,"w":242,"h":268},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
				"sourceSize": {"w":242,"h":447}
			}
			,{
				"filename": "Symbol 10 instance 10019",
				"frame": {"x":484,"y":888,"w":242,"h":287},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
				"sourceSize": {"w":242,"h":447}
			}
			,{
				"filename": "Symbol 10 instance 10020",
				"frame": {"x":726,"y":888,"w":242,"h":287},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
				"sourceSize": {"w":242,"h":447}
			}
			,{
				"filename": "Symbol 10 instance 10021",
				"frame": {"x":968,"y":888,"w":242,"h":287},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
				"sourceSize": {"w":242,"h":447}
			}
			,{
				"filename": "Symbol 10 instance 10022",
				"frame": {"x":484,"y":1175,"w":242,"h":287},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
				"sourceSize": {"w":242,"h":447}
			}
			,{
				"filename": "Symbol 10 instance 10023",
				"frame": {"x":726,"y":1175,"w":242,"h":287},
				"rotated": false,
				"trimmed": true,
				"spriteSourceSize": {"x":0,"y":0,"w":242,"h":447},
				"sourceSize": {"w":242,"h":447}
			}	
			
		],
			"meta": {
				"app": "Adobe Animate",
				"version": "16.5.1.104",
				"image": "q4.png",
				"format": "RGBA8888",
				"size": {"w":2048,"h":2048},
				"scale": "1"
			}
			},

			bulbBtnJson:{"frames": [

				{
					"filename": "Symbol 1 instance 10000",
					"frame": {"x":0,"y":0,"w":66,"h":49},
					"rotated": false,
					"trimmed": false,
					"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
					"sourceSize": {"w":66,"h":49}
				}
				,{
					"filename": "Symbol 1 instance 10001",
					"frame": {"x":66,"y":0,"w":66,"h":49},
					"rotated": false,
					"trimmed": false,
					"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
					"sourceSize": {"w":66,"h":49}
				}
				,{
					"filename": "Symbol 1 instance 10002",
					"frame": {"x":132,"y":0,"w":66,"h":49},
					"rotated": false,
					"trimmed": false,
					"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
					"sourceSize": {"w":66,"h":49}
				}
				,{
					"filename": "Symbol 1 instance 10003",
					"frame": {"x":0,"y":49,"w":66,"h":49},
					"rotated": false,
					"trimmed": false,
					"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
					"sourceSize": {"w":66,"h":49}
				}
				,{
					"filename": "Symbol 1 instance 10004",
					"frame": {"x":66,"y":49,"w":66,"h":49},
					"rotated": false,
					"trimmed": false,
					"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
					"sourceSize": {"w":66,"h":49}
				}
				,{
					"filename": "Symbol 1 instance 10005",
					"frame": {"x":132,"y":49,"w":66,"h":49},
					"rotated": false,
					"trimmed": false,
					"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
					"sourceSize": {"w":66,"h":49}
				}
				,{
					"filename": "Symbol 1 instance 10006",
					"frame": {"x":0,"y":98,"w":66,"h":49},
					"rotated": false,
					"trimmed": false,
					"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
					"sourceSize": {"w":66,"h":49}
				}
				,{
					"filename": "Symbol 1 instance 10007",
					"frame": {"x":66,"y":98,"w":66,"h":49},
					"rotated": false,
					"trimmed": false,
					"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
					"sourceSize": {"w":66,"h":49}
				}
				,{
					"filename": "Symbol 1 instance 10008",
					"frame": {"x":132,"y":98,"w":66,"h":49},
					"rotated": false,
					"trimmed": false,
					"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
					"sourceSize": {"w":66,"h":49}
				}
				,{
					"filename": "Symbol 1 instance 10009",
					"frame": {"x":0,"y":147,"w":66,"h":49},
					"rotated": false,
					"trimmed": false,
					"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
					"sourceSize": {"w":66,"h":49}
				}
				,{
					"filename": "Symbol 1 instance 10010",
					"frame": {"x":66,"y":147,"w":66,"h":49},
					"rotated": false,
					"trimmed": false,
					"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
					"sourceSize": {"w":66,"h":49}
				}
				,{
					"filename": "Symbol 1 instance 10011",
					"frame": {"x":132,"y":147,"w":66,"h":49},
					"rotated": false,
					"trimmed": false,
					"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
					"sourceSize": {"w":66,"h":49}
				}
				,{
					"filename": "Symbol 1 instance 10012",
					"frame": {"x":0,"y":196,"w":66,"h":49},
					"rotated": false,
					"trimmed": false,
					"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
					"sourceSize": {"w":66,"h":49}
				}
				,{
					"filename": "Symbol 1 instance 10013",
					"frame": {"x":66,"y":196,"w":66,"h":49},
					"rotated": false,
					"trimmed": false,
					"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
					"sourceSize": {"w":66,"h":49}
				}
				,{
					"filename": "Symbol 1 instance 10014",
					"frame": {"x":132,"y":196,"w":66,"h":49},
					"rotated": false,
					"trimmed": false,
					"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
					"sourceSize": {"w":66,"h":49}
				}
				,{
					"filename": "Symbol 1 instance 10015",
					"frame": {"x":0,"y":245,"w":66,"h":49},
					"rotated": false,
					"trimmed": false,
					"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
					"sourceSize": {"w":66,"h":49}
				}
				,{
					"filename": "Symbol 1 instance 10016",
					"frame": {"x":66,"y":245,"w":66,"h":49},
					"rotated": false,
					"trimmed": false,
					"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
					"sourceSize": {"w":66,"h":49}
				}
				,{
					"filename": "Symbol 1 instance 10017",
					"frame": {"x":132,"y":245,"w":66,"h":49},
					"rotated": false,
					"trimmed": false,
					"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
					"sourceSize": {"w":66,"h":49}
				}
				,{
					"filename": "Symbol 1 instance 10018",
					"frame": {"x":0,"y":294,"w":66,"h":49},
					"rotated": false,
					"trimmed": false,
					"spriteSourceSize": {"x":0,"y":0,"w":66,"h":49},
					"sourceSize": {"w":66,"h":49}
				}],
				"meta": {
					"app": "Adobe Animate",
					"version": "18.0.0.107",
					"image": "bulb anim.png",
					"format": "RGBA8888",
					"size": {"w":198,"h":347},
					"scale": "1"
				}
				}
			

};

